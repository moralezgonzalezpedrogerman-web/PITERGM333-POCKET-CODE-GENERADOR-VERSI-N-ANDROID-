"""Pone el logotipo de PITER POCKET CODE GENERADOR como icono de la app (se ejecuta en GitHub despues de 'npx cap add android')."""
import os, shutil
res = os.path.join('android', 'app', 'src', 'main', 'res')
shutil.rmtree(os.path.join(res, 'mipmap-anydpi-v26'), ignore_errors=True)   # icono adaptable por defecto de Capacitor
for dens, size in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
    d = os.path.join(res, 'mipmap-' + dens); os.makedirs(d, exist_ok=True)
    for n in ('ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png'):
        shutil.copy(os.path.join('app-icons', '%d.png' % size), os.path.join(d, n))
print('Icono de la app puesto')
