package com.piter.pocketcodegenerador;

import android.content.Context;
import android.content.Intent;
import android.app.NotificationManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

// Puente entre la app (JavaScript) y la notificación de progreso de la generación.
@CapacitorPlugin(name = "ProgressNotify")
public class ProgressNotifyPlugin extends Plugin {
    private String title = "Generando juego";

    private NotificationManager nm() {
        return (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
    }

    @PluginMethod
    public void start(PluginCall call) {
        title = call.getString("title", "Generando juego");
        GenerationService.RUNNING = true; // antes de cualquier cuadro de permiso: así la app no se congela al pausarse
        try {
            Intent i = new Intent(getContext(), GenerationService.class);
            i.putExtra("title", title);
            i.putExtra("text", call.getString("text", "Preparando…"));
            ContextCompat.startForegroundService(getContext(), i);
        } catch (Exception e) { GenerationService.RUNNING = false; }
        try {
            if (Build.VERSION.SDK_INT >= 33 && getActivity() != null
                    && ContextCompat.checkSelfPermission(getContext(), "android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
                ActivityCompat.requestPermissions(getActivity(), new String[]{"android.permission.POST_NOTIFICATIONS"}, 7302);
        } catch (Exception e) { }
        call.resolve();
    }

    @PluginMethod
    public void update(PluginCall call) {
        try {
            int pct = call.getInt("percent", 0);
            String text = call.getString("text", "");
            NotificationManager nm = nm();
            if (nm != null && GenerationService.RUNNING)
                nm.notify(GenerationService.ID, GenerationService.build(getContext(), title + " · " + pct + "%", text, pct, true));
        } catch (Exception e) { }
        call.resolve();
    }

    @PluginMethod
    public void finish(PluginCall call) {
        try {
            boolean ok = Boolean.TRUE.equals(call.getBoolean("ok", true));
            String text = call.getString("text", "");
            getContext().stopService(new Intent(getContext(), GenerationService.class));
            NotificationManager nm = nm();
            if (nm != null) {
                nm.cancel(GenerationService.ID);
                nm.notify(GenerationService.ID + 1, GenerationService.build(getContext(), ok ? "✔ Juego generado (100%)" : "✖ No se pudo generar el juego", text, 100, false));
            }
        } catch (Exception e) { }
        call.resolve();
    }
}
