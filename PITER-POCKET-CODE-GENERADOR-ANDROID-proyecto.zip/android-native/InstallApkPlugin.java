package com.piter.pocketcodegenerador;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

// Instala desde la propia app el APK que se acaba de generar. Usa el instalador por sesiones de Android: el APK se entrega ya
// preparado, enseguida aparece la pantalla del sistema "Instalar / Cancelar" y, si algo falla, el sistema dice exactamente por qué.
@CapacitorPlugin(name = "InstallApk")
public class InstallApkPlugin extends Plugin {
    private static final String ACTION_SUFFIX = ".INSTALL_STATUS";
    private BroadcastReceiver receiver;

    private boolean allowed() {
        return Build.VERSION.SDK_INT < 26 || getContext().getPackageManager().canRequestPackageInstalls();
    }

    private void openSettings() {
        Context c = getContext();
        Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    @PluginMethod
    public void canInstall(PluginCall call) {
        JSObject r = new JSObject();
        r.put("allowed", allowed());
        call.resolve(r);
    }

    @PluginMethod
    public void install(final PluginCall call) {
        final String path = call.getString("path");
        final long expected = call.getData().optLong("size", 0L);
        if (path == null || path.length() == 0) { call.reject("Falta el archivo APK"); return; }
        new Thread(new Runnable() {
            @Override
            public void run() {
                File f = null;
                try {
                    JSObject r = new JSObject();
                    if (!allowed()) { // primero hay que permitir "instalar apps desconocidas" a esta app
                        openSettings();
                        r.put("needsPermission", true);
                        call.resolve(r);
                        return;
                    }
                    String p = path.startsWith("file:") ? Uri.parse(path).getPath() : path;
                    f = new File(p);
                    if (!f.exists() || f.length() == 0) { call.reject("No se encontró el APK preparado"); return; }
                    if (expected > 0 && f.length() != expected) {
                        call.reject("El APK preparado está incompleto (" + f.length() + " de " + expected + " bytes)");
                        return;
                    }
                    int id = startSession(f);
                    r.put("started", true);
                    r.put("session", id);
                    call.resolve(r);
                } catch (Throwable t) {
                    try { // si el instalador por sesiones no está disponible, se usa el método clásico
                        if (f != null && f.exists()) { legacyInstall(f); JSObject r = new JSObject(); r.put("started", true); r.put("legacy", true); call.resolve(r); return; }
                    } catch (Throwable t2) { }
                    call.reject(t.getMessage() == null ? t.toString() : t.getMessage());
                }
            }
        }).start();
    }

    private int startSession(File f) throws Exception {
        Context c = getContext();
        PackageInstaller installer = c.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setSize(f.length());
        int id = installer.createSession(params);
        PackageInstaller.Session session = installer.openSession(id);
        try {
            InputStream in = new FileInputStream(f);
            OutputStream out = session.openWrite("base.apk", 0, f.length());
            try {
                byte[] buf = new byte[1 << 20];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                session.fsync(out);
            } finally {
                in.close();
                out.close();
            }
            registerStatusReceiver(c);
            Intent intent = new Intent(c.getPackageName() + ACTION_SUFFIX);
            intent.setPackage(c.getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pi = PendingIntent.getBroadcast(c, id, intent, flags);
            session.commit(pi.getIntentSender());
        } catch (Exception e) {
            session.abandon();
            throw e;
        } finally {
            session.close();
        }
        return id;
    }

    private synchronized void registerStatusReceiver(Context c) {
        if (receiver != null) return;
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent it) {
                int status = it.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
                String msg = it.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) { // aquí sale la pantalla "Instalar / Cancelar" del sistema
                    Intent confirm = (Intent) it.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) {
                        confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try { ctx.startActivity(confirm); } catch (Exception e) { }
                    }
                    return;
                }
                JSObject ev = new JSObject();
                ev.put("status", status);
                ev.put("ok", status == PackageInstaller.STATUS_SUCCESS);
                ev.put("message", msg == null ? "" : msg);
                notifyListeners("installResult", ev);
            }
        };
        ContextCompat.registerReceiver(c, receiver, new IntentFilter(c.getPackageName() + ACTION_SUFFIX), ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    private void legacyInstall(File f) {
        Context c = getContext();
        Uri uri = FileProvider.getUriForFile(c, c.getPackageName() + ".piterinstall", f);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    @Override
    protected void handleOnDestroy() {
        try { if (receiver != null) getContext().unregisterReceiver(receiver); } catch (Exception e) { }
        receiver = null;
    }
}
