package com.piter.pocketcodegenerador;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;

// Instala desde la propia app el APK que se acaba de generar (abre el instalador de Android).
@CapacitorPlugin(name = "InstallApk")
public class InstallApkPlugin extends Plugin {

    private boolean allowed() {
        return Build.VERSION.SDK_INT < 26 || getContext().getPackageManager().canRequestPackageInstalls();
    }

    private void openSettings() {
        Context c = getContext();
        Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    @PluginMethod
    public void canInstall(PluginCall call) {
        JSObject r = new JSObject();
        r.put("allowed", allowed());
        call.resolve(r);
    }

    @PluginMethod
    public void install(PluginCall call) {
        String path = call.getString("path");
        if (path == null || path.length() == 0) { call.reject("Falta el archivo APK"); return; }
        try {
            JSObject r = new JSObject();
            if (!allowed()) { // primero hay que permitir "instalar apps desconocidas" a esta app
                openSettings();
                r.put("needsPermission", true);
                call.resolve(r);
                return;
            }
            String p = path.startsWith("file:") ? Uri.parse(path).getPath() : path;
            File f = new File(p);
            if (!f.exists()) { call.reject("No se encontró el APK preparado"); return; }
            Context c = getContext();
            Uri uri = FileProvider.getUriForFile(c, c.getPackageName() + ".piterinstall", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            r.put("started", true);
            call.resolve(r);
        } catch (Exception e) {
            call.reject(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }
}
