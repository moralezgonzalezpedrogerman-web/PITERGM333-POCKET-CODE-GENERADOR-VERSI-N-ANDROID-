package com.piter.pocketcodegenerador;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.provider.DocumentsContract;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

// Deja elegir una carpeta del teléfono (selector del sistema) y copiar ahí el .zip generado.
@CapacitorPlugin(name = "FolderSaver")
public class FolderSaverPlugin extends Plugin {

    @PluginMethod
    public void pickFolder(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, intent, "pickFolderResult");
    }

    @ActivityCallback
    private void pickFolderResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("cancelado");
            return;
        }
        Uri uri = data.getData();
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception ignored) { }
        JSObject ret = new JSObject();
        ret.put("uri", uri.toString());
        ret.put("name", DocumentsContract.getTreeDocumentId(uri));
        call.resolve(ret);
    }

    @PluginMethod
    public void copyToFolder(final PluginCall call) {
        final String tree = call.getString("treeUri");
        final String source = call.getString("sourceUri");
        final String name = call.getString("fileName");
        final String mime = call.getString("mimeType", "application/zip");
        if (tree == null || source == null || name == null) {
            call.reject("Faltan datos para guardar el archivo");
            return;
        }
        getBridge().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Uri treeUri = Uri.parse(tree);
                    Uri parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));
                    ContentResolver cr = getContext().getContentResolver();
                    Uri doc = DocumentsContract.createDocument(cr, parent, mime, name);
                    if (doc == null) throw new IOException("No se pudo crear el archivo en esa carpeta");
                    File src = new File(Uri.parse(source).getPath());
                    InputStream in = new FileInputStream(src);
                    OutputStream out = cr.openOutputStream(doc);
                    if (out == null) { in.close(); throw new IOException("No se pudo abrir el archivo de destino"); }
                    try {
                        byte[] buf = new byte[1 << 20];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        out.flush();
                    } finally {
                        in.close();
                        out.close();
                    }
                    JSObject ret = new JSObject();
                    ret.put("uri", doc.toString());
                    call.resolve(ret);
                } catch (Exception e) {
                    call.reject(e.getMessage() == null ? e.toString() : e.getMessage());
                }
            }
        });
    }
}
