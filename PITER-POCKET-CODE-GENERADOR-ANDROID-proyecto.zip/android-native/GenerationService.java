package com.piter.pocketcodegenerador;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

// Mantiene viva la app mientras genera un juego (aunque el usuario salga o apague la pantalla)
// y muestra en la notificación el porcentaje que lleva.
public class GenerationService extends Service {
    public static final String CH = "piter_generacion";
    public static final int ID = 7302;
    public static volatile boolean RUNNING = false;
    private PowerManager.WakeLock wl;

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(new NotificationChannel(CH, "Generación de juegos", NotificationManager.IMPORTANCE_LOW));
        }
    }

    static Notification build(Context c, String title, String text, int pct, boolean ongoing) {
        ensureChannel(c);
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        PendingIntent pi = open == null ? null : PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(ongoing).setOnlyAlertOnce(true);
        if (ongoing) b.setProgress(100, Math.max(0, Math.min(100, pct)), false);
        else b.setAutoCancel(true);
        if (pi != null) b.setContentIntent(pi);
        return b.build();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent != null && intent.getStringExtra("title") != null ? intent.getStringExtra("title") : "Generando juego";
        String text = intent != null && intent.getStringExtra("text") != null ? intent.getStringExtra("text") : "Preparando…";
        try {
            Notification n = build(this, title + " · 0%", text, 0, true);
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(ID, n);
            RUNNING = true;
            if (wl == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) { wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "piter:generacion"); wl.acquire(2L * 60 * 60 * 1000); }
            }
        } catch (Exception e) { RUNNING = false; stopSelf(); }
        return START_NOT_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) { stopSelf(); super.onTaskRemoved(rootIntent); }

    @Override public void onDestroy() {
        RUNNING = false;
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception e) { }
        super.onDestroy();
    }
}
