package com.piter.pocketcodegenerador;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(FolderSaverPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
