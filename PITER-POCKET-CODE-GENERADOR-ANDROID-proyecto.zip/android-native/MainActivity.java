package com.piter.pocketcodegenerador;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(FolderSaverPlugin.class);
        registerPlugin(ProgressNotifyPlugin.class);
        registerPlugin(InstallApkPlugin.class);
        super.onCreate(savedInstanceState);
    }

    // Mientras se genera un juego, la app sigue trabajando aunque se salga de ella o se apague la pantalla
    private void keepAlive() {
        if (!GenerationService.RUNNING) return;
        try { getBridge().getWebView().onResume(); getBridge().getWebView().resumeTimers(); } catch (Exception e) { }
    }

    @Override public void onPause() { super.onPause(); keepAlive(); }
    @Override public void onStop() { super.onStop(); keepAlive(); }
}
