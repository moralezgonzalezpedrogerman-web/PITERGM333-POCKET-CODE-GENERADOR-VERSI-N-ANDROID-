"""Segundo plano del generador (Android): permisos y servicio con notificación de progreso.
Se ejecuta en GitHub despues de 'npx cap add android'. Con --remove quita el servicio (si no compila)."""
import os, sys
M = os.path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml')
TAG = '<service android:name=".GenerationService" android:exported="false" android:foregroundServiceType="dataSync" />'
s = open(M, encoding='utf-8').read()
if '--remove' in sys.argv:
    open(M, 'w', encoding='utf-8').write(s.replace(TAG, ''))
    print('Servicio de segundo plano quitado'); sys.exit(0)
for perm in ('FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_DATA_SYNC', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'REQUEST_INSTALL_PACKAGES'):
    t = '<uses-permission android:name="android.permission.%s" />' % perm
    if t not in s:
        s = s.replace('<application', t + '\n    <application', 1)
if 'GenerationService' not in s:
    s = s.replace('</application>', '    ' + TAG + '\n    </application>', 1)
# instalar desde la app: proveedor de archivos propio (no depende del de Capacitor) con la carpeta de cache
PROV = '<provider android:name="androidx.core.content.FileProvider" android:authorities="${applicationId}.piterinstall" android:exported="false" android:grantUriPermissions="true"><meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/piter_paths" /></provider>'
if 'piterinstall' not in s:
    s = s.replace('</application>', '    ' + PROV + '\n    </application>', 1)
xml_dir = os.path.join('android', 'app', 'src', 'main', 'res', 'xml'); os.makedirs(xml_dir, exist_ok=True)
open(os.path.join(xml_dir, 'piter_paths.xml'), 'w', encoding='utf-8').write('<?xml version="1.0" encoding="utf-8"?>\n<paths>\n    <cache-path name="cache" path="." />\n    <files-path name="files" path="." />\n</paths>\n')
open(M, 'w', encoding='utf-8').write(s)
print('Segundo plano del generador listo')
