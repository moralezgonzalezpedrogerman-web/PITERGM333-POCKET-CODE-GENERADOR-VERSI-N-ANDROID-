"""Segundo plano del generador (Android): permisos y servicio con notificación de progreso.
Se ejecuta en GitHub despues de 'npx cap add android'. Con --remove quita el servicio (si no compila)."""
import os, sys
M = os.path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml')
TAG = '<service android:name=".GenerationService" android:exported="false" android:foregroundServiceType="dataSync" />'
s = open(M, encoding='utf-8').read()
if '--remove' in sys.argv:
    open(M, 'w', encoding='utf-8').write(s.replace(TAG, ''))
    print('Servicio de segundo plano quitado'); sys.exit(0)
for perm in ('FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_DATA_SYNC', 'POST_NOTIFICATIONS', 'WAKE_LOCK'):
    t = '<uses-permission android:name="android.permission.%s" />' % perm
    if t not in s:
        s = s.replace('<application', t + '\n    <application', 1)
if 'GenerationService' not in s:
    s = s.replace('</application>', '    ' + TAG + '\n    </application>', 1)
open(M, 'w', encoding='utf-8').write(s)
print('Segundo plano del generador listo')
