"""Crea www/runtime-template.zip con el motor de Electron para Windows (sin idiomas ni licencias extra)."""
import os, sys, zipfile
src, out = sys.argv[1], sys.argv[2]
KEEP_LOCALES = {'en-US.pak', 'es.pak', 'es-419.pak'}
n = 0
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for root, dirs, files in os.walk(src):
        for f in sorted(files):
            p = os.path.join(root, f)
            rel = os.path.relpath(p, src).replace(os.sep, '/')
            if rel.startswith('locales/') and f not in KEEP_LOCALES: continue
            if rel == 'LICENSES.chromium.html': continue
            if rel.startswith('resources/app'): continue
            z.write(p, rel); n += 1
if 'electron.exe' not in zipfile.ZipFile(out).namelist():
    sys.exit('ERROR: falta electron.exe en el motor de Windows')
print('Molde creado:', n, 'archivos,', round(os.path.getsize(out) / 1048576), 'MB')
