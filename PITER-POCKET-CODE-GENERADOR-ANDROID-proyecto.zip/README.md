# PITER POCKET CODE GENERADOR (Android)

Misma función que la versión de Windows, pero se usa desde el celular: elige un juego de Pocket Code
(`.catrobat` o `.zip`), lo traduce, te deja personalizar nombre/logotipo/versión, mapear botones a teclado y mouse,
y crea un `.zip` con el juego para Windows (`NombreDelJuego/NombreDelJuego.exe`). En la PC se extrae y se abre el .exe.

## Compilar el APK (GitHub)
1. Sube a tu repositorio `PITER-POCKET-CODE-GENERADOR-ANDROID-proyecto.zip` (raíz) y `compilar-apk.yml` (en `.github/workflows/`).
2. Actions → "Compilar PITER POCKET CODE GENERADOR (Android)" → Run workflow.
3. Descarga el artefacto `app-debug.apk` e instálalo (permite "instalar apps de origen desconocido").

## Carpeta de destino
Antes de generar eliges (o recuerdas) la carpeta del teléfono con el selector del sistema; el .zip se guarda ahí. Si el selector no está disponible, se usa "Guardar / Enviar".

## Diferencias con la versión de Windows
- No hay selección de carpeta: solo archivo .catrobat / .zip.
- El `.exe` del juego es un lanzador pequeño con tu logotipo, nombre y versión (se edita en el celular); abre `motor.exe`, el motor de Windows incluido en la app. Hay que extraer todo el zip y no borrar `motor.exe`. También se incluye `icono.ico`.
- Salida: un .zip (no un solo .exe).
- Necesita memoria libre (~300 MB) y un "Android System WebView" actualizado.
