# PITER POCKET CODE GENERADOR (Android)

Misma función que la versión de Windows, pero se usa desde el celular: elige un juego de Pocket Code
(`.catrobat` o `.zip`), lo traduce, te deja personalizar nombre/logotipo/versión, mapear botones a teclado y mouse,
y crea un `.zip` con el juego para Windows (`NombreDelJuego/NombreDelJuego.exe`). En la PC se extrae y se abre el .exe.

## APK de los juegos (sin GitHub)
Al compilar este generador, el flujo de GitHub también compila una plantilla (`runner.apk`) que queda dentro de la app. Al elegir "App para Android (APK)" el generador le cambia nombre, icono, orientación y archivos del juego, la firma y guarda el `.apk` listo para instalar. Si la plantilla no existe, crea el paquete + .yml de antes.
- Identificación del juego: `com.piter.juegos.<nombre>`. Carpeta de datos (no hace falta para jugar): `Android/data/<id>/files/DatosDelJuego/` con `info.json` y `LEEME.txt` (solo se crea si no existe).
- La firma usa una llave que se crea una vez en el celular y se reutiliza: mientras no borres los datos de la app, un juego con el mismo nombre se instala como actualización.

## Compilar el APK del generador (GitHub)
1. Sube a tu repositorio `PITER-POCKET-CODE-GENERADOR-ANDROID-proyecto.zip` (raíz) y `compilar-apk.yml` (en `.github/workflows/`).
2. Actions → "Compilar PITER POCKET CODE GENERADOR (Android)" → Run workflow.
3. Descarga el artefacto `app-debug.apk` e instálalo (permite "instalar apps de origen desconocido").

## Carpeta de destino
Antes de generar eliges (o recuerdas) la carpeta del teléfono con el selector del sistema; el .zip se guarda ahí. Si el selector no está disponible, se usa "Guardar / Enviar".

## Diferencias con la versión de Windows
- No hay selección de carpeta: solo archivo .catrobat / .zip.
- El `.exe` del juego es un lanzador pequeño con tu logotipo, nombre y versión (se edita en el celular); abre `motor.exe`, el motor de Windows incluido en la app. Hay que extraer todo el zip y no borrar `motor.exe`. También se incluye `icono.ico`.
- Salida: un .zip (no un solo .exe).
- Necesita memoria libre (~300 MB) y un "Android System WebView" actualizado.
