# PITER POCKET CODE GENERADOR (Android)

Misma función que la versión de Windows, pero se usa desde el celular: elige un juego de Pocket Code
(`.catrobat` o `.zip`), lo traduce, te deja personalizar nombre/logotipo/versión, mapear botones a teclado y mouse,
y crea un `.zip` con el juego para Windows (`NombreDelJuego/NombreDelJuego.exe`). En la PC se extrae y se abre el .exe.

## Compilar el APK (GitHub)
1. Sube a tu repositorio `PITER-POCKET-CODE-GENERADOR-ANDROID-proyecto.zip` (raíz) y `compilar-apk.yml` (en `.github/workflows/`).
2. Actions → "Compilar PITER POCKET CODE GENERADOR (Android)" → Run workflow.
3. Descarga el artefacto `app-debug.apk` e instálalo (permite "instalar apps de origen desconocido").

## Diferencias con la versión de Windows
- No hay selección de carpeta: solo archivo .catrobat / .zip.
- El .exe se crea copiando el motor de Windows incluido en la app (no se puede editar el icono del archivo .exe desde Android). La ventana del juego sí usa tu logotipo y se incluye `icono.ico` para el acceso directo.
- Salida: un .zip (no un solo .exe).
- Necesita memoria libre (~300 MB) y un "Android System WebView" actualizado.
