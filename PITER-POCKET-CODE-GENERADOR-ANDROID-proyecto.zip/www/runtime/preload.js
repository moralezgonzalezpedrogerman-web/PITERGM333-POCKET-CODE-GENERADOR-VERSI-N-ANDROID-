const { contextBridge, ipcRenderer } = require('electron');
const { pathToFileURL } = require('url');
const path = require('path');
contextBridge.exposeInMainWorld('api', {
  getGame: () => ipcRenderer.invoke('getGame'),
  loadVars: () => ipcRenderer.invoke('loadVars'),
  saveVars: o => ipcRenderer.invoke('saveVars', o),
  log: t => ipcRenderer.invoke('log', t),
  openUrl: u => ipcRenderer.invoke('openUrl', u),
  quit: () => ipcRenderer.invoke('quit'),
  fileUrl: rel => pathToFileURL(path.join(__dirname, rel)).href
});
