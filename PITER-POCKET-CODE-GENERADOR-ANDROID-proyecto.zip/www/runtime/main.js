// Proceso principal del juego generado: abre la ventana y guarda el progreso.
const { app, BrowserWindow, ipcMain, Menu, shell, screen } = require('electron');
const path = require('path');
const fs = require('fs');

let GAME = null;
try { GAME = JSON.parse(fs.readFileSync(path.join(__dirname, 'game.json'), 'utf8')); } catch (e) { GAME = null; }
const META = (GAME && GAME.meta) || { id: 'juego', name: 'Juego', W: 1280, H: 720 };

// Cada juego tiene su propia carpeta de datos: varios juegos instalados no se mezclan.
app.setPath('userData', path.join(app.getPath('appData'), 'PiterPocketCode', META.id));

const userFile = n => path.join(app.getPath('userData'), n);
let win;

function createWindow() {
  Menu.setApplicationMenu(null);
  const wa = screen.getPrimaryDisplay().workAreaSize;
  const k = Math.min(1280 / META.W, 720 / META.H, (wa.width * 0.95) / META.W, (wa.height * 0.9) / META.H);
  win = new BrowserWindow({
    width: Math.max(320, Math.round(META.W * k)), height: Math.max(200, Math.round(META.H * k)), useContentSize: true,
    backgroundColor: '#000000', autoHideMenuBar: true, show: false, title: META.name,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { autoplayPolicy: 'no-user-gesture-required', webSecurity: false, preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false }
  });
  win.on('page-title-updated', e => e.preventDefault());
  win.once('ready-to-show', () => { win.show(); if (META.fullscreen) win.setFullScreen(true); });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F11') win.setFullScreen(!win.isFullScreen());
    if (input.key === 'Escape' && win.isFullScreen()) win.setFullScreen(false);
    if (input.key === 'F12' && META.devtools) win.webContents.toggleDevTools();
  });
}

// Variables guardadas "en el dispositivo" (DeviceVariables.json en la carpeta de datos del juego)
let fmt = 'map';
ipcMain.handle('getGame', () => GAME);
ipcMain.handle('loadVars', () => {
  try {
    const j = JSON.parse(fs.readFileSync(userFile('DeviceVariables.json'), 'utf8'));
    return j && typeof j === 'object' ? j : {};
  } catch { return (META.initialSaved && typeof META.initialSaved === 'object') ? META.initialSaved : {}; }
});
ipcMain.handle('saveVars', (_e, obj) => {
  try { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.writeFileSync(userFile('DeviceVariables.json'), JSON.stringify(obj)); return true; }
  catch { return false; }
});
ipcMain.handle('log', (_e, line) => {
  try { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.appendFileSync(userFile('registro.txt'), new Date().toISOString() + '  ' + line + '\n'); } catch {}
});
ipcMain.handle('openUrl', (_e, url) => { if (/^https?:\/\//i.test(url)) shell.openExternal(url); });
ipcMain.handle('quit', () => app.quit());

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
