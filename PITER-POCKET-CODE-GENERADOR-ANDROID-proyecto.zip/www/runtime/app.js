// Arranque del juego: pide el game.json ya traducido y lo ejecuta.
(async function () {
  const ui = document.getElementById('ui'), msg = document.getElementById('msg'), title = document.getElementById('title');
  window.addEventListener('error', e => window.api.log('Error: ' + e.message));
  window.addEventListener('unhandledrejection', e => window.api.log('Error: ' + (e.reason && e.reason.message || e.reason)));
  try {
    const game = await window.api.getGame();
    if (!game) throw new Error('No se pudo leer game.json');
    title.textContent = game.meta.name || 'Juego';
    document.title = game.meta.name || 'Juego';
    await CatroEngine.start(game, window.api);
    ui.style.display = 'none';
  } catch (e) {
    console.error(e); window.api.log('Error al iniciar: ' + (e && e.stack || e));
    title.textContent = 'No se pudo iniciar el juego'; msg.textContent = String(e && e.message || e);
  }
})();
