'use strict';
// CatroEngine: ejecuta el game.json (ya traducido por el generador) en un canvas.
(function () {
  const STOP = Symbol('stop');
  const G = {
    api: null, game: null, W: 2400, H: 1080,
    scenes: [], sceneName: '', sprites: [], background: null, vars: {}, lists: {}, saved: {},
    touch: { down: false, x: 0, y: 0 }, now: 0, last: 0, waiters: [], videos: {}, sounds: {},
    texts: {}, pending: null, loading: false, unknown: {}, conds: [], runs: new Set(), t0: 0,
    volume: 100, gravity: { x: 0, y: -10 },
    render: { scale: 1, smooth: 'high', fps: 60, optimize: true, maxImage: 0 }, minDt: 0, lastTick: 0
  };
  const PX_PER_M = 40; // escala de la física (igual que Pocket Code)

  const seen = new Set();
  function warn(msg) { // avisa en consola y guarda en el registro (una sola vez por mensaje)
    if (seen.has(msg)) return; seen.add(msg); console.warn(msg);
    try { G.api.log && G.api.log(msg); } catch (e) {}
  }

  // ---------- fórmulas ----------
  const num = v => { if (typeof v === 'number') return v; if (typeof v === 'boolean') return v ? 1 : 0; const n = parseFloat(v); return isNaN(n) ? 0 : n; };
  const isNumLike = v => typeof v === 'number' || (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)));
  const truthy = v => num(v) !== 0;
  const RAD = Math.PI / 180, DEG = 180 / Math.PI;
  const normDir = d => { d = ((d % 360) + 360) % 360; return d > 180 ? d - 360 : d; };
  const list = name => G.lists[name] || (G.lists[name] = []);

  function ev(f, sp) {
    if (!f) return 0;
    switch (f.type) {
      case 'NUMBER': return num(f.value);
      case 'STRING': return f.value || '';
      case 'USER_VARIABLE': return G.vars[f.value] !== undefined ? G.vars[f.value] : 0;
      case 'USER_LIST': return list(f.value).join(' ');
      case 'BRACKET': return ev(f.r, sp);
      case 'COLLISION_FORMULA': return collidesWithName(sp, f.value) ? 1 : 0;
      case 'SENSOR': return sensor(f.value, sp);
      case 'FUNCTION': return fn(f, sp);
      case 'OPERATOR': return op(f, sp);
    }
    return 0;
  }
  function op(f, sp) {
    const a = () => ev(f.l, sp), b = () => ev(f.r, sp);
    switch (f.value) {
      case 'PLUS': return num(a()) + num(b());
      case 'MINUS': return f.l ? num(a()) - num(b()) : -num(b());
      case 'MULT': return num(a()) * num(b());
      case 'DIVIDE': return num(a()) / num(b());
      case 'MOD': { const x = num(a()), y = num(b()); return y === 0 ? 0 : ((x % y) + y) % y; }
      case 'POW': return Math.pow(num(a()), num(b()));
      case 'EQUAL': case 'NOT_EQUAL': {
        const x = a(), y = b(); const eq = (isNumLike(x) && isNumLike(y)) ? num(x) === num(y) : String(x) === String(y);
        return (f.value === 'EQUAL') === eq ? 1 : 0;
      }
      case 'SMALLER_THAN': return num(a()) < num(b()) ? 1 : 0;
      case 'SMALLER_OR_EQUAL': return num(a()) <= num(b()) ? 1 : 0;
      case 'GREATER_THAN': return num(a()) > num(b()) ? 1 : 0;
      case 'GREATER_OR_EQUAL': return num(a()) >= num(b()) ? 1 : 0;
      case 'LOGICAL_AND': return truthy(a()) && truthy(b()) ? 1 : 0;
      case 'LOGICAL_OR': return truthy(a()) || truthy(b()) ? 1 : 0;
      case 'LOGICAL_NOT': return truthy(b()) ? 0 : 1;
    }
    return 0;
  }
  // En fórmulas de listas, uno de los hijos es la lista (USER_LIST) y el otro el valor/índice
  function listArgs(f, sp) {
    const lIsList = f.l && f.l.type === 'USER_LIST', rIsList = f.r && f.r.type === 'USER_LIST';
    const L = lIsList ? list(f.l.value) : rIsList ? list(f.r.value) : [];
    const other = lIsList ? f.r : f.l;
    return { L, v: other ? ev(other, sp) : 0 };
  }
  function fn(f, sp) {
    const a = () => ev(f.l, sp), b = () => ev(f.r, sp);
    switch (f.value) {
      case 'TRUE': return 1; case 'FALSE': return 0; case 'PI': return Math.PI;
      case 'RAND': {
        const x = num(a()), y = num(b()), lo = Math.min(x, y), hi = Math.max(x, y);
        return (Number.isInteger(x) && Number.isInteger(y)) ? Math.floor(Math.random() * (hi - lo + 1)) + lo : lo + Math.random() * (hi - lo);
      }
      case 'ABS': return Math.abs(num(a())); case 'ROUND': return Math.round(num(a()));
      case 'FLOOR': return Math.floor(num(a())); case 'CEIL': return Math.ceil(num(a()));
      case 'SQRT': return Math.sqrt(num(a()));
      case 'SIN': return Math.sin(num(a()) * RAD); case 'COS': return Math.cos(num(a()) * RAD); case 'TAN': return Math.tan(num(a()) * RAD);
      case 'ARCSIN': return Math.asin(num(a())) * DEG; case 'ARCCOS': return Math.acos(num(a())) * DEG;
      case 'ARCTAN': return Math.atan(num(a())) * DEG; case 'ARCTAN2': return Math.atan2(num(a()), num(b())) * DEG;
      case 'LN': return Math.log(num(a())); case 'LOG': return Math.log10(num(a())); case 'EXP': return Math.exp(num(a()));
      case 'POWER': return Math.pow(num(a()), num(b()));
      case 'MOD': { const x = num(a()), y = num(b()); return y === 0 ? 0 : ((x % y) + y) % y; }
      case 'MAX': return Math.max(num(a()), num(b())); case 'MIN': return Math.min(num(a()), num(b()));
      case 'JOIN': return String(a()) + String(b());
      case 'LENGTH': return String(a()).length;
      case 'LETTER': { const i = Math.floor(num(a())), s = String(b()); return i >= 1 && i <= s.length ? s[i - 1] : ''; }
      case 'NUMBER_OF_ITEMS': return listArgs(f, sp).L.length;
      case 'LIST_ITEM': { const { L, v } = listArgs(f, sp), i = Math.floor(num(v)); return i >= 1 && i <= L.length ? L[i - 1] : 0; }
      case 'CONTAINS': { const { L, v } = listArgs(f, sp); return L.some(x => (isNumLike(x) && isNumLike(v)) ? num(x) === num(v) : String(x) === String(v)) ? 1 : 0; }
      case 'INDEX_OF_ITEM': { const { L, v } = listArgs(f, sp); return L.findIndex(x => (isNumLike(x) && isNumLike(v)) ? num(x) === num(v) : String(x) === String(v)) + 1; }
    }
    return 0;
  }
  function sensor(name, sp) {
    const d = new Date();
    switch (name) {
      case 'FINGER_TOUCHED': return G.touch.down ? 1 : 0;
      case 'FINGER_X': return G.touch.x; case 'FINGER_Y': return G.touch.y;
      case 'COLLIDES_WITH_FINGER': return sp && (sp.keyHold || (G.touch.down && hit(sp, G.touch.x, G.touch.y))) ? 1 : 0;
      case 'OBJECT_X': return sp ? sp.x : 0; case 'OBJECT_Y': return sp ? sp.y : 0;
      case 'OBJECT_SIZE': return sp ? sp.size : 100; case 'OBJECT_TRANSPARENCY': return sp ? sp.trans : 0;
      case 'OBJECT_BRIGHTNESS': return sp ? sp.bright : 100; case 'OBJECT_COLOR': return sp ? sp.color : 0;
      case 'OBJECT_ANGLE': case 'OBJECT_DIRECTION': return sp ? sp.dir : 90;
      case 'OBJECT_LOOK_NUMBER': return sp ? sp.lookIdx + 1 : 0;
      case 'OBJECT_LAYER': return sp ? G.sprites.indexOf(sp) : 0;
      case 'TIMER': return (G.now - G.t0) / 1000;
      case 'DATE_YEAR': return d.getFullYear(); case 'DATE_MONTH': return d.getMonth() + 1; case 'DATE_DAY': return d.getDate();
      case 'DATE_WEEKDAY': return d.getDay() === 0 ? 7 : d.getDay();
      case 'TIME_HOUR': return d.getHours(); case 'TIME_MINUTE': return d.getMinutes(); case 'TIME_SECOND': return d.getSeconds();
    }
    return 0; // sensores de celular (GPS, acelerómetro, etc.): en PC valen 0
  }

  // ---------- ejecución ----------
  const chk = r => { if (r.dead) throw STOP; };
  function sleep(ms, r) { return new Promise(res => G.waiters.push({ t: G.now + ms, res })).then(() => chk(r)); }
  const frame = r => sleep(0, r);

  async function runList(l, r) { for (const b of l) await exec(b, r); }

  async function exec(b, r) {
    chk(r);
    const sp = r.sprite;
    // F(categoría, posición): usa la categoría del bloque; si no existe, la fórmula en esa posición
    const F = (k, i) => ev(b.f[k] !== undefined ? b.f[k] : b.fl[i || 0], sp);
    switch (b.type) {
      // ---- movimiento ----
      case 'PlaceAtBrick': sp.x = num(F('X_POSITION', 0)); sp.y = num(F('Y_POSITION', 1)); break;
      case 'SetXBrick': sp.x = num(F('X_POSITION')); break;
      case 'SetYBrick': sp.y = num(F('Y_POSITION')); break;
      case 'ChangeXByNBrick': sp.x += num(F('X_POSITION_CHANGE')); break;
      case 'ChangeYByNBrick': sp.y += num(F('Y_POSITION_CHANGE')); break;
      case 'MoveNStepsBrick': { const n = num(F('STEPS')), a = sp.dir * RAD; sp.x += n * Math.sin(a); sp.y += n * Math.cos(a); break; }
      case 'TurnLeftBrick': sp.dir = normDir(sp.dir - num(F('TURN_LEFT_DEGREES'))); break;
      case 'TurnRightBrick': sp.dir = normDir(sp.dir + num(F('TURN_RIGHT_DEGREES'))); break;
      case 'PointInDirectionBrick': sp.dir = normDir(num(F('DEGREES'))); break;
      case 'PointToBrick': {
        const t = G.sprites.find(o => o.name === b.pointed);
        if (t && (t.x !== sp.x || t.y !== sp.y)) sp.dir = normDir(Math.atan2(t.x - sp.x, t.y - sp.y) * DEG);
        break;
      }
      case 'IfOnEdgeBounceBrick': bounceOnEdge(sp); break;
      case 'GoNStepsBackBrick': {
        const i = G.sprites.indexOf(sp); if (i <= 0) break;
        const j = Math.max(1, i - Math.floor(num(F('STEPS'))));
        G.sprites.splice(i, 1); G.sprites.splice(j, 0, sp); break;
      }
      case 'ComeToFrontBrick': { const i = G.sprites.indexOf(sp); if (i > 0) { G.sprites.splice(i, 1); G.sprites.push(sp); } break; }
      case 'GlideToBrick': {
        const dur = num(F('DURATION_IN_SECONDS', 0)) * 1000, dx = num(F('X_DESTINATION', 1)), dy = num(F('Y_DESTINATION', 2));
        const sx = sp.x, sy = sp.y, t0 = G.now;
        while (G.now - t0 < dur) { await frame(r); const p = Math.min(1, (G.now - t0) / dur); sp.x = sx + (dx - sx) * p; sp.y = sy + (dy - sy) * p; }
        sp.x = dx; sp.y = dy; break;
      }
      // ---- apariencia ----
      case 'SetSizeToBrick': sp.size = Math.max(0, num(F('SIZE'))); break;
      case 'ChangeSizeByNBrick': sp.size = Math.max(0, sp.size + num(F('SIZE_CHANGE'))); break;
      case 'SetTransparencyBrick': sp.trans = num(F('TRANSPARENCY')); break;
      case 'ChangeTransparencyByNBrick': sp.trans += num(F('TRANSPARENCY_CHANGE')); break;
      case 'SetBrightnessBrick': sp.bright = num(F('BRIGHTNESS')); break;
      case 'ChangeBrightnessByNBrick': sp.bright += num(F('BRIGHTNESS_CHANGE')); break;
      case 'SetColorBrick': sp.color = num(F('COLOR')); break;
      case 'ChangeColorByNBrick': sp.color += num(F('COLOR_CHANGE')); break;
      case 'ClearGraphicEffectBrick': sp.trans = 0; sp.bright = 100; sp.color = 0; break;
      case 'ShowBrick': sp.visible = true; break;
      case 'HideBrick': sp.visible = false; break;
      case 'NextLookBrick': if (sp.looks.length) sp.lookIdx = (sp.lookIdx + 1) % sp.looks.length; break;
      case 'PreviousLookBrick': if (sp.looks.length) sp.lookIdx = (sp.lookIdx - 1 + sp.looks.length) % sp.looks.length; break;
      case 'SetLookByIndexBrick': { const i = Math.floor(num(F('LOOK_INDEX'))) - 1; if (i >= 0 && i < sp.looks.length) sp.lookIdx = i; break; }
      case 'SetBackgroundByIndexBrick': { const bg = G.background; const i = Math.floor(num(F('LOOK_INDEX'))) - 1; if (bg && i >= 0 && i < bg.looks.length) bg.lookIdx = i; break; }
      case 'SetLookBrick': setLook(sp, b); break;
      case 'SetBackgroundBrick': setLook(G.background, b); break;
      // ---- control ----
      case 'WaitBrick': await sleep(num(F('TIME_TO_WAIT_IN_SECONDS')) * 1000, r); break;
      case 'WaitUntilBrick': while (!truthy(F('IF_CONDITION'))) await frame(r); break;
      case 'ForeverBrick': for (;;) { await runList(b.loop || [], r); await frame(r); }
      case 'RepeatBrick': { const n = Math.floor(num(F('TIMES_TO_REPEAT'))); for (let i = 0; i < n; i++) { await runList(b.loop || [], r); await frame(r); } break; }
      case 'RepeatUntilBrick': while (!truthy(F('REPEAT_UNTIL_CONDITION'))) { await runList(b.loop || [], r); await frame(r); } break;
      case 'IfLogicBeginBrick': await runList(truthy(F('IF_CONDITION')) ? (b.ifB || []) : (b.elseB || []), r); break;
      case 'IfThenLogicBeginBrick': if (truthy(F('IF_CONDITION'))) await runList(b.ifB || [], r); break;
      case 'BroadcastBrick': broadcast(b.msg || ''); break;
      case 'BroadcastWaitBrick': await Promise.all(broadcast(b.msg || '')); chk(r); break;
      case 'NoteBrick': break;
      case 'StopScriptBrick': {
        if (b.spinner === 2) { for (const s of sp.scripts) if (s.cur && s.cur !== r) s.cur.dead = true; }
        else if (b.spinner === 1) { for (const r2 of G.runs) r2.dead = true; throw STOP; }
        else throw STOP;
        break;
      }
      case 'SceneTransitionBrick': case 'SceneStartBrick': requestScene(b.scene); throw STOP;
      case 'ClearSceneBrick': break; // cada escena arranca de cero y la anterior se detiene al cambiar
      case 'ExitStageBrick': G.api.quit(); throw STOP;
      // ---- variables y listas ----
      case 'SetVariableBrick': if (b.varName != null) G.vars[b.varName] = F('VARIABLE'); break;
      case 'ChangeVariableBrick': if (b.varName != null) G.vars[b.varName] = num(G.vars[b.varName]) + num(F('VARIABLE_CHANGE')); break;
      case 'ShowTextBrick': if (b.varName != null) G.texts[b.varName] = { x: num(F('X_POSITION', 0)), y: num(F('Y_POSITION', 1)) }; break;
      case 'HideTextBrick': if (b.varName != null) delete G.texts[b.varName]; break;
      case 'WriteVariableOnDeviceBrick': if (b.varName != null) { G.saved[b.varKey || b.varName] = num(G.vars[b.varName]); G.api.saveVars(G.saved); } break;
      case 'ReadVariableFromDeviceBrick': { const k = b.varKey || b.varName; if (b.varName != null && G.saved[k] !== undefined) G.vars[b.varName] = G.saved[k]; break; }
      case 'AddItemToUserListBrick': if (b.listName != null) list(b.listName).push(F('LIST_ADD_ITEM', 0)); break;
      case 'DeleteItemOfUserListBrick': { if (b.listName == null) break; const L = list(b.listName), i = Math.floor(num(F('LIST_DELETE_ITEM', 0))); if (i >= 1 && i <= L.length) L.splice(i - 1, 1); break; }
      case 'InsertItemIntoUserListBrick': {
        if (b.listName == null) break; const L = list(b.listName);
        const v = F('INSERT_ITEM_INTO_USERLIST_VALUE', 0), i = Math.floor(num(F('INSERT_ITEM_INTO_USERLIST_INDEX', 1)));
        if (i >= 1 && i <= L.length + 1) L.splice(i - 1, 0, v); break;
      }
      case 'ReplaceItemInUserListBrick': {
        if (b.listName == null) break; const L = list(b.listName);
        const v = F('REPLACE_ITEM_IN_USERLIST_VALUE', 0), i = Math.floor(num(F('REPLACE_ITEM_IN_USERLIST_INDEX', 1)));
        if (i >= 1 && i <= L.length) L[i - 1] = v; break;
      }
      case 'ClearUserListBrick': if (b.listName != null) G.lists[b.listName] = []; break;
      // ---- sonido ----
      case 'PlaySoundBrick': playSound(b.sound, 0); break;
      case 'PlaySoundAtBrick': playSound(b.sound, num(F('PLAY_SOUND_AT')));  break;
      case 'PlaySoundAndWaitBrick': { const a = playSound(b.sound, 0); if (a) await new Promise(res => { a.onended = res; a.onerror = res; a.onpause = () => { if (a.ended || a.currentTime === 0 || r.dead) res(); }; setTimeout(res, 600000); }); chk(r); break; }
      case 'StopSoundBrick': { const a = G.sounds[b.sound]; if (a) { a.pause(); a.currentTime = 0; } break; }
      case 'StopAllSoundsBrick': stopAllSounds(); break;
      case 'SetVolumeToBrick': setVolume(num(F('VOLUME'))); break;
      case 'ChangeVolumeByNBrick': setVolume(G.volume + num(F('VOLUME_CHANGE'))); break;
      case 'SpeakBrick': speak(String(F('SPEAK'))); break;
      case 'SpeakAndWaitBrick': await speak(String(F('SPEAK'))); chk(r); break;
      // ---- física (aproximada) ----
      case 'SetPhysicsObjectTypeBrick': sp.ph.type = (b.ptype || 'NONE').toUpperCase(); break;
      case 'SetVelocityBrick': sp.ph.vx = num(F('PHYSICS_VELOCITY_X', 0)); sp.ph.vy = num(F('PHYSICS_VELOCITY_Y', 1)); break;
      case 'TurnLeftSpeedBrick': sp.ph.rot = -num(F('PHYSICS_TURN_LEFT_SPEED')); break;
      case 'TurnRightSpeedBrick': sp.ph.rot = num(F('PHYSICS_TURN_RIGHT_SPEED')); break;
      case 'SetGravityBrick': G.gravity = { x: num(F('PHYSICS_GRAVITY_X', 0)), y: num(F('PHYSICS_GRAVITY_Y', 1)) }; break;
      case 'SetMassBrick': sp.ph.mass = Math.max(0, num(F('PHYSICS_MASS'))); break;
      case 'SetBounceBrick': sp.ph.bounce = Math.max(0, num(F('PHYSICS_BOUNCE_FACTOR')) / 100); break;
      case 'SetFrictionBrick': sp.ph.friction = Math.max(0, num(F('PHYSICS_FRICTION')) / 100); break;
      // ---- video (vistas nativas) ----
      case 'CreateVideoBrick': createVideo(b, sp); break;
      case 'DeleteWebBrick': { const n = String(F('NAME')).trim(); const v = G.videos[n]; if (v) { v.pause(); v.remove(); delete G.videos[n]; } break; }
      case 'PlayVideoBrick': { const v = G.videos[String(F('NAME')).trim()]; if (v) v.play().catch(() => {}); break; }
      case 'PauseVideoBrick': { const v = G.videos[String(F('NAME')).trim()]; if (v) v.pause(); break; }
      case 'NativeViewConfigBrick': { // supuesto: propiedad 1 = opacidad (VALUE_2) de la vista VALUE_1
        const v = G.videos[String(ev(b.f.VALUE_1, sp)).trim()]; if (v && b.prop === 1) v.style.opacity = String(num(ev(b.f.VALUE_2, sp))); break;
      }
      case 'OpenUrlBrick': G.api.openUrl(String(F('OPEN_URL'))); break;
      default:
        // bloques de celular/hardware: no hacen nada en PC
        if (/^(VibrationBrick|FlashBrick|CameraBrick|ChooseCameraBrick|LedOnBrick|LedOffBrick|Lego|Arduino|Phiro|Drone|Raspi|JumpingSumo|Nfc|Set(Nxt|Ev3))/.test(b.type)) break;
        if (!G.unknown[b.type]) { G.unknown[b.type] = 1; warn('Bloque no soportado: ' + b.type); }
    }
  }
  function setLook(sp, b) {
    if (!sp) return;
    let i = -1;
    if (b.lookIdx != null && sp.looks[b.lookIdx] && (!b.lookFile || sp.looks[b.lookIdx].file === b.lookFile)) i = b.lookIdx;
    else if (b.lookFile) i = sp.looks.findIndex(l => l.file === b.lookFile);
    if (i >= 0) sp.lookIdx = i;
  }
  function bounceOnEdge(sp) {
    const l = cur(sp); if (!l || !l.img) return;
    const w = l.img.naturalWidth * sp.size / 100, h = l.img.naturalHeight * sp.size / 100;
    let d = sp.dir;
    if (sp.x - w / 2 < -G.W / 2) { sp.x = -G.W / 2 + w / 2; d = -d; }
    else if (sp.x + w / 2 > G.W / 2) { sp.x = G.W / 2 - w / 2; d = -d; }
    if (sp.y + h / 2 > G.H / 2) { sp.y = G.H / 2 - h / 2; d = 180 - d; }
    else if (sp.y - h / 2 < -G.H / 2) { sp.y = -G.H / 2 + h / 2; d = 180 - d; }
    sp.dir = normDir(d);
  }

  // ---------- scripts ----------
  function startScript(s) {
    if (s.cur) s.cur.dead = true;
    const r = { dead: false, sprite: s.sprite }; s.cur = r; G.runs.add(r);
    return (async () => {
      try { await runList(s.def.bricks, r); }
      catch (e) { if (e !== STOP) { console.error(e); warn('Error en script de ' + s.sprite.name + ': ' + (e && e.message)); } }
      finally { G.runs.delete(r); }
    })();
  }
  function broadcast(msg) {
    const ps = [];
    for (const sp of G.sprites.slice()) for (const s of sp.scripts) if (s.def.type === 'BroadcastScript' && s.def.msg === msg) ps.push(startScript(s));
    return ps;
  }

  // ---------- sprites, dibujo y toques ----------
  function makeSprite(od) {
    const sp = { name: od.name, x: 0, y: 0, size: 100, dir: 90, visible: true, trans: 0, bright: 100, color: 0, lookIdx: 0, scripts: [], looks: [], od,
      ph: { type: 'NONE', vx: 0, vy: 0, rot: 0, mass: 1, bounce: 0.8, friction: 0.2 } };
    for (const l of od.looks) sp.looks.push({ file: l.file, name: l.name, img: null });
    for (const d of od.scripts) sp.scripts.push({ def: d, sprite: sp, cur: null, prev: false });
    return sp;
  }
  function findFile(name, sceneName) {
    const list = G.game.files[String(name).toLowerCase()];
    if (!list || !list.length) return null;
    const sn = sceneName.toLowerCase();
    return list.find(p => p.toLowerCase().split(/[\\/]/).includes(sn)) || list[0];
  }
  // Las imágenes se cargan de pocas en pocas (6), se decodifican antes de usarse (sin tirones en el primer dibujo),
  // se comparten entre objetos que usan el mismo archivo y ninguna puede dejar el juego esperando para siempre.
  const imgCache = new Map(); let imgActive = 0; const imgWait = [];
  const imgSlot = () => new Promise(r => { if (imgActive < 6) { imgActive++; r(); } else imgWait.push(r); });
  const imgFree = () => { const n = imgWait.shift(); if (n) n(); else imgActive--; };
  function loadImg(file, sceneName) {
    const p = findFile(file, sceneName);
    if (!p) { warn('Falta imagen: ' + file); return Promise.resolve(null); }
    if (imgCache.has(p)) return imgCache.get(p);
    const job = (async () => {
      await imgSlot();
      try {
        return await new Promise(res => {
          const im = new Image(); let done = false, tm = 0;
          const fin = v => { if (done) return; done = true; clearTimeout(tm); res(v); };
          tm = setTimeout(() => { warn('Tardó demasiado en cargar: ' + p); fin(null); }, 20000);
          im.onload = () => { (im.decode ? im.decode().catch(() => {}) : Promise.resolve()).then(() => { try { fin(shrink(im)); } catch (e) { fin(im); } }); };
          im.onerror = () => { warn('No se pudo cargar: ' + p); fin(null); };
          im.src = G.api.fileUrl(p);
        });
      } finally { imgFree(); }
    })();
    imgCache.set(p, job); return job;
  }
  // Ahorro de memoria: las imágenes enormes se guardan reducidas (se dibujan al tamaño original)
  function shrink(im) {
    const max = G.render.maxImage, nw = im.naturalWidth, nh = im.naturalHeight;
    if (!max || Math.max(nw, nh) <= max) return im;
    const k = max / Math.max(nw, nh), cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(nw * k)); cv.height = Math.max(1, Math.round(nh * k));
    cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
    cv.naturalWidth = nw; cv.naturalHeight = nh; im.src = '';
    return cv;
  }
  const cur = sp => sp.looks[sp.lookIdx] || null;
  const px = document.createElement('canvas'); px.width = px.height = 1;
  const pxc = px.getContext('2d', { willReadFrequently: true });
  function hit(sp, x, y) {
    if (!sp.visible) return false;
    const l = cur(sp); if (!l || !l.img || sp.size <= 0) return false;
    const dx = x - sp.x, dy = -(y - sp.y); // y de pantalla (hacia abajo)
    const a = (sp.dir - 90) * RAD, c = Math.cos(-a), s = Math.sin(-a);
    const lx = (dx * c - dy * s) / (sp.size / 100) + l.img.naturalWidth / 2;
    const ly = (dx * s + dy * c) / (sp.size / 100) + l.img.naturalHeight / 2;
    if (lx < 0 || ly < 0 || lx >= l.img.naturalWidth || ly >= l.img.naturalHeight) return false;
    const k = (l.img.width || l.img.naturalWidth) / l.img.naturalWidth;
    try { pxc.clearRect(0, 0, 1, 1); pxc.drawImage(l.img, Math.floor(lx * k), Math.floor(ly * k), 1, 1, 0, 0, 1, 1); return pxc.getImageData(0, 0, 1, 1).data[3] > 0; }
    catch { return true; }
  }
  function tap(x, y, skip) {
    // "al tocar la pantalla": cualquier toque
    for (const sp of G.sprites.slice()) for (const s of sp.scripts) if (s.def.type === 'WhenTouchDownScript') startScript(s);
    // Como Catroid: el objeto más alto que reciba el toque y tenga bloque "al tocar" lo atiende;
    // si no lo tiene, el toque pasa al objeto de abajo.
    for (let i = G.sprites.length - 1; i >= 0; i--) {
      const sp = G.sprites[i], ss = sp.scripts.filter(s => s.def.type === 'WhenScript');
      if (ss.length && hit(sp, x, y)) { if (!skip || !skip.has(sp)) for (const s of ss) startScript(s); return; }
    }
  }
  // Máscara de transparencia reducida (máx. 128 px) para colisiones rápidas
  function maskOf(l) {
    if (l.mask !== undefined) return l.mask;
    if (!l.img) return null;
    const iw = l.img.naturalWidth, ih = l.img.naturalHeight, k = Math.max(1, Math.max(iw, ih) / 128);
    const w = Math.max(1, Math.round(iw / k)), h = Math.max(1, Math.round(ih / k));
    try {
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(l.img, 0, 0, w, h);
      const d = x.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h), cells = [];
      for (let i = 0; i < w * h; i++) if (d[i * 4 + 3] > 10) { a[i] = 1; cells.push(i); }
      l.mask = { w, h, a, cells, iw, ih };
    } catch (e) { l.mask = null; }
    return l.mask;
  }
  function collides(A, B) {
    if (A === B || A.size <= 0 || B.size <= 0) return false;
    if (!A.visible || !B.visible || A.trans >= 100 || B.trans >= 100) return false; // ocultos o 100 % transparentes no colisionan
    const la = cur(A), lb = cur(B); if (!la || !lb || !la.img || !lb.img) return false;
    const ra = Math.hypot(la.img.naturalWidth, la.img.naturalHeight) / 2 * A.size / 100;
    const rb = Math.hypot(lb.img.naturalWidth, lb.img.naturalHeight) / 2 * B.size / 100;
    if (Math.hypot(A.x - B.x, A.y - B.y) > ra + rb) return false;
    const ma = maskOf(la), mb = maskOf(lb); if (!ma || !mb) return true;
    const aa = (A.dir - 90) * RAD, ca = Math.cos(aa), sa = Math.sin(aa);
    const ab = -(B.dir - 90) * RAD, cb = Math.cos(ab), sb = Math.sin(ab);
    const sA = A.size / 100, sB = B.size / 100, stride = Math.max(1, Math.ceil(ma.cells.length / 3000));
    for (let n = 0; n < ma.cells.length; n += stride) {
      const c = ma.cells[n], ix = c % ma.w, iy = (c / ma.w) | 0;
      const px = ((ix + 0.5) / ma.w - 0.5) * ma.iw * sA, py = ((iy + 0.5) / ma.h - 0.5) * ma.ih * sA;
      const x = A.x + px * ca - py * sa, y = A.y - (px * sa + py * ca);     // posición en el escenario
      const dx = x - B.x, dy = -(y - B.y);
      const lx = (dx * cb - dy * sb) / sB / mb.iw * mb.w + mb.w / 2, ly = (dx * sb + dy * cb) / sB / mb.ih * mb.h + mb.h / 2;
      if (lx >= 0 && ly >= 0 && lx < mb.w && ly < mb.h && mb.a[(ly | 0) * mb.w + (lx | 0)]) return true;
    }
    return false;
  }
  function collidesWithName(sp, name) {
    if (!sp) return false;
    const n = String(name).replace(/\s*\(collision\)\s*$/i, '');
    if (/^(anything|any|todo)$/i.test(n.trim())) return G.sprites.some(o => o !== sp && collides(sp, o));
    let found = G.sprites.filter(o => o.name === n);
    if (!found.length) found = G.sprites.filter(o => o.name.trim() === n.trim());
    for (const o of found) if (collides(sp, o)) return true;
    return false;
  }
  const collTarget = msg => { const p = String(msg).split('<->'); return (p.length > 1 ? p[1] : p[0]).trim(); };

  // ---------- física aproximada (cuerpos DYNAMIC / FIXED) ----------
  function solidHit(s) {
    for (const o of G.sprites) if (o !== s && (o.ph.type === 'FIXED' || o.ph.type === 'DYNAMIC') && collides(s, o)) return o;
    return null;
  }
  function physicsStep(dt) {
    for (const s of G.sprites) {
      const p = s.ph;
      if (p.rot) s.dir = normDir(s.dir + p.rot * dt);
      if (p.type !== 'DYNAMIC') continue;
      p.vx += G.gravity.x * PX_PER_M * dt; p.vy += G.gravity.y * PX_PER_M * dt;
      let ox = s.x; s.x += p.vx * dt;
      let o = solidHit(s);
      if (o) { s.x = ox; p.vx = -p.vx * Math.max(p.bounce, o.ph.bounce); if (Math.abs(p.vx) < 5) p.vx = 0; }
      let oy = s.y; s.y += p.vy * dt;
      o = solidHit(s);
      if (o) {
        s.y = oy; p.vy = -p.vy * Math.max(p.bounce, o.ph.bounce); if (Math.abs(p.vy) < 5) p.vy = 0;
        p.vx *= Math.max(0, 1 - Math.min(1, (p.friction + o.ph.friction) / 2) * dt * 5);
      }
    }
  }

  let ctx, canvas;
  function draw() {
    const S = G.render.scale; ctx.setTransform(S, 0, 0, S, 0, 0);
    ctx.imageSmoothingEnabled = G.render.smooth !== 'off'; ctx.imageSmoothingQuality = G.render.smooth === 'high' ? 'high' : 'low';
    ctx.clearRect(0, 0, G.W, G.H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, G.W, G.H);
    for (const sp of G.sprites) {
      if (!sp.visible) continue; const l = cur(sp); if (!l || !l.img) continue;
      const alpha = 1 - sp.trans / 100; if (alpha <= 0 || sp.size <= 0) continue;
      ctx.save();
      ctx.translate(G.W / 2 + sp.x, G.H / 2 - sp.y); ctx.rotate((sp.dir - 90) * RAD);
      const s = sp.size / 100; ctx.scale(s, s); ctx.globalAlpha = Math.min(1, alpha);
      const filters = [];
      if (sp.bright !== 100) filters.push('brightness(' + Math.max(0, sp.bright) + '%)');
      if (sp.color % 200 !== 0) filters.push('hue-rotate(' + (((sp.color % 200) + 200) % 200 / 200 * 360) + 'deg)');
      if (filters.length) ctx.filter = filters.join(' ');
      ctx.drawImage(l.img, -l.img.naturalWidth / 2, -l.img.naturalHeight / 2, l.img.naturalWidth, l.img.naturalHeight);
      ctx.restore();
    }
    ctx.font = 'bold 56px Segoe UI, Arial'; ctx.textBaseline = 'top'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 6;
    if (G.loading) { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, G.W, G.H); ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('Cargando…', G.W / 2, G.H / 2); ctx.textAlign = 'left'; ctx.textBaseline = 'top'; return; }
    for (const k in G.texts) {
      const t = G.texts[k], s = String(G.vars[k] !== undefined ? G.vars[k] : 0), x = G.W / 2 + t.x, y = G.H / 2 - t.y;
      ctx.strokeText(s, x, y); ctx.fillText(s, x, y);
    }
  }

  // ---------- audio, voz y video ----------
  function setVolume(v) {
    G.volume = Math.max(0, Math.min(100, v));
    for (const k in G.sounds) G.sounds[k].volume = G.volume / 100;
  }
  function playSound(file, at) {
    if (!file) return null;
    let a = G.sounds[file];
    if (!a) { const p = findFile(file, G.sceneName); if (!p) { warn('Falta sonido: ' + file); return null; } a = new Audio(G.api.fileUrl(p)); G.sounds[file] = a; }
    a.onended = a.onerror = a.onpause = null;
    a.volume = G.volume / 100;
    try { a.currentTime = at || 0; } catch {}
    a.play().catch(() => {}); return a;
  }
  function stopAllSounds() { for (const k in G.sounds) { const a = G.sounds[k]; a.onended = a.onerror = a.onpause = null; a.pause(); try { a.removeAttribute('src'); a.load(); } catch (e) {} } G.sounds = {}; }
  function speak(text) {
    return new Promise(res => {
      try {
        const u = new SpeechSynthesisUtterance(text); u.volume = G.volume / 100;
        u.onend = u.onerror = () => res(); speechSynthesis.speak(u);
      } catch (e) { res(); }
    });
  }
  function createVideo(b, sp) {
    const F = (k, i) => ev(b.f[k] !== undefined ? b.f[k] : b.fl[i || 0], sp), name = String(F('NAME')).trim(), file = String(F('FILE'));
    const old = G.videos[name]; if (old) { old.pause(); old.remove(); }
    const p = findFile(file, G.sceneName); if (!p) { warn('Falta video: ' + file); return; }
    const v = document.createElement('video'), w = num(F('WIDTH')), h = num(F('HEIGHT'));
    v.src = G.api.fileUrl(p); v.loop = truthy(F('LOOPED')); v.controls = truthy(F('CONTROLS')); v.playsInline = true; v.autoplay = true;
    Object.assign(v.style, { width: w + 'px', height: h + 'px', objectFit: 'fill', left: (G.W / 2 + num(F('POSX')) - w / 2) + 'px', top: (G.H / 2 - num(F('POSY')) - h / 2) + 'px' });
    document.getElementById('videos').appendChild(v); G.videos[name] = v; v.play().catch(() => {});
  }
  function clearMedia() {
    stopAllSounds();
    try { speechSynthesis.cancel(); } catch (e) {}
    for (const k in G.videos) { const v = G.videos[k]; v.pause(); try { v.removeAttribute('src'); v.load(); } catch (e) {} v.remove(); } G.videos = {};
  }

  // ---------- escenas ----------
  function requestScene(name) { G.pending = name; for (const r of G.runs) r.dead = true; }
  function findScene(name) { return G.scenes.find(s => s.name === name) || G.scenes.find(s => s.name.trim() === String(name).trim()) || null; }
  // Libera la escena anterior: detiene todo lo que quedaba corriendo y suelta imágenes y sonidos de la memoria
  function freeScene(keep) {
    for (const r of G.runs) r.dead = true;
    const ws = G.waiters; G.waiters = []; for (const w of ws) w.res(); // despierta scripts dormidos para que terminen
    for (const sp of G.sprites) {
      for (const l of sp.looks) {
        l.mask = undefined;
        if (l.img && !(keep && l.path && keep.has(l.path))) { try { l.img.src = ''; if (l.img.width !== undefined && l.img.getContext) { l.img.width = 1; l.img.height = 1; } } catch (e) {} if (l.path) imgCache.delete(l.path); }
        l.img = null;
      }
      for (const s of sp.scripts) s.cur = null;
    }
    G.sprites = []; G.background = null;
  }
  async function loadScene(name) {
    const sc = findScene(name);
    if (!sc) { warn('Escena inexistente: ' + name); return; }
    G.loading = true;
    try {
      for (const r of G.runs) r.dead = true;
      if (G.render.optimize) { // lo que la escena nueva también usa no se suelta (así no se vuelve a cargar)
        const keep = new Set(); for (const od of sc.objs) for (const l of od.looks) { const p = findFile(l.file, sc.name); if (p) keep.add(p); }
        freeScene(keep);
      }
      G.runs.clear(); G.conds = []; G.texts = {}; G.gravity = { x: 0, y: -10 }; clearMedia();
      G.sceneName = sc.name; G.sprites = sc.objs.map(makeSprite); G.background = G.sprites[0] || null;
      const jobs = [];
      for (const sp of G.sprites) for (const l of sp.looks) { l.path = findFile(l.file, sc.name); jobs.push(loadImg(l.file, sc.name).then(im => { l.img = im; })); }
      await Promise.all(jobs);
    } catch (e) { console.error(e); warn('Error al cargar la escena "' + name + '": ' + (e && e.message)); }
    G.t0 = G.now; G.loading = false; // pase lo que pase, el juego sigue
    for (const sp of G.sprites) for (const s of sp.scripts) {
      if (s.def.type === 'StartScript') startScript(s);
      else if (s.def.type === 'WhenConditionScript' || s.def.type === 'CollisionScript') G.conds.push(s);
    }
  }

  // ---------- bucle principal ----------
  function tick(ts) {
    if (G.minDt && G.lastTick && ts - G.lastTick < G.minDt) { requestAnimationFrame(tick); return; }
    G.lastTick = ts;
    const dt = Math.min(0.05, Math.max(0, (ts - (G.last || ts)) / 1000)); G.last = ts; G.now = ts;
    if (!G.loading && dt > 0) physicsStep(dt);
    draw();
    if (G.pending !== null && !G.loading) { const n = G.pending; G.pending = null; loadScene(n).catch(e => { G.loading = false; warn('Error al cambiar de escena: ' + (e && e.message)); }); }
    else if (!G.loading) {
      for (const s of G.conds) {
        const v = s.def.type === 'CollisionScript' ? collidesWithName(s.sprite, collTarget(s.def.msg)) : truthy(ev(s.def.cond, s.sprite));
        if (v && !s.prev) startScript(s); s.prev = v;
      }
    }
    if (G.touch.upReq) { G.touch.down = false; G.touch.upReq = false; }
    const due = [], rest = [];
    for (const w of G.waiters) (w.t <= G.now ? due : rest).push(w);
    G.waiters = rest; for (const w of due) w.res();
    requestAnimationFrame(tick);
  }
  function fit() {
    const wrap = document.getElementById('wrap'), s = Math.min(innerWidth / G.W, innerHeight / G.H);
    wrap.style.transform = 'translate(' + (innerWidth - G.W * s) / 2 + 'px,' + (innerHeight - G.H * s) / 2 + 'px) scale(' + s + ')';
  }
  function bindInput() {
    const wrap = document.getElementById('wrap');
    const pos = e => { const r = wrap.getBoundingClientRect(); G.touch.x = (e.clientX - r.left) / r.width * G.W - G.W / 2; G.touch.y = G.H / 2 - (e.clientY - r.top) / r.height * G.H; };
    // Controles asignados a teclado/mouse (se suman al toque; la pantalla táctil sigue igual)
    const binds = (G.game.inputs || []).filter(i => i.bind);
    const fire = (it, down, trig) => {
      if (G.loading) return;
      if (it.screen) { // "pantalla tocada" en cualquier parte
        if (down) { G.touch.down = true; for (const sp of G.sprites.slice()) for (const s of sp.scripts) if (s.def.type === 'WhenTouchDownScript') startScript(s); }
        else G.touch.upReq = true;
        return;
      }
      const sp = G.sprites.find(o => o.name === it.obj); if (!sp) return;
      if (it.hold) sp.keyHold = down;
      if (down && it.tap) { for (const s of sp.scripts) if (s.def.type === 'WhenScript') startScript(s); if (trig) trig.add(sp); }
    };
    const active = it => !it.scene || it.scene === G.sceneName;
    const heldKeys = new Set();
    addEventListener('keydown', e => {
      const m = binds.filter(i => i.bind.type === 'key' && i.bind.code === e.code); if (!m.length) return;
      e.preventDefault(); if (e.repeat || heldKeys.has(e.code)) return; heldKeys.add(e.code);
      for (const it of m) if (active(it)) fire(it, true);
    });
    addEventListener('keyup', e => {
      const m = binds.filter(i => i.bind.type === 'key' && i.bind.code === e.code); if (!m.length) return;
      heldKeys.delete(e.code); for (const it of m) fire(it, false);
    });
    addEventListener('blur', () => { heldKeys.clear(); for (const it of binds) fire(it, false); });
    if (binds.some(i => i.bind.type === 'mouse')) wrap.addEventListener('contextmenu', e => e.preventDefault());

    wrap.addEventListener('pointerdown', e => {
      pos(e); const trig = new Set();
      if (e.pointerType === 'mouse') for (const it of binds) if (it.bind.type === 'mouse' && it.bind.button === e.button && active(it)) fire(it, true, trig);
      // el botón izquierdo del mouse y el toque siguen funcionando como siempre
      if (e.pointerType !== 'mouse' || e.button === 0) { G.touch.down = true; wrap.setPointerCapture(e.pointerId); if (!G.loading) tap(G.touch.x, G.touch.y, trig); }
    });
    wrap.addEventListener('pointermove', pos);
    const up = e => {
      if (e.pointerType === 'mouse') for (const it of binds) if (it.bind.type === 'mouse' && it.bind.button === e.button) fire(it, false);
      if (e.pointerType !== 'mouse' || e.button === 0) G.touch.upReq = true;
    };
    wrap.addEventListener('pointerup', up); wrap.addEventListener('pointercancel', up);
  }

  async function start(game, api) {
    G.api = api; G.game = game;
    G.W = game.meta.W || 2400; G.H = game.meta.H || 1080;
    G.scenes = game.scenes;
    if (!G.scenes.length) throw new Error('El juego no tiene escenas');
    const R = game.meta.render || {};
    G.render = { scale: Math.min(3, Math.max(0.25, R.scale || 1)), smooth: R.smooth || 'high', fps: R.fps === undefined ? 60 : R.fps, optimize: R.optimize !== false, maxImage: R.maxImage || 0 };
    G.minDt = G.render.fps > 0 ? 1000 / G.render.fps - 2 : 0;
    G.vars = Object.assign({}, game.vars || {}); // valores iniciales de las variables (vida = 100, etc.)
    G.saved = (await api.loadVars()) || {};
    canvas = document.getElementById('c'); canvas.width = Math.round(G.W * G.render.scale); canvas.height = Math.round(G.H * G.render.scale);
    canvas.style.width = G.W + 'px'; canvas.style.height = G.H + 'px'; ctx = canvas.getContext('2d', { alpha: false });
    const wrap = document.getElementById('wrap'); wrap.style.width = G.W + 'px'; wrap.style.height = G.H + 'px';
    const vids = document.getElementById('videos'); vids.style.width = G.W + 'px'; vids.style.height = G.H + 'px';
    addEventListener('resize', fit); fit(); bindInput();
    requestAnimationFrame(tick);
    await loadScene(G.scenes[0].name);
  }

  window.CatroEngine = { start, G, bindInput, ev, hit, collides, collidesWithName, tap, exec, startScript, broadcast, physicsStep, makeSprite };
})();
