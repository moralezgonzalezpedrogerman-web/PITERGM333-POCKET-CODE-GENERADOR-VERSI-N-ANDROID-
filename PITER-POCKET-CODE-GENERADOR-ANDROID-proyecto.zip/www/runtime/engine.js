'use strict';
// CatroEngine: ejecuta el game.json (ya traducido por el generador) en un canvas.
(function () {
  const STOP = Symbol('stop');
  const G = {
    api: null, game: null, W: 2400, H: 1080,
    scenes: [], sceneName: '', sprites: [], background: null, vars: {}, lists: {}, saved: {},
    touch: { down: false, x: 0, y: 0 }, now: 0, last: 0, waiters: [], videos: {}, sounds: {},
    texts: {}, pending: null, loading: false, unknown: {}, conds: [], runs: new Set(), t0: 0,
    volume: 100, gravity: { x: 0, y: -10 },
    render: { scale: 1, smooth: 'high', fps: 60, optimize: true, maxImage: 0 }, minDt: 0, lastTick: 0, memBudget: 0, fullNext: true, bgTok: 0, fingers: new Map(), fingerList: [], contacts: new Set(), cam: { x: 0, y: 0, target: null, fh: 0, fv: 0 }, stepMs: 0, acc: 0, lastTs: 0, lazy: false
  };
  const PX_PER_M = 40; // escala de la física (igual que Pocket Code)

  const seen = new Set(), ring = [];
  function note(msg) { // apunta en el registro (archivo en PC, visor F9 / 5 toques en Android)
    ring.push(((G.now / 1000) | 0) + 's  ' + msg); if (ring.length > 200) ring.shift();
    try { G.api.log && G.api.log(msg); } catch (e) {}
  }
  function warn(msg) { // avisa en consola y guarda en el registro (una sola vez por mensaje)
    if (seen.has(msg)) return; seen.add(msg); console.warn(msg); note(msg);
  }
  let logBox = null;
  function toggleLog() {
    if (logBox) { logBox.remove(); logBox = null; return; }
    if (!document.body) return;
    logBox = document.createElement('div');
    logBox.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.92);color:#cfd6e6;font:12px monospace;padding:10px;overflow:auto;white-space:pre-wrap;word-break:break-all';
    logBox.textContent = 'REGISTRO DEL JUEGO (F9 o 5 toques en la esquina superior izquierda para cerrar)\n\n' + ring.join('\n');
    logBox.onclick = toggleLog; document.body.appendChild(logBox);
  }

  // ---------- fórmulas ----------
  const num = v => { if (typeof v === 'number') return v; if (typeof v === 'boolean') return v ? 1 : 0; const n = parseFloat(v); return isNaN(n) ? 0 : n; };
  const isNumLike = v => typeof v === 'number' || (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)));
  const truthy = v => num(v) !== 0;
  const RAD = Math.PI / 180, DEG = 180 / Math.PI;
  const normDir = d => { d = ((d % 360) + 360) % 360; return d > 180 ? d - 360 : d; };
  // Variables y listas: si el objeto la declara como LOCAL (solo para este objeto), cada objeto y cada clon tiene su propia copia; si no, es global.
  const isLocalVar = (sp, n) => !!(sp && sp.locals && sp.locals.has(n));
  const getVar = (sp, n) => { const v = isLocalVar(sp, n) ? sp.vars[n] : G.vars[n]; return v === undefined ? 0 : v; };
  const setVar = (sp, n, v) => { if (isLocalVar(sp, n)) sp.vars[n] = v; else G.vars[n] = v; };
  const list = (name, sp) => { const t = sp && sp.localLists && sp.localLists.has(name) ? sp.lists : G.lists; return t[name] || (t[name] = []); };

  function ev(f, sp) {
    if (!f) return 0;
    switch (f.type) {
      case 'NUMBER': return num(f.value);
      case 'STRING': return f.value || '';
      case 'USER_VARIABLE': return getVar(sp, f.value);
      case 'USER_LIST': return list(f.value, sp).join(' ');
      case 'BRACKET': return ev(f.r, sp);
      case 'COLLISION_FORMULA': return collidesWithName(sp, f.value) ? 1 : 0;
      case 'SENSOR': return sensor(f.value, sp);
      case 'FUNCTION': return fn(f, sp);
      case 'OPERATOR': return op(f, sp);
    }
    return 0;
  }
  function op(f, sp) {
    const a = () => ev(f.l, sp), b = () => ev(f.r, sp);
    switch (f.value) {
      case 'PLUS': return num(a()) + num(b());
      case 'MINUS': return f.l ? num(a()) - num(b()) : -num(b());
      case 'MULT': return num(a()) * num(b());
      case 'DIVIDE': return num(a()) / num(b());
      case 'MOD': { const x = num(a()), y = num(b()); return y === 0 ? 0 : ((x % y) + y) % y; }
      case 'POW': return Math.pow(num(a()), num(b()));
      case 'EQUAL': case 'NOT_EQUAL': {
        const x = a(), y = b(); const eq = (isNumLike(x) && isNumLike(y)) ? num(x) === num(y) : String(x) === String(y);
        return (f.value === 'EQUAL') === eq ? 1 : 0;
      }
      case 'SMALLER_THAN': return num(a()) < num(b()) ? 1 : 0;
      case 'SMALLER_OR_EQUAL': return num(a()) <= num(b()) ? 1 : 0;
      case 'GREATER_THAN': return num(a()) > num(b()) ? 1 : 0;
      case 'GREATER_OR_EQUAL': return num(a()) >= num(b()) ? 1 : 0;
      case 'LOGICAL_AND': return truthy(a()) && truthy(b()) ? 1 : 0;
      case 'LOGICAL_OR': return truthy(a()) || truthy(b()) ? 1 : 0;
      case 'LOGICAL_NOT': return truthy(b()) ? 0 : 1;
    }
    return 0;
  }
  // En fórmulas de listas, uno de los hijos es la lista (USER_LIST) y el otro el valor/índice
  function listArgs(f, sp) {
    const lIsList = f.l && f.l.type === 'USER_LIST', rIsList = f.r && f.r.type === 'USER_LIST';
    const L = lIsList ? list(f.l.value, sp) : rIsList ? list(f.r.value, sp) : [];
    const other = lIsList ? f.r : f.l;
    return { L, v: other ? ev(other, sp) : 0 };
  }
  function fn(f, sp) {
    const a = () => ev(f.l, sp), b = () => ev(f.r, sp);
    switch (f.value) {
      case 'TRUE': return 1; case 'FALSE': return 0; case 'PI': return Math.PI;
      case 'RAND': {
        const x = num(a()), y = num(b()), lo = Math.min(x, y), hi = Math.max(x, y);
        return (Number.isInteger(x) && Number.isInteger(y)) ? Math.floor(Math.random() * (hi - lo + 1)) + lo : lo + Math.random() * (hi - lo);
      }
      case 'ABS': return Math.abs(num(a())); case 'ROUND': return Math.round(num(a()));
      case 'FLOOR': return Math.floor(num(a())); case 'CEIL': return Math.ceil(num(a()));
      case 'SQRT': return Math.sqrt(num(a()));
      case 'SIN': return Math.sin(num(a()) * RAD); case 'COS': return Math.cos(num(a()) * RAD); case 'TAN': return Math.tan(num(a()) * RAD);
      case 'ARCSIN': return Math.asin(num(a())) * DEG; case 'ARCCOS': return Math.acos(num(a())) * DEG;
      case 'ARCTAN': return Math.atan(num(a())) * DEG; case 'ARCTAN2': return Math.atan2(num(a()), num(b())) * DEG;
      case 'LN': return Math.log(num(a())); case 'LOG': return Math.log10(num(a())); case 'EXP': return Math.exp(num(a()));
      case 'POWER': return Math.pow(num(a()), num(b()));
      case 'MOD': { const x = num(a()), y = num(b()); return y === 0 ? 0 : ((x % y) + y) % y; }
      case 'MAX': return Math.max(num(a()), num(b())); case 'MIN': return Math.min(num(a()), num(b()));
      case 'JOIN': return String(a()) + String(b());
      case 'LENGTH': return String(a()).length;
      case 'LETTER': { const i = Math.floor(num(a())), s = String(b()); return i >= 1 && i <= s.length ? s[i - 1] : ''; }
      case 'NUMBER_OF_ITEMS': return listArgs(f, sp).L.length;
      case 'LIST_ITEM': { const { L, v } = listArgs(f, sp), i = Math.floor(num(v)); return i >= 1 && i <= L.length ? L[i - 1] : 0; }
      case 'CONTAINS': { const { L, v } = listArgs(f, sp); return L.some(x => (isNumLike(x) && isNumLike(v)) ? num(x) === num(v) : String(x) === String(v)) ? 1 : 0; }
      case 'REGEX': { try { const m = new RegExp(String(a())).exec(String(b())); return m ? (m[1] !== undefined ? m[1] : m[0]) : ''; } catch (e) { return ''; } }
      case 'FLATTEN': return listArgs(f, sp).L.join(' ');
      case 'COLLIDES_WITH_EDGE': { const l = sp && cur(sp); if (!l) return 0; const w = l.img.naturalWidth * sp.size / 200, h = l.img.naturalHeight * sp.size / 200; return (sp.x - w <= -G.W / 2 || sp.x + w >= G.W / 2 || sp.y - h <= -G.H / 2 || sp.y + h >= G.H / 2) ? 1 : 0; }
      case 'MULTI_FINGER_TOUCHED': return G.fingerList[Math.floor(num(a())) - 1] !== undefined ? 1 : 0;
      case 'MULTI_FINGER_X': { const t = G.fingers.get(G.fingerList[Math.floor(num(a())) - 1]); return t ? t.x : 0; }
      case 'MULTI_FINGER_Y': { const t = G.fingers.get(G.fingerList[Math.floor(num(a())) - 1]); return t ? t.y : 0; }
      case 'INDEX_OF_ITEM': { const { L, v } = listArgs(f, sp); return L.findIndex(x => (isNumLike(x) && isNumLike(v)) ? num(x) === num(v) : String(x) === String(v)) + 1; }
    }
    return 0;
  }
  function sensor(name, sp) {
    const d = new Date();
    switch (name) {
      case 'FINGER_TOUCHED': return G.touch.down ? 1 : 0;
      case 'FINGER_X': return G.touch.x; case 'FINGER_Y': return G.touch.y;
      case 'COLLIDES_WITH_FINGER': if (sp && sp.keyHold && !sp.visible) sp.keyHold = false; return sp && (sp.keyHold || (G.touch.down && hit(sp, G.touch.x, G.touch.y))) ? 1 : 0;
      case 'OBJECT_X': return sp ? sp.x : 0; case 'OBJECT_Y': return sp ? sp.y : 0;
      case 'OBJECT_SIZE': return sp ? sp.size : 100; case 'OBJECT_TRANSPARENCY': return sp ? sp.trans : 0;
      case 'OBJECT_BRIGHTNESS': return sp ? sp.bright : 100; case 'OBJECT_COLOR': return sp ? sp.color : 0;
      case 'OBJECT_ANGLE': case 'OBJECT_DIRECTION': return sp ? sp.dir : 90;
      case 'OBJECT_LOOK_NUMBER': return sp ? sp.lookIdx + 1 : 0;
      case 'OBJECT_LAYER': return sp ? G.sprites.indexOf(sp) : 0;
      case 'TIMER': return (G.now - G.t0) / 1000;
      case 'OBJECT_X_VELOCITY': return sp && sp.ph.type === 'DYNAMIC' ? sp.ph.vx : 0;
      case 'OBJECT_Y_VELOCITY': return sp && sp.ph.type === 'DYNAMIC' ? sp.ph.vy : 0;
      case 'OBJECT_ANGULAR_VELOCITY': return sp ? sp.ph.rot : 0;
      case 'MOTION_DIRECTION': return sp ? (sp.md === undefined ? sp.dir : sp.md) : 0;
      case 'LOUDNESS': return loudness();
      case 'OBJECT_WIDTH': { const l = sp && cur(sp); return l ? l.img.naturalWidth * sp.size / 100 : 0; }
      case 'OBJECT_HEIGHT': { const l = sp && cur(sp); return l ? l.img.naturalHeight * sp.size / 100 : 0; }
      case 'OBJECT_LOOK_NAME': { const l = sp && sp.looks[sp.lookIdx]; return l ? l.name : ''; }
      case 'OBJECT_NUMBER_OF_LOOKS': return sp ? sp.looks.length : 0;
      case 'OBJECT_BACKGROUND_NUMBER': return G.background ? G.background.lookIdx + 1 : 0;
      case 'OBJECT_BACKGROUND_NAME': { const l = G.background && G.background.looks[G.background.lookIdx]; return l ? l.name : ''; }
      case 'LAST_FINGER_INDEX': return G.fingerList.length;
      case 'DATE_YEAR': return d.getFullYear(); case 'DATE_MONTH': return d.getMonth() + 1; case 'DATE_DAY': return d.getDate();
      case 'DATE_WEEKDAY': return d.getDay() === 0 ? 7 : d.getDay();
      case 'TIME_HOUR': return d.getHours(); case 'TIME_MINUTE': return d.getMinutes(); case 'TIME_SECOND': return d.getSeconds();
    }
    return 0; // sensores de celular (GPS, acelerómetro, etc.): en PC valen 0
  }

  // ---------- ejecución ----------
  const chk = r => { if (r.dead) throw STOP; };
  function sleep(ms, r) { return new Promise(res => G.waiters.push({ t: G.now + ms, res })).then(() => chk(r)); }
  const frame = r => sleep(0, r);

  async function runList(l, r) { for (const b of l) await exec(b, r); }

  async function exec(b, r) {
    chk(r);
    const sp = r.sprite;
    // F(categoría, posición): usa la categoría del bloque; si no existe, la fórmula en esa posición
    const F = (k, i) => ev(b.f[k] !== undefined ? b.f[k] : b.fl[i || 0], sp);
    switch (b.type) {
      // ---- movimiento ----
      case 'PlaceAtBrick': sp.x = num(F('X_POSITION', 0)); sp.y = num(F('Y_POSITION', 1)); break;
      case 'SetXBrick': sp.x = num(F('X_POSITION')); break;
      case 'SetYBrick': sp.y = num(F('Y_POSITION')); break;
      case 'ChangeXByNBrick': sp.x += num(F('X_POSITION_CHANGE')); break;
      case 'ChangeYByNBrick': sp.y += num(F('Y_POSITION_CHANGE')); break;
      case 'MoveNStepsBrick': { const n = num(F('STEPS')), a = sp.dir * RAD; sp.x += n * Math.sin(a); sp.y += n * Math.cos(a); break; }
      case 'TurnLeftBrick': sp.dir = normDir(sp.dir - num(F('TURN_LEFT_DEGREES'))); break;
      case 'TurnRightBrick': sp.dir = normDir(sp.dir + num(F('TURN_RIGHT_DEGREES'))); break;
      case 'PointInDirectionBrick': sp.dir = normDir(num(F('DEGREES'))); break;
      case 'PointToBrick': {
        const t = G.sprites.find(o => o.name === b.pointed);
        if (t && (t.x !== sp.x || t.y !== sp.y)) sp.dir = normDir(Math.atan2(t.x - sp.x, t.y - sp.y) * DEG);
        break;
      }
      case 'IfOnEdgeBounceBrick': bounceOnEdge(sp); break;
      case 'GoNStepsBackBrick': {
        const i = G.sprites.indexOf(sp); if (i <= 0) break;
        const j = Math.max(1, i - Math.floor(num(F('STEPS'))));
        G.sprites.splice(i, 1); G.sprites.splice(j, 0, sp); break;
      }
      case 'ComeToFrontBrick': { const i = G.sprites.indexOf(sp); if (i > 0) { G.sprites.splice(i, 1); G.sprites.push(sp); } break; }
      case 'GlideToBrick': {
        const dur = num(F('DURATION_IN_SECONDS', 0)) * 1000, dx = num(F('X_DESTINATION', 1)), dy = num(F('Y_DESTINATION', 2));
        const sx = sp.x, sy = sp.y, t0 = G.now;
        while (G.now - t0 < dur) { await frame(r); const p = Math.min(1, (G.now - t0) / dur); sp.x = sx + (dx - sx) * p; sp.y = sy + (dy - sy) * p; }
        sp.x = dx; sp.y = dy; break;
      }
      // ---- apariencia ----
      case 'SetSizeToBrick': sp.size = Math.max(0, num(F('SIZE'))); break;
      case 'ChangeSizeByNBrick': sp.size = Math.max(0, sp.size + num(F('SIZE_CHANGE'))); break;
      case 'SetTransparencyBrick': sp.trans = num(F('TRANSPARENCY')); break;
      case 'ChangeTransparencyByNBrick': sp.trans += num(F('TRANSPARENCY_CHANGE')); break;
      case 'SetBrightnessBrick': sp.bright = num(F('BRIGHTNESS')); break;
      case 'ChangeBrightnessByNBrick': sp.bright += num(F('BRIGHTNESS_CHANGE')); break;
      case 'SetColorBrick': sp.color = num(F('COLOR')); break;
      case 'ChangeColorByNBrick': sp.color += num(F('COLOR_CHANGE')); break;
      case 'ClearGraphicEffectBrick': sp.trans = 0; sp.bright = 100; sp.color = 0; break;
      case 'ShowBrick': sp.visible = true; break;
      case 'HideBrick': sp.visible = false; break;
      case 'NextLookBrick': if (sp.looks.length) { const w = lookSet(sp, (sp.lookIdx + 1) % sp.looks.length, r); if (w) await w; } break;
      case 'PreviousLookBrick': if (sp.looks.length) { const w = lookSet(sp, (sp.lookIdx - 1 + sp.looks.length) % sp.looks.length, r); if (w) await w; } break;
      case 'SetLookByIndexBrick': { const i = Math.floor(num(F('LOOK_INDEX'))) - 1; if (i >= 0 && i < sp.looks.length) { const w = lookSet(sp, i, r); if (w) await w; } break; }
      case 'SetBackgroundByIndexBrick': { const bg = G.background; const i = Math.floor(num(F('LOOK_INDEX'))) - 1; if (bg && i >= 0 && i < bg.looks.length) { const w = lookSet(bg, i, r); if (w) await w; } break; }
      case 'SetLookBrick': { const k = lookIdxOf(sp, b); if (k >= 0) { const w = lookSet(sp, k, r); if (w) await w; } break; }
      case 'SetBackgroundBrick': { const bg = G.background, k = bg ? lookIdxOf(bg, b) : -1; if (k >= 0) { const w = lookSet(bg, k, r); if (w) await w; } break; }
      // ---- control ----
      case 'WaitBrick': await sleep(num(F('TIME_TO_WAIT_IN_SECONDS')) * 1000, r); break;
      case 'WaitUntilBrick': while (!truthy(F('IF_CONDITION'))) await frame(r); break;
      case 'ForeverBrick': for (;;) { await runList(b.loop || [], r); await frame(r); }
      case 'RepeatBrick': { const n = Math.floor(num(F('TIMES_TO_REPEAT'))); for (let i = 0; i < n; i++) { await runList(b.loop || [], r); await frame(r); } break; }
      case 'RepeatUntilBrick': while (!truthy(F('REPEAT_UNTIL_CONDITION'))) { await runList(b.loop || [], r); await frame(r); } break;
      case 'IfLogicBeginBrick': await runList(truthy(F('IF_CONDITION')) ? (b.ifB || []) : (b.elseB || []), r); break;
      case 'IfThenLogicBeginBrick': if (truthy(F('IF_CONDITION'))) await runList(b.ifB || [], r); break;
      case 'BroadcastBrick': broadcast(b.msg || ''); break;
      case 'BroadcastWaitBrick': await Promise.all(broadcast(b.msg || '')); chk(r); break;
      case 'NoteBrick': break;
      case 'StopScriptBrick': {
        if (b.spinner === 2) { for (const s of sp.scripts) if (s.cur && s.cur !== r) s.cur.dead = true; }
        else if (b.spinner === 1) { for (const r2 of G.runs) r2.dead = true; throw STOP; }
        else throw STOP;
        break;
      }
      case 'SceneTransitionBrick': case 'SceneStartBrick': requestScene(b.scene); throw STOP;
      case 'ClearSceneBrick': break; // cada escena arranca de cero y la anterior se detiene al cambiar
      case 'ExitStageBrick': case 'FinishStageBrick': G.api.quit(); throw STOP;
      // ---- variables y listas ----
      case 'SetVariableBrick': if (b.varName != null) setVar(sp, b.varName, F('VARIABLE')); break;
      case 'ChangeVariableBrick': if (b.varName != null) setVar(sp, b.varName, num(getVar(sp, b.varName)) + num(F('VARIABLE_CHANGE'))); break;
      case 'ShowTextBrick': if (b.varName != null) G.texts[b.varName] = { x: num(F('X_POSITION', 0)), y: num(F('Y_POSITION', 1)), owner: isLocalVar(sp, b.varName) ? sp : null }; break;
      case 'HideTextBrick': if (b.varName != null) delete G.texts[b.varName]; break;
      case 'WriteVariableOnDeviceBrick': if (b.varName != null) { G.saved[b.varKey || b.varName] = num(getVar(sp, b.varName)); G.api.saveVars(G.saved); } break;
      case 'ReadVariableFromDeviceBrick': { const k = b.varKey || b.varName; if (b.varName != null && G.saved[k] !== undefined) setVar(sp, b.varName, G.saved[k]); break; }
      case 'AddItemToUserListBrick': if (b.listName != null) list(b.listName, sp).push(F('LIST_ADD_ITEM', 0)); break;
      case 'DeleteItemOfUserListBrick': { if (b.listName == null) break; const L = list(b.listName, sp), i = Math.floor(num(F('LIST_DELETE_ITEM', 0))); if (i >= 1 && i <= L.length) L.splice(i - 1, 1); break; }
      case 'InsertItemIntoUserListBrick': {
        if (b.listName == null) break; const L = list(b.listName, sp);
        const v = F('INSERT_ITEM_INTO_USERLIST_VALUE', 0), i = Math.floor(num(F('INSERT_ITEM_INTO_USERLIST_INDEX', 1)));
        if (i >= 1 && i <= L.length + 1) L.splice(i - 1, 0, v); break;
      }
      case 'ReplaceItemInUserListBrick': {
        if (b.listName == null) break; const L = list(b.listName, sp);
        const v = F('REPLACE_ITEM_IN_USERLIST_VALUE', 0), i = Math.floor(num(F('REPLACE_ITEM_IN_USERLIST_INDEX', 1)));
        if (i >= 1 && i <= L.length) L[i - 1] = v; break;
      }
      case 'ClearUserListBrick': if (b.listName != null) list(b.listName, sp).length = 0; break;
      // ---- sonido ----
      case 'PlaySoundBrick': playSound(b.sound, 0); break;
      case 'PlaySoundAtBrick': playSound(b.sound, num(F('PLAY_SOUND_AT')));  break;
      case 'PlaySoundAndWaitBrick': { const a = playSound(b.sound, 0); if (a) await new Promise(res => { a.onended = res; a.onerror = res; a.onpause = () => { if (a.ended || a.currentTime === 0 || r.dead) res(); }; setTimeout(res, 600000); }); chk(r); break; }
      case 'StopSoundBrick': { const a = G.sounds[b.sound]; if (a) { a.pause(); a.currentTime = 0; } break; }
      case 'StopAllSoundsBrick': stopAllSounds(); break;
      case 'SetVolumeToBrick': setVolume(num(F('VOLUME'))); break;
      case 'ChangeVolumeByNBrick': setVolume(G.volume + num(F('VOLUME_CHANGE'))); break;
      case 'SpeakBrick': speak(String(F('SPEAK'))); break;
      case 'SpeakAndWaitBrick': await speak(String(F('SPEAK'))); chk(r); break;
      // ---- física (aproximada) ----
      case 'SetPhysicsObjectTypeBrick': sp.ph.type = (b.ptype || 'NONE').toUpperCase(); break;
      case 'SetVelocityBrick': sp.ph.vx = num(F('PHYSICS_VELOCITY_X', 0)); sp.ph.vy = num(F('PHYSICS_VELOCITY_Y', 1)); break;
      case 'TurnLeftSpeedBrick': sp.ph.rot = -num(F('PHYSICS_TURN_LEFT_SPEED')); break;
      case 'TurnRightSpeedBrick': sp.ph.rot = num(F('PHYSICS_TURN_RIGHT_SPEED')); break;
      case 'SetGravityBrick': G.gravity = { x: num(F('PHYSICS_GRAVITY_X', 0)), y: num(F('PHYSICS_GRAVITY_Y', 1)) }; break;
      case 'SetMassBrick': sp.ph.mass = Math.max(0, num(F('PHYSICS_MASS'))); break;
      case 'SetBounceBrick': sp.ph.bounce = Math.max(0, num(F('PHYSICS_BOUNCE_FACTOR')) / 100); break;
      case 'SetFrictionBrick': sp.ph.friction = Math.max(0, num(F('PHYSICS_FRICTION')) / 100); break;
      // ---- video (vistas nativas) ----
      case 'CreateVideoBrick': createVideo(b, sp); break;
      case 'DeleteWebBrick': { const n = String(F('NAME')).trim(); const v = G.videos[n]; if (v) { dropVideo(v); delete G.videos[n]; } break; }
      case 'PlayVideoBrick': { const v = G.videos[String(F('NAME')).trim()]; if (v) tryPlay(v); break; }
      case 'PauseVideoBrick': { const v = G.videos[String(F('NAME')).trim()]; if (v) v.pause(); break; }
      case 'NativeViewConfigBrick': { // supuesto: la propiedad 1 es el volumen (0 a 1) de la vista VALUE_1; las demás se ignoran (no se sabe qué hacen)
        const v = G.videos[String(ev(b.f.VALUE_1, sp)).trim()], val = num(ev(b.f.VALUE_2, sp));
        if (v) { if (b.prop === 1) v.volume = Math.max(0, Math.min(1, val)); else warn('Configurar vista nativa: la propiedad ' + b.prop + ' no se conoce; se ignora'); }
        break;
      }
      case 'OpenUrlBrick': G.api.openUrl(String(F('OPEN_URL'))); break;
      // ---- clones e "ir a" ----
      case 'CloneBrick': cloneSprite(sp, b.cloneOf && b.cloneOf !== sp.name ? b.cloneOf : null); break;
      case 'DeleteThisCloneBrick': if (sp.isClone) { removeSprite(sp); throw STOP; } break;
      case 'VibrationBrick': try { if (navigator.vibrate) navigator.vibrate(Math.max(0, num(F('VIBRATE_DURATION_IN_SECONDS', 0))) * 1000); } catch (e) {} break;
      case 'SetCameraFocusPointBrick': G.cam.target = sp; G.cam.fh = Math.max(0, Math.min(100, num(F('HORIZONTAL_FLEXIBILITY', 0)))); G.cam.fv = Math.max(0, Math.min(100, num(F('VERTICAL_FLEXIBILITY', 1)))); camStep(); break;
      case 'GoToBrick': {
        if (b.spinner === 80) { sp.x = G.touch.x; sp.y = G.touch.y; }
        else if (b.spinner === 81) { sp.x = Math.round((Math.random() - 0.5) * G.W); sp.y = Math.round((Math.random() - 0.5) * G.H); }
        else { const t = G.sprites.find(o => o.name === b.gotoName && !o.isClone) || G.sprites.find(o => o.name === b.gotoName); if (t) { sp.x = t.x; sp.y = t.y; } }
        break;
      }
      case 'SetRotationStyleBrick': sp.rot = b.spinner === 0 ? 0 : b.spinner === 2 ? 2 : 1; break;
      case 'TapAtBrick': tap(num(F('X_POSITION', 0)), num(F('Y_POSITION', 1))); break;
      // ---- bucles "para cada" ----
      case 'ForVariableFromToBrick': {
        if (b.varName == null) break;
        const from = num(F('FOR_LOOP_FROM', 0)), to = num(F('FOR_LOOP_TO', 1)), st = from <= to ? 1 : -1;
        for (let v = from; st > 0 ? v <= to : v >= to; v += st) { setVar(sp, b.varName, v); await runList(b.loop || [], r); await frame(r); }
        break;
      }
      case 'ForItemInUserListBrick': {
        if (b.listName == null) break;
        for (const item of list(b.listName, sp).slice()) { if (b.varName != null) setVar(sp, b.varName, item); await runList(b.loop || [], r); await frame(r); }
        break;
      }
      // ---- pluma ----
      case 'PenDownBrick': { const p = penOf(sp); p.down = true; p.lx = sp.x; p.ly = sp.y; const c = penLayer(); c.fillStyle = p.color; c.beginPath(); c.arc(G.W / 2 + sp.x, G.H / 2 - sp.y, p.size / 2, 0, 7); c.fill(); penBoxes.push([G.W / 2 + sp.x - p.size - 2, G.H / 2 - sp.y - p.size - 2, G.W / 2 + sp.x + p.size + 2, G.H / 2 - sp.y + p.size + 2]); penUsed = true; break; }
      case 'PenUpBrick': penOf(sp).down = false; break;
      case 'SetPenSizeBrick': penOf(sp).size = Math.max(0.1, num(F('PEN_SIZE', 0))); break;
      case 'SetPenColorBrick': { const cl = k => Math.max(0, Math.min(255, Math.round(num(F(k[0], k[1]))))); penOf(sp).color = 'rgb(' + cl(['PEN_COLOR_RED', 0]) + ',' + cl(['PEN_COLOR_GREEN', 1]) + ',' + cl(['PEN_COLOR_BLUE', 2]) + ')'; break; }
      case 'StampBrick': penStamp(sp); break;
      case 'ClearBackgroundBrick': penClear(); break;
      // ---- burbujas y textos ----
      case 'SayBubbleBrick': case 'ThinkBubbleBrick': { const t = String(F('STRING', 0)); sp.bubble = t === '' ? null : { text: t, think: b.type === 'ThinkBubbleBrick' }; break; }
      case 'SayForBubbleBrick': case 'ThinkForBubbleBrick': {
        const bub = { text: String(F('STRING', 0)), think: b.type === 'ThinkForBubbleBrick' }; sp.bubble = bub;
        try { await sleep(num(F('DURATION_IN_SECONDS', 1)) * 1000, r); } finally { if (sp.bubble === bub) sp.bubble = null; }
        break;
      }
      case 'ShowTextColorSizeAlignmentBrick':
        if (b.varName != null) G.texts[b.varName] = { x: num(F('X_POSITION', 0)), y: num(F('Y_POSITION', 1)), size: num(F('RELATIVE_SIZE', 2)) || 100, color: String(F('COLOR', 3) || '#ffffff'), align: b.spinner || 0, owner: isLocalVar(sp, b.varName) ? sp : null };
        break;
      // ---- entrada, web y guardado de listas ----
      case 'AskBrick': case 'AskSpeechBrick': { const ans = await askBox(String(F('ASK_QUESTION', 0))); chk(r); if (b.varName != null) setVar(sp, b.varName, ans); break; }
      case 'WebRequestBrick': {
        const url = String(F('WEB_REQUEST', 0)); let out = '';
        if (!/^https?:\/\//i.test(url)) out = 'Error: dirección no válida';
        else { try { const resp = await fetch(url); out = await resp.text(); } catch (e) { out = 'Error: ' + (e && e.message); } }
        chk(r); if (b.varName != null) setVar(sp, b.varName, out); break;
      }
      case 'WriteListOnDeviceBrick': if (b.listName != null) { G.saved[b.listKey || b.listName] = list(b.listName, sp).slice(); G.api.saveVars(G.saved); } break;
      case 'ReadListFromDeviceBrick': if (b.listName != null) { const v = G.saved[b.listKey || b.listName]; if (Array.isArray(v)) { const L2 = list(b.listName, sp); L2.length = 0; L2.push(...v); } } break;
      // ---- música ----
      case 'PlayNoteForBeatsBrick': { const note = num(F('NOTE', 0)), sec = Math.max(0, num(F('BEATS', 1))) * 60 / Math.max(1, tempo); tone(440 * Math.pow(2, (note - 69) / 12), sec, instrument); await sleep(sec * 1000, r); break; }
      case 'PauseForBeatsBrick': await sleep(Math.max(0, num(F('BEATS', 0))) * 60000 / Math.max(1, tempo), r); break;
      case 'SetTempoBrick': tempo = Math.max(1, num(F('TEMPO', 0))); break;
      case 'ChangeTempoByNBrick': tempo = Math.max(1, tempo + num(F('TEMPO_CHANGE', 0))); break;
      case 'SetInstrumentBrick': instrument = ['sine', 'square', 'sawtooth', 'triangle'][(b.spinner || 0) % 4]; break;
      case 'PlayDrumForBeatsBrick': { const sec = Math.max(0, num(F('BEATS', 0))) * 60 / Math.max(1, tempo); drum(sec); await sleep(sec * 1000, r); break; }
      default:
        // bloques de celular/hardware: no hacen nada en PC
        if (/^(VibrationBrick|FlashBrick|CameraBrick|ChooseCameraBrick|LedOnBrick|LedOffBrick|Lego|Arduino|Phiro|Drone|Raspi|JumpingSumo|Nfc|Set(Nxt|Ev3))/.test(b.type)) break;
        if (!G.unknown[b.type]) { G.unknown[b.type] = 1; warn('Bloque no soportado: ' + b.type); }
    }
  }
  // Espera (sin congelar el juego) a que la apariencia esté decodificada. Así nunca se ve una versión intermedia ni de otro tamaño.
  async function waitLook(l, r) {
    if (!l || l.img || !l.path) return;
    request(l);
    const t0 = Date.now();
    while (!l.img) {
      const e = store.get(l.path);
      if (!e || e.state === 'failed') return;          // imagen que no cargó: el script NO se detiene a esperarla
      if (e.state === 'ready') { l.img = e.img; return; }
      if (e.promise) await Promise.race([e.promise, idle(30)]); else { request(l); await idle(10); }
      chk(r); if (Date.now() - t0 > 1200) return;       // máximo 1,2 s; si no llegó, el juego sigue (la imagen aparece al terminar de cargar)
    }
  }
  async function setLookIdx(sp, i, r) { const l = sp.looks[i]; if (l) await waitLook(l, r); sp.lookIdx = i; if (sp === G.background) bgChanged(); }
  // Si la apariencia ya está lista (lo normal) se cambia al instante, sin pasos extra: los bloques corren en el mismo orden y tiempo que siempre.
  // Solo si todavía no cargó (modo ahorro de memoria) devuelve una promesa para esperarla.
  function lookSet(sp, i, r) { const l = sp.looks[i]; if (!l || l.img || !l.path) { sp.lookIdx = i; if (sp === G.background) bgChanged(); return null; } return setLookIdx(sp, i, r); }
  function setLook(sp, b) {
    if (!sp) return;
    let i = -1;
    if (b.lookIdx != null && sp.looks[b.lookIdx] && (!b.lookFile || sp.looks[b.lookIdx].file === b.lookFile)) i = b.lookIdx;
    else if (b.lookFile) i = sp.looks.findIndex(l => l.file === b.lookFile);
    if (i >= 0) sp.lookIdx = i;
  }
  function bounceOnEdge(sp) {
    const l = cur(sp); if (!l || !l.img) return;
    const w = l.img.naturalWidth * sp.size / 100, h = l.img.naturalHeight * sp.size / 100;
    let d = sp.dir;
    if (sp.x - w / 2 < -G.W / 2) { sp.x = -G.W / 2 + w / 2; d = -d; }
    else if (sp.x + w / 2 > G.W / 2) { sp.x = G.W / 2 - w / 2; d = -d; }
    if (sp.y + h / 2 > G.H / 2) { sp.y = G.H / 2 - h / 2; d = 180 - d; }
    else if (sp.y - h / 2 < -G.H / 2) { sp.y = -G.H / 2 + h / 2; d = 180 - d; }
    sp.dir = normDir(d);
  }

  // ---------- scripts ----------
  function startScript(s) {
    if (s.cur) s.cur.dead = true;
    const r = { dead: false, sprite: s.sprite }; s.cur = r; G.runs.add(r);
    return (async () => {
      try { await runList(s.def.bricks, r); }
      catch (e) { if (e !== STOP) { console.error(e); warn('Error en script de ' + s.sprite.name + ': ' + (e && e.message)); } }
      finally { G.runs.delete(r); }
    })();
  }
  function broadcast(msg) {
    const ps = [];
    for (const sp of G.sprites.slice()) for (const s of sp.scripts) if (s.def.type === 'BroadcastScript' && s.def.msg === msg) ps.push(startScript(s));
    return ps;
  }

  // ---------- sprites, dibujo y toques ----------

  // ---------- clones ----------
  const MAX_CLONES = 500;
  function cloneSprite(src, targetName) {
    const orig = targetName ? (G.sprites.find(o => o.name === targetName && !o.isClone) || G.sprites.find(o => o.name === targetName)) : src;
    if (!orig) { warn('Clonar: no encuentro el objeto "' + targetName + '"'); return null; }
    let n = 0; for (const o of G.sprites) if (o.isClone) n++;
    if (n >= MAX_CLONES) { warn('Se alcanzó el límite de ' + MAX_CLONES + ' clones; no se crean más hasta que se borren'); return null; }
    const c = makeSprite(orig.od); c.isClone = true;
    for (const k of ['x', 'y', 'size', 'dir', 'visible', 'trans', 'bright', 'color', 'lookIdx', 'rot']) c[k] = orig[k]; // el clon nace igual que el original
    c.vars = Object.assign({}, orig.vars); for (const k in orig.lists) c.lists[k] = orig.lists[k].slice(); // cada clon tiene SU copia de las variables locales (no se comparten con el original ni con otros clones)
    c.ph = { type: orig.ph.type, vx: 0, vy: 0, rot: 0, mass: orig.ph.mass, bounce: orig.ph.bounce, friction: orig.ph.friction }; // el clon nace con las mismas propiedades físicas pero SIN la velocidad del original (en Pocket Code arranca en reposo)
    attachLooks(c, G.sceneName);
    const i = G.sprites.indexOf(orig); G.sprites.splice(i < 0 ? G.sprites.length : i + 1, 0, c); // justo encima del original
    for (const s2 of c.scripts) {
      if (s2.def.type === 'WhenClonedScript') startScript(s2);
      else if (s2.def.type === 'WhenConditionScript' || s2.def.type === 'CollisionScript') G.conds.push(s2);
    }
    return c;
  }
  function removeSprite(sp) { // borra un clon: detiene sus scripts y suelta sus imágenes
    for (const s2 of sp.scripts) if (s2.cur) s2.cur.dead = true;
    G.conds = G.conds.filter(s2 => s2.sprite !== sp);
    for (const l of sp.looks) { const e = l.path && store.get(l.path); if (e) e.looks.delete(l); l.img = null; l.mask = undefined; }
    const i = G.sprites.indexOf(sp); if (i >= 0) G.sprites.splice(i, 1);
    sp.bubble = null; sp.removed = true;
  }

  // ---------- pluma (lápiz) ----------
  let penCv = null, penCx = null, penUsed = false; const penBoxes = [];
  const penLayer = () => { if (!penCv) { penCv = document.createElement('canvas'); penCv.width = G.W; penCv.height = G.H; penCx = penCv.getContext('2d'); } return penCx; };
  const penOf = sp => sp.pen || (sp.pen = { down: false, size: 3.15, color: 'rgb(0,0,0)', lx: 0, ly: 0 });
  function applyRot(c2d, sp) { if (sp.rot === 0) { if (sp.dir < 0) c2d.scale(-1, 1); } else if (sp.rot !== 2) c2d.rotate((sp.dir - 90) * RAD); }
  function penStep() { // dibuja el trazo de los objetos con la pluma abajo que se movieron
    for (const sp of G.sprites) {
      const p = sp.pen; if (!p || !p.down || (p.lx === sp.x && p.ly === sp.y)) continue;
      const c = penLayer(); c.strokeStyle = p.color; c.lineWidth = p.size; c.lineCap = 'round';
      c.beginPath(); c.moveTo(G.W / 2 + p.lx, G.H / 2 - p.ly); c.lineTo(G.W / 2 + sp.x, G.H / 2 - sp.y); c.stroke();
      const pad = p.size + 2;
      penBoxes.push([G.W / 2 + Math.min(p.lx, sp.x) - pad, G.H / 2 - Math.max(p.ly, sp.y) - pad, G.W / 2 + Math.max(p.lx, sp.x) + pad, G.H / 2 - Math.min(p.ly, sp.y) + pad]);
      p.lx = sp.x; p.ly = sp.y; penUsed = true;
    }
  }
  function penStamp(sp) {
    const l = cur(sp); if (!l || !l.img) return;
    const c = penLayer(); c.save();
    c.translate(G.W / 2 + sp.x, G.H / 2 - sp.y); applyRot(c, sp); const k = sp.size / 100; c.scale(k, k); c.globalAlpha = Math.min(1, 1 - sp.trans / 100);
    try { c.drawImage(l.img, -l.img.naturalWidth / 2, -l.img.naturalHeight / 2, l.img.naturalWidth, l.img.naturalHeight); } catch (e) {}
    c.restore(); penBoxes.push(boxOf(sp, l)); penUsed = true;
  }
  function penClear() { if (penCx) penCx.clearRect(0, 0, G.W, G.H); penBoxes.push([0, 0, G.W, G.H]); penUsed = false; }

  // ---------- burbujas de diálogo ----------
  function paintBubbles() {
    for (const sp of G.sprites) {
      const bb = sp.bubble; if (!bb || !sp.visible) continue;
      const l = cur(sp), top = l ? (l.img.naturalHeight * sp.size / 100) / 2 : 40, cx = G.W / 2 + sp.x - G.cam.x, cy = G.H / 2 - sp.y + G.cam.y - top - 24;
      ctx.save(); ctx.font = 'bold 44px Segoe UI, Arial'; ctx.textBaseline = 'middle'; ctx.textAlign = 'center';
      const lines = []; let line = '';
      for (const w of String(bb.text).split(/\s+/)) { const t = line ? line + ' ' + w : w; if (ctx.measureText(t).width > 520 && line) { lines.push(line); line = w; } else line = t; }
      if (line) lines.push(line);
      const lw = Math.min(600, Math.max(80, ...lines.map(x => ctx.measureText(x).width)) + 56), lh = lines.length * 54 + 30;
      const bx = Math.max(10, Math.min(G.W - lw - 10, cx - lw / 2)), by = Math.max(10, cy - lh);
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 5; ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(bx, by, lw, lh, 26); else ctx.rect(bx, by, lw, lh);
      ctx.fill(); ctx.stroke();
      if (bb.think) { ctx.beginPath(); ctx.arc(cx, by + lh + 16, 12, 0, 7); ctx.fill(); ctx.stroke(); ctx.beginPath(); ctx.arc(cx - 10, by + lh + 44, 7, 0, 7); ctx.fill(); ctx.stroke(); }
      else { ctx.beginPath(); ctx.moveTo(cx - 14, by + lh - 2); ctx.lineTo(cx, by + lh + 30); ctx.lineTo(cx + 14, by + lh - 2); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.fillRect(cx - 12, by + lh - 6, 24, 8); }
      ctx.fillStyle = '#000'; lines.forEach((x, i) => ctx.fillText(x, bx + lw / 2, by + 15 + 27 + i * 54));
      ctx.restore();
    }
  }

  // ---------- preguntas al jugador ----------
  function askBox(question) {
    return new Promise(res => {
      if (!document.body) return res('');
      const w = document.createElement('div'); w.style.cssText = 'position:fixed;inset:0;z-index:9998;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center';
      const box = document.createElement('div'); box.style.cssText = 'background:#fff;color:#000;border-radius:12px;padding:18px;max-width:80%;min-width:260px;font:18px sans-serif';
      const q = document.createElement('div'); q.textContent = question; q.style.marginBottom = '10px';
      const inp = document.createElement('input'); inp.type = 'text'; inp.style.cssText = 'width:100%;font:18px sans-serif;padding:8px;box-sizing:border-box';
      const ok = document.createElement('button'); ok.textContent = 'Aceptar'; ok.style.cssText = 'margin-top:10px;font:18px sans-serif;padding:8px 16px';
      const done = () => { const v = inp.value; w.remove(); res(v); };
      ok.onclick = done; inp.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') done(); });
      box.append(q, inp, ok); w.appendChild(box); document.body.appendChild(w); setTimeout(() => inp.focus(), 50);
    });
  }

  // ---------- música sencilla ----------
  let actx = null, tempo = 60, instrument = 'sine';
  const audioCtx = () => { if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } return actx; };
  function tone(freq, sec, type) {
    const a = audioCtx(); if (!a) return;
    const o = a.createOscillator(), g = a.createGain(), d = Math.max(0.05, sec);
    o.type = type || 'sine'; o.frequency.value = freq; g.gain.setValueAtTime(G.volume / 100 * 0.3, a.currentTime); g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + d);
    o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + d);
  }
  function drum(sec) {
    const a = audioCtx(); if (!a) return; const n = Math.floor(a.sampleRate * Math.min(0.25, Math.max(0.05, sec))), buf = a.createBuffer(1, n, a.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const src = a.createBufferSource(), g = a.createGain(); g.gain.value = G.volume / 100 * 0.4; src.buffer = buf; src.connect(g); g.connect(a.destination); src.start();
  }

  // ---------- eventos nuevos ----------
  function bgChanged() { // "cuando el fondo cambie a…"
    const bg = G.background; if (!bg) return; const l = bg.looks[bg.lookIdx]; if (!l) return;
    for (const sp of G.sprites) for (const s2 of sp.scripts)
      if (s2.def.type === 'WhenBackgroundChangesScript' && (!s2.def.lookFile || s2.def.lookFile === l.file) && (s2.def.lookIdx == null || s2.def.lookIdx === bg.lookIdx)) startScript(s2);
  }
  function bounced(a, b) { // "cuando rebote con…"
    const t = G.now;
    for (const [x, y] of [[a, b], [b, a]]) for (const sc of x.scripts) if (sc.def.type === 'WhenBounceOffScript') {
      const m = String(sc.def.msg || '');
      if ((!m || m === y.name || /^anything$/i.test(m)) && (!sc.last || t - sc.last > 250)) { sc.last = t; startScript(sc); }
    }
  }

  // ---------- cámara que sigue a un objeto ("establecer foco de la cámara") ----------
  function camStep() {
    const c = G.cam, t = c.target; if (!t || t.removed) return;
    const hz = c.fh / 100 * (G.W / 2), vz = c.fv / 100 * (G.H / 2), dx = t.x - c.x, dy = t.y - c.y; // flexibilidad = zona (en % de media pantalla) donde el objeto se mueve sin arrastrar la cámara
    if (dx > hz) c.x = t.x - hz; else if (dx < -hz) c.x = t.x + hz;
    if (dy > vz) c.y = t.y - vz; else if (dy < -vz) c.y = t.y + vz;
  }
  // ---------- dirección del movimiento ----------
  function motionStep() {
    for (const sp of G.sprites) {
      if (sp.mx === undefined) { sp.mx = sp.x; sp.my = sp.y; sp.md = sp.dir; continue; }
      const dx = sp.x - sp.mx, dy = sp.y - sp.my; if (dx !== 0 || dy !== 0) sp.md = normDir(Math.atan2(dx, dy) * DEG);
      sp.mx = sp.x; sp.my = sp.y;
    }
  }
  // ---------- micrófono (sensor "volumen") ----------
  let micState = null;
  function loudness() {
    if (micState === 'denied' || micState === 'pending') return 0;
    if (micState === null) {
      micState = 'pending';
      try {
        navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
          const a = audioCtx(); if (!a) { micState = 'denied'; return; }
          const an = a.createAnalyser(); an.fftSize = 1024; a.createMediaStreamSource(stream).connect(an); micState = { an, buf: new Float32Array(an.fftSize) };
        }).catch(() => { micState = 'denied'; });
      } catch (e) { micState = 'denied'; }
      return 0;
    }
    micState.an.getFloatTimeDomainData(micState.buf); let sum = 0; for (let i = 0; i < micState.buf.length; i++) sum += micState.buf[i] * micState.buf[i];
    return Math.min(100, Math.round(Math.sqrt(sum / micState.buf.length) * 300));
  }

  let spId = 0;
  function makeSprite(od) {
    const sp = { id: ++spId, pv: null, fb: null, locals: new Set(od.locals || []), vars: {}, localLists: new Set(od.localLists || []), lists: {}, removed: false, rot: 1, pen: null, bubble: null, isClone: false, name: od.name, x: 0, y: 0, size: 100, dir: 90, visible: true, trans: 0, bright: 100, color: 0, lookIdx: 0, scripts: [], looks: [], od,
      ph: { type: 'NONE', vx: 0, vy: 0, rot: 0, mass: 1, bounce: 0.8, friction: 0.2 } };
    for (const l of od.looks) sp.looks.push({ file: l.file, name: l.name, img: null, path: null });
    for (const d of od.scripts) sp.scripts.push({ def: d, sprite: sp, cur: null, prev: false });
    return sp;
  }
  function findFile(name, sceneName) {
    const list = G.game.files[String(name).toLowerCase()];
    if (!list || !list.length) return null;
    const sn = sceneName.toLowerCase();
    return list.find(p => p.toLowerCase().split(/[\\/]/).includes(sn)) || list[0];
  }
  // ---------- imágenes: carga bajo demanda, tope de memoria y precarga ----------
  // Cada archivo se decodifica una sola vez (aunque lo usen varios objetos). Solo se cargan al inicio las apariencias que la escena muestra
  // primero; el resto va llegando en segundo plano. Hay un tope de memoria: si se pasa, se sueltan las menos usadas (nunca las que se están viendo).
  const store = new Map(); let usedPx = 0; let imgActive = 0; const imgWait = [];
  const imgSlot = () => new Promise(r => { if (imgActive < 6) { imgActive++; r(); } else imgWait.push(r); });
  const imgFree = () => { const n = imgWait.shift(); if (n) n(); else imgActive--; };
  const entryFor = p => { let e = store.get(p); if (!e) { e = { path: p, img: null, state: 'none', px: 0, last: 0, promise: null, looks: new Set(), hold: false, fails: 0, failAt: 0 }; store.set(p, e); } return e; };
  // JPG de galería: pueden traer una "orientación" interna (EXIF). Pocket Code la ignora (usa los píxeles tal cual) pero el navegador la aplica,
  // y eso cambia el tamaño/giro de la imagen. Aquí se detecta y se deja como en Pocket Code.
  function exifInfo(u8) {
    try {
      if (u8[0] !== 0xFF || u8[1] !== 0xD8) return null;
      let i = 2, ori = 1, rw = 0, rh = 0;
      while (i + 9 < u8.length) {
        if (u8[i] !== 0xFF) { i++; continue; }
        const m = u8[i + 1]; if (m === 0xD8 || m === 0x01 || (m >= 0xD0 && m <= 0xD7)) { i += 2; continue; }
        const len = (u8[i + 2] << 8) | u8[i + 3];
        if (m === 0xE1 && u8[i + 4] === 0x45 && u8[i + 5] === 0x78 && u8[i + 6] === 0x69 && u8[i + 7] === 0x66) {
          const t = i + 10, le = u8[t] === 0x49, r16 = o => le ? (u8[o] | (u8[o + 1] << 8)) : ((u8[o] << 8) | u8[o + 1]);
          const r32 = o => (le ? (u8[o] | (u8[o + 1] << 8) | (u8[o + 2] << 16) | (u8[o + 3] << 24)) : ((u8[o] << 24) | (u8[o + 1] << 16) | (u8[o + 2] << 8) | u8[o + 3])) >>> 0;
          const ifd = t + r32(t + 4); if (ifd + 2 < u8.length) { const n = r16(ifd); for (let k = 0; k < n && ifd + 2 + k * 12 + 10 < u8.length; k++) { const e = ifd + 2 + k * 12; if (r16(e) === 0x0112) { ori = r16(e + 8); break; } } }
        }
        if (m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) { rh = (u8[i + 5] << 8) | u8[i + 6]; rw = (u8[i + 7] << 8) | u8[i + 8]; break; }
        i += 2 + len;
      }
      return { ori, rw, rh };
    } catch (e) { return null; }
  }
  const EXIF_M = { 2: [-1, 0, 0, 1, 'W', 0], 3: [-1, 0, 0, -1, 'W', 'H'], 4: [1, 0, 0, -1, 0, 'H'], 5: [0, 1, 1, 0, 0, 0], 6: [0, -1, 1, 0, 0, 'W'], 7: [0, -1, -1, 0, 'H', 'W'], 8: [0, 1, -1, 0, 'H', 0] };
  let exifApplied = null; // ¿el navegador aplica la orientación EXIF? (se descubre con la primera imagen girada)
  async function exifFix(im, url, file) {
    if (!/\.jpe?g$/i.test(file || '')) return im;
    try {
      const bl = await fetchBlob(url), info = exifInfo(new Uint8Array(await bl.slice(0, 131072).arrayBuffer()));
      if (!info || info.ori < 2 || info.ori > 8) return im;
      const W = im.naturalWidth, H = im.naturalHeight;
      if (info.ori >= 5) { const applied = (W === info.rh && H === info.rw && W !== H); if (!applied && W === info.rw && H === info.rh) { exifApplied = false; return im; } exifApplied = applied || exifApplied; }
      else if (exifApplied === false) return im;
      const swap = info.ori >= 5, cv = document.createElement('canvas'); cv.width = swap ? H : W; cv.height = swap ? W : H;
      const M = EXIF_M[info.ori].map(v => v === 'W' ? W : v === 'H' ? H : v), c = cv.getContext('2d');
      c.setTransform(M[0], M[1], M[2], M[3], M[4], M[5]); c.drawImage(im, 0, 0);
      cv.naturalWidth = cv.width; cv.naturalHeight = cv.height; im.src = '';
      note('Imagen ' + file + ': tenía rotación EXIF ' + info.ori + '; se dejó como en Pocket Code (' + cv.width + 'x' + cv.height + ')');
      return cv;
    } catch (e) { return im; }
  }
  function decodePath(p) { // imagen lista para dibujar (o null); nunca se queda esperando para siempre
    return new Promise(res => {
      const im = new Image(); let done = false, tm = 0;
      const fin = v => { if (done) return; done = true; clearTimeout(tm); res(v); };
      tm = setTimeout(() => { warn('Tardó demasiado en cargar: ' + p); fin(null); }, 20000);
      im.onload = () => { (im.decode ? im.decode().catch(() => {}) : Promise.resolve()).then(() => exifFix(im, im.src, p)).then(v => { try { fin(shrink(v)); } catch (e) { fin(v); } }).catch(() => fin(im)); };
      im.onerror = () => { warn('No se pudo cargar: ' + p); fin(null); };
      im.src = G.api.fileUrl(p);
    });
  }
  function evict(e) { // suelta la imagen de la memoria (se puede volver a cargar)
    for (const l of e.looks) { l.img = null; l.mask = undefined; }
    if (e.img) { try { e.img.src = ''; if (e.img.getContext) { e.img.width = 1; e.img.height = 1; } } catch (x) {} }
    usedPx -= e.px; e.img = null; e.state = 'none'; e.px = 0;
  }
  function loadEntry(e) {
    if (e.state === 'ready') return Promise.resolve(e);
    if (e.promise) return e.promise;
    e.state = 'loading';
    e.promise = (async () => { await imgSlot(); try { return await decodePath(e.path); } finally { imgFree(); } })().then(im => {
      e.promise = null;
      if (im) {
        e.img = im; e.state = 'ready'; e.px = (im.width || im.naturalWidth || 0) * (im.height || im.naturalHeight || 0); e.last = G.now; usedPx += e.px;
        for (const l of e.looks) l.img = im;
        if (!e.looks.size && !e.hold) { evict(e); store.delete(e.path); } else trimStore();
      } else { e.state = 'failed'; e.failAt = G.now; e.fails++; }
      return e;
    }, () => { e.promise = null; e.state = 'failed'; e.failAt = G.now; e.fails++; return e; });
    return e.promise;
  }
  function trimStore() {
    const budget = G.memBudget; if (!budget || usedPx <= budget) return;
    const pinned = new Set();
    for (const sp of G.sprites) { const l = sp.looks[sp.lookIdx]; if (l && l.path) pinned.add(l.path); }
    const cand = []; for (const e of store.values()) if (e.state === 'ready' && !e.hold && !pinned.has(e.path)) cand.push(e);
    cand.sort((a, b) => a.last - b.last);
    for (const e of cand) { if (usedPx <= budget) break; evict(e); }
  }
  function dropEntries(keep) { // al cambiar de escena: fuera todo lo que la nueva no usa
    for (const [p, e] of Array.from(store)) { if (keep.has(p) || e.hold) continue; if (e.state === 'ready') evict(e); if (e.state !== 'loading') store.delete(p); }
  }
  function attachLooks(sp, sceneName) {
    for (const l of sp.looks) {
      l.path = findFile(l.file, sceneName);
      if (!l.path) { if (l.file) warn('Falta imagen: ' + l.file); continue; }
      const e = entryFor(l.path); e.looks.add(l);
      if (e.state === 'ready') { l.img = e.img; e.last = G.now; }
    }
  }
  function request(l) { // pide la imagen de una apariencia si todavía no está (sin bloquear el juego)
    if (l.img || !l.path) return;
    const e = store.get(l.path); if (!e) return;
    if (e.state === 'ready') { l.img = e.img; return; }
    if (e.state === 'failed' && (e.fails >= 3 || G.now - e.failAt < 3000)) return;
    loadEntry(e);
  }
  // Ahorro de memoria: las imágenes enormes se guardan reducidas (se dibujan al tamaño original)
  function shrink(im) {
    const max = G.render.maxImage, nw = im.naturalWidth, nh = im.naturalHeight;
    if (!max || Math.max(nw, nh) <= max) return im;
    const k = max / Math.max(nw, nh), cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(nw * k)); cv.height = Math.max(1, Math.round(nh * k));
    cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
    cv.naturalWidth = nw; cv.naturalHeight = nh; im.src = '';
    return cv;
  }
  // Si una imagen quedó dañada (no se puede dibujar), se descarta y se vuelve a cargar (máx. 3 intentos)
  function repairLook(l) {
    const e = l.path && store.get(l.path);
    if (!e) { l.img = null; return; }
    if (e.state === 'ready') evict(e);
    e.fails++; if (e.fails < 3) { e.state = 'none'; loadEntry(e); } else e.state = 'failed';
  }
  // Apariencia que se ve ahora: si la nueva todavía no cargó, se sigue mostrando la anterior (sin parpadeos ni tirones)
  const cur = sp => { const l = sp.looks[sp.lookIdx]; if (!l) return null; if (l.img) return l; request(l); return null; };
  const px = document.createElement('canvas'); px.width = px.height = 1;
  const pxc = px.getContext('2d', { willReadFrequently: true });
  function hit(sp, x, y) {
    if (!sp.visible) return false;
    const l = cur(sp); if (!l || !l.img || sp.size <= 0) return false;
    const dx = x - sp.x, dy = -(y - sp.y); // y de pantalla (hacia abajo)
    const a = (sp.rot === 1 ? sp.dir - 90 : 0) * RAD, c = Math.cos(-a), s = Math.sin(-a);
    let cxl = (dx * c - dy * s) / (sp.size / 100); if (sp.rot === 0 && sp.dir < 0) cxl = -cxl;
    const lx = cxl + l.img.naturalWidth / 2;
    const ly = (dx * s + dy * c) / (sp.size / 100) + l.img.naturalHeight / 2;
    if (lx < 0 || ly < 0 || lx >= l.img.naturalWidth || ly >= l.img.naturalHeight) return false;
    const k = (l.img.width || l.img.naturalWidth) / l.img.naturalWidth;
    try { pxc.clearRect(0, 0, 1, 1); pxc.drawImage(l.img, Math.floor(lx * k), Math.floor(ly * k), 1, 1, 0, 0, 1, 1); return pxc.getImageData(0, 0, 1, 1).data[3] > 0; }
    catch { return true; }
  }
  function tap(x, y, skip) {
    // "al tocar la pantalla": cualquier toque
    for (const sp of G.sprites.slice()) for (const s of sp.scripts) if (s.def.type === 'WhenTouchDownScript') startScript(s);
    // Como Catroid: el objeto más alto que reciba el toque y tenga bloque "al tocar" lo atiende;
    // si no lo tiene, el toque pasa al objeto de abajo.
    for (let i = G.sprites.length - 1; i >= 0; i--) {
      const sp = G.sprites[i], ss = sp.scripts.filter(s => s.def.type === 'WhenScript');
      if (ss.length && hit(sp, x, y)) { if (!skip || !skip.has(sp)) for (const s of ss) startScript(s); return; }
    }
  }
  // Máscara de transparencia reducida (máx. 128 px) para colisiones rápidas
  function maskOf(l) {
    if (l.mask !== undefined) return l.mask;
    if (!l.img) return null;
    const iw = l.img.naturalWidth, ih = l.img.naturalHeight, k = Math.max(1, Math.max(iw, ih) / 128);
    const w = Math.max(1, Math.round(iw / k)), h = Math.max(1, Math.round(ih / k));
    try {
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(l.img, 0, 0, w, h);
      const d = x.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h), cells = [];
      for (let i = 0; i < w * h; i++) if (d[i * 4 + 3] > 10) { a[i] = 1; cells.push(i); }
      l.mask = { w, h, a, cells, iw, ih };
    } catch (e) { l.mask = null; }
    return l.mask;
  }
  function collides(A, B) {
    if (A === B || A.size <= 0 || B.size <= 0) return false;
    if (!A.visible || !B.visible || A.trans >= 100 || B.trans >= 100) return false; // ocultos o 100 % transparentes no colisionan
    const la = cur(A), lb = cur(B); if (!la || !lb || !la.img || !lb.img) return false;
    const ra = Math.hypot(la.img.naturalWidth, la.img.naturalHeight) / 2 * A.size / 100;
    const rb = Math.hypot(lb.img.naturalWidth, lb.img.naturalHeight) / 2 * B.size / 100;
    if (Math.hypot(A.x - B.x, A.y - B.y) > ra + rb) return false;
    const ma = maskOf(la), mb = maskOf(lb); if (!ma || !mb) return true;
    const aa = (A.rot === 1 ? A.dir - 90 : 0) * RAD, ca = Math.cos(aa), sa = Math.sin(aa), flA = A.rot === 0 && A.dir < 0 ? -1 : 1;
    const ab = -(B.rot === 1 ? B.dir - 90 : 0) * RAD, cb = Math.cos(ab), sb = Math.sin(ab), flB = B.rot === 0 && B.dir < 0 ? -1 : 1;
    const sA = A.size / 100, sB = B.size / 100, stride = Math.max(1, Math.ceil(ma.cells.length / 3000));
    for (let n = 0; n < ma.cells.length; n += stride) {
      const c = ma.cells[n], ix = c % ma.w, iy = (c / ma.w) | 0;
      const px = flA * ((ix + 0.5) / ma.w - 0.5) * ma.iw * sA, py = ((iy + 0.5) / ma.h - 0.5) * ma.ih * sA;
      const x = A.x + px * ca - py * sa, y = A.y - (px * sa + py * ca);     // posición en el escenario
      const dx = x - B.x, dy = -(y - B.y);
      const lx = flB * (dx * cb - dy * sb) / sB / mb.iw * mb.w + mb.w / 2, ly = (dx * sb + dy * cb) / sB / mb.ih * mb.h + mb.h / 2;
      if (lx >= 0 && ly >= 0 && lx < mb.w && ly < mb.h && mb.a[(ly | 0) * mb.w + (lx | 0)]) return true;
    }
    return false;
  }
  function collidesWithName(sp, name) {
    if (!sp) return false;
    const n = String(name).replace(/\s*\(collision\)\s*$/i, '');
    if (/^(anything|any|todo)$/i.test(n.trim())) return G.sprites.some(o => o !== sp && collides(sp, o));
    let found = G.sprites.filter(o => o.name === n);
    if (!found.length) found = G.sprites.filter(o => o.name.trim() === n.trim());
    for (const o of found) if (collides(sp, o)) return true;
    return false;
  }
  const collTarget = msg => { const p = String(msg).split('<->'); return (p.length > 1 ? p[1] : p[0]).trim(); };

  // ---------- física aproximada (cuerpos DYNAMIC / FIXED) ----------
  function solidHit(s) {
    for (const o of G.sprites) if (o !== s && (o.ph.type === 'FIXED' || o.ph.type === 'DYNAMIC') && collides(s, o)) return o;
    return null;
  }
  // "Cuando hay una colisión física con…" solo cuenta entre objetos FÍSICOS (dinámico/fijo, y al menos uno dinámico).
  // Antes se disparaba con cualquier traslape (por ejemplo objetos sin física que se cruzan), y eso sumaba puntos de más.
  const isPhys = o => o.ph.type === 'DYNAMIC' || o.ph.type === 'FIXED';
  const canCollide = (a, b) => isPhys(a) && isPhys(b) && (a.ph.type === 'DYNAMIC' || b.ph.type === 'DYNAMIC');
  function physCollidesWithName(sp, target) {
    if (!sp || !isPhys(sp)) return false;
    const t = String(target).trim(), anyT = /^(anything|any|todo)$/i.test(t);
    for (const o of G.sprites) { if (o === sp || !canCollide(sp, o)) continue; if (!anyT && o.name.trim() !== t) continue; if (collides(sp, o)) return true; }
    return false;
  }
  let contactsNow = new Set();
  function contact(a, b) { // inicio de contacto (como BeginContact de Box2D): una sola vez hasta que se separen
    const key = a.id < b.id ? a.id * 1e6 + b.id : b.id * 1e6 + a.id; contactsNow.add(key);
    if (G.contacts.has(key)) return;
    const t = G.now;
    for (const [x, y] of [[a, b], [b, a]]) for (const sc of x.scripts) if (sc.def.type === 'CollisionScript') {
      const m = collTarget(sc.def.msg).trim();
      if ((/^(anything|any|todo)$/i.test(m) || m === y.name.trim()) && (!sc.last || t - sc.last > 120)) { sc.last = t; startScript(sc); }
    }
  }
  function physicsStep(dt) {
    contactsNow = new Set();
    for (const s of G.sprites) {
      const p = s.ph;
      if (p.rot) s.dir = normDir(s.dir + p.rot * dt);
      if (p.type !== 'DYNAMIC') continue;
      p.vx += G.gravity.x * PX_PER_M * dt; p.vy += G.gravity.y * PX_PER_M * dt;
      let ox = s.x; s.x += p.vx * dt;
      let o = solidHit(s);
      if (o) { contact(s, o); if (Math.abs(p.vx) > 5) bounced(s, o); s.x = ox; p.vx = -p.vx * Math.max(p.bounce, o.ph.bounce); if (Math.abs(p.vx) < 5) p.vx = 0; }
      let oy = s.y; s.y += p.vy * dt;
      o = solidHit(s);
      if (o) {
        contact(s, o); if (Math.abs(p.vy) > 5) bounced(s, o);
        s.y = oy; p.vy = -p.vy * Math.max(p.bounce, o.ph.bounce); if (Math.abs(p.vy) < 5) p.vy = 0;
        p.vx *= Math.max(0, 1 - Math.min(1, (p.friction + o.ph.friction) / 2) * dt * 5);
      }
    }
    G.contacts = contactsNow;
  }

  let ctx, canvas;
  let lastCamX = 0, lastCamY = 0, lastOrder = 0, lastTextSig = '', lastFull = 0, partialSince = false;
  const boxOf = (sp, l) => { // círculo que cubre al objeto (gire como gire), en coordenadas del escenario
    const r = Math.hypot(l.img.naturalWidth, l.img.naturalHeight) / 2 * (sp.size / 100) + 2, cx = G.W / 2 + sp.x - G.cam.x, cy = G.H / 2 - sp.y + G.cam.y;
    return [cx - r, cy - r, cx + r, cy + r];
  };
  function paintSprite(sp, l) {
    ctx.save();
    try {
      ctx.translate(G.W / 2 + sp.x - G.cam.x, G.H / 2 - sp.y + G.cam.y); applyRot(ctx, sp);
      const s = sp.size / 100; ctx.scale(s, s); ctx.globalAlpha = Math.min(1, 1 - sp.trans / 100);
      const filters = [];
      if (sp.bright !== 100) filters.push('brightness(' + Math.max(0, sp.bright) + '%)');
      if (sp.color % 200 !== 0) filters.push('hue-rotate(' + (((sp.color % 200) + 200) % 200 / 200 * 360) + 'deg)');
      if (filters.length) ctx.filter = filters.join(' ');
      ctx.drawImage(l.img, -l.img.naturalWidth / 2, -l.img.naturalHeight / 2, l.img.naturalWidth, l.img.naturalHeight);
    } catch (e) {
      warn('No se pudo dibujar "' + sp.name + '" (' + (l.file || '?') + '): ' + (e && e.message));
      repairLook(l); // la imagen quedó inservible: se vuelve a cargar y el resto del juego sigue
    } finally { ctx.restore(); }
  }
  // Solo se redibuja lo que cambió: si nada se movió no se dibuja nada (ahorra CPU y batería); si algo cambió, solo su zona.
  function draw() {
    const S = G.render.scale;
    if (G.loading) {
      ctx.setTransform(S, 0, 0, S, 0, 0); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, G.W, G.H);
      ctx.fillStyle = '#fff'; ctx.font = 'bold 56px Segoe UI, Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('Cargando…', G.W / 2, G.H / 2); ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      G.fullNext = true; return;
    }
    let full = G.fullNext || G.render.dirty === false || (partialSince && G.now - lastFull > 15000); // red de seguridad: un redibujado completo cada 15 s si hubo parciales
    let L = 1e9, T = 1e9, R = -1e9, B = -1e9, any = false, order = 0;
    const ext = b => { if (b[0] < L) L = b[0]; if (b[1] < T) T = b[1]; if (b[2] > R) R = b[2]; if (b[3] > B) B = b[3]; any = true; };
    if (G.cam.x !== lastCamX || G.cam.y !== lastCamY) { lastCamX = G.cam.x; lastCamY = G.cam.y; full = true; for (const s0 of G.sprites) if (s0.pv) s0.pv.stale = true; } // la cámara se movió: todo se redibuja
    for (const sp of G.sprites) {
      order = (Math.imul(order, 31) + sp.id) | 0;
      let l = null;
      if (sp.visible && sp.size > 0 && sp.trans < 100) { l = cur(sp); if (l && !l.img) l = null; }
      const pv = sp.pv;
      if (l) {
        if (!pv || pv.stale || pv.x !== sp.x || pv.y !== sp.y || pv.size !== sp.size || pv.dir !== sp.dir || pv.trans !== sp.trans || pv.bright !== sp.bright || pv.color !== sp.color || pv.rot !== sp.rot || pv.img !== l.img) {
          const nb = boxOf(sp, l); if (pv) ext(pv.box); ext(nb);
          if (pv) { pv.x = sp.x; pv.y = sp.y; pv.size = sp.size; pv.dir = sp.dir; pv.trans = sp.trans; pv.bright = sp.bright; pv.color = sp.color; pv.rot = sp.rot; pv.img = l.img; pv.box = nb; pv.look = l; pv.stale = false; }
          else sp.pv = { x: sp.x, y: sp.y, size: sp.size, dir: sp.dir, trans: sp.trans, bright: sp.bright, color: sp.color, rot: sp.rot, img: l.img, box: nb, look: l };
        } else pv.look = l;
      } else if (pv) { ext(pv.box); sp.pv = null; }
    }
    for (const pb of penBoxes) ext(pb); penBoxes.length = 0;
    for (const sp2 of G.sprites) if (sp2.bubble) { full = true; break; } // mientras hay una burbuja visible se redibuja todo (son pocas)
    if (order !== lastOrder) { full = true; lastOrder = order; }
    let tsig = ''; for (const k in G.texts) { const t = G.texts[k]; tsig += k + '=' + (t.owner ? getVar(t.owner, k) : G.vars[k]) + '@' + t.x + ',' + t.y + ',' + t.size + ',' + t.color + ',' + t.align + ';'; }
    if (tsig !== lastTextSig) { full = true; lastTextSig = tsig; }
    if (!full && !any) return; // nada cambió
    let x0 = 0, y0 = 0, x1 = 0, y1 = 0, part = false;
    if (!full) {
      const cw = canvas.width, ch = canvas.height;
      x0 = Math.max(0, Math.floor(L * S) - 2); y0 = Math.max(0, Math.floor(T * S) - 2); x1 = Math.min(cw, Math.ceil(R * S) + 2); y1 = Math.min(ch, Math.ceil(B * S) + 2);
      if (x1 <= x0 || y1 <= y0) return; // el cambio quedó fuera de la pantalla
      if ((x1 - x0) * (y1 - y0) > 0.6 * cw * ch) full = true; else part = true;
    }
    ctx.setTransform(S, 0, 0, S, 0, 0);
    ctx.imageSmoothingEnabled = G.render.smooth !== 'off'; ctx.imageSmoothingQuality = G.render.smooth === 'high' ? 'high' : 'low';
    const rx0 = x0 / S, ry0 = y0 / S, rx1 = x1 / S, ry1 = y1 / S;
    if (part) { ctx.save(); ctx.beginPath(); ctx.rect(rx0, ry0, rx1 - rx0, ry1 - ry0); ctx.clip(); }
    ctx.clearRect(0, 0, G.W, G.H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, G.W, G.H);
    let penDone = false; const drawPen = () => { penDone = true; if (penUsed && penCv) { try { ctx.drawImage(penCv, -G.cam.x, G.cam.y, G.W, G.H); } catch (e) {} } };
    for (let gi = 0; gi < G.sprites.length; gi++) { // la pluma se dibuja sobre el fondo y debajo de los demás objetos
      const sp = G.sprites[gi], pv = sp.pv;
      if (pv && !(part && (pv.box[2] < rx0 || pv.box[0] > rx1 || pv.box[3] < ry0 || pv.box[1] > ry1))) paintSprite(sp, pv.look);
      if (gi === 0) drawPen();
    }
    if (!penDone) drawPen();
    paintBubbles();
    ctx.textBaseline = 'top'; ctx.lineWidth = 6; ctx.strokeStyle = '#000';
    for (const k in G.texts) {
      const t = G.texts[k], s = String(t.owner ? getVar(t.owner, k) : (G.vars[k] !== undefined ? G.vars[k] : 0)), x = G.W / 2 + t.x, y = G.H / 2 - t.y;
      ctx.font = 'bold ' + Math.round(56 * (t.size || 100) / 100) + 'px Segoe UI, Arial'; ctx.fillStyle = t.color || '#fff'; ctx.textAlign = t.align === 1 ? 'center' : t.align === 2 ? 'right' : 'left';
      ctx.strokeText(s, x, y); ctx.fillText(s, x, y);
    }
    ctx.textAlign = 'left';
    if (part) ctx.restore();
    G.fullNext = false;
    if (full) { lastFull = G.now; partialSince = false; } else partialSince = true;
  }

  // ---------- audio, voz y video ----------
  function setVolume(v) {
    G.volume = Math.max(0, Math.min(100, v));
    for (const k in G.sounds) G.sounds[k].volume = G.volume / 100;
  }
  function playSound(file, at) {
    if (!file) return null;
    let a = G.sounds[file];
    if (!a) { const p = findFile(file, G.sceneName); if (!p) { warn('Falta sonido: ' + file); return null; } a = new Audio(G.api.fileUrl(p)); G.sounds[file] = a; }
    a.onended = a.onerror = a.onpause = null;
    a.volume = G.volume / 100;
    try { a.currentTime = at || 0; } catch {}
    a.play().catch(() => {}); return a;
  }
  function stopAllSounds() { for (const k in G.sounds) { const a = G.sounds[k]; a.onended = a.onerror = a.onpause = null; a.pause(); try { a.removeAttribute('src'); a.load(); } catch (e) {} } G.sounds = {}; }
  function speak(text) {
    return new Promise(res => {
      try {
        const u = new SpeechSynthesisUtterance(text); u.volume = G.volume / 100;
        u.onend = u.onerror = () => res(); speechSynthesis.speak(u);
      } catch (e) { res(); }
    });
  }
  // Los videos que el navegador no deja arrancar solos empiezan con el siguiente toque o tecla
  const pendingPlay = new Set(); let gestureHooked = false;
  function hookGesture() {
    if (gestureHooked) return; gestureHooked = true;
    const go = () => { for (const v of Array.from(pendingPlay)) { try { v.play().then(() => pendingPlay.delete(v)).catch(() => {}); } catch (e) {} } };
    addEventListener('pointerdown', go, true); addEventListener('keydown', go, true);
  }
  function tryPlay(v) {
    try { const pr = v.play(); if (pr && pr.catch) pr.catch(e => { warn('Video "' + v.__n + '": no arrancó solo (' + (e && e.name) + '); empieza con el próximo toque'); pendingPlay.add(v); hookGesture(); }); } catch (e) {}
  }
  function fetchBlob(url) { // copia del video en memoria (por si el servidor local de la app no entrega bien el archivo)
    return new Promise((res, rej) => { const x = new XMLHttpRequest(); x.open('GET', url); x.responseType = 'blob';
      x.onload = () => ((x.status === 200 || x.status === 0) && x.response) ? res(x.response) : rej(new Error('HTTP ' + x.status)); x.onerror = () => rej(new Error('no se pudo leer')); x.send(); });
  }
  function dropVideo(v) { try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) {} try { if (v.__blob) URL.revokeObjectURL(v.__blob); } catch (e) {} try { v.remove(); } catch (e) {} pendingPlay.delete(v); }
  function createVideo(b, sp) {
    const F = (k, i) => ev(b.f[k] !== undefined ? b.f[k] : b.fl[i || 0], sp), name = String(F('NAME')).trim(), file = String(F('FILE'));
    const old = G.videos[name]; if (old) dropVideo(old);
    const p = findFile(file, G.sceneName); if (!p) { warn('Falta video: ' + file); return; }
    const v = document.createElement('video'), w = num(F('WIDTH')), h = num(F('HEIGHT')), url = G.api.fileUrl(p);
    v.__n = name; v.preload = 'auto'; v.loop = truthy(F('LOOPED')); v.controls = truthy(F('CONTROLS')); v.playsInline = true; v.autoplay = true;
    try { v.setAttribute('playsinline', ''); } catch (e) {}
    let tried = false;
    v.addEventListener('error', () => {
      const er = v.error;
      warn('Video "' + name + '" no cargó (' + (er ? 'código ' + er.code + (er.message ? ' ' + er.message : '') : 'sin detalle') + '): ' + p);
      if (!tried) {
        tried = true;
        fetchBlob(url).then(bl => { if (G.videos[name] !== v) return; v.__blob = URL.createObjectURL(bl); v.src = v.__blob; v.load(); tryPlay(v); })
          .catch(e2 => { warn('Video "' + name + '": tampoco funcionó con copia en memoria (' + (e2 && e2.message) + ')'); dropVideo(v); });
      } else dropVideo(v); // no dejar un cuadro roto o en blanco encima del juego
    });
    v.addEventListener('loadedmetadata', () => note('Video "' + name + '": ' + v.videoWidth + 'x' + v.videoHeight + ', ' + (v.duration || 0).toFixed(1) + ' s'));
    v.src = url;
    Object.assign(v.style, { width: w + 'px', height: h + 'px', objectFit: 'fill', left: (G.W / 2 + num(F('POSX')) - w / 2) + 'px', top: (G.H / 2 - num(F('POSY')) - h / 2) + 'px' });
    document.getElementById('videos').appendChild(v); G.videos[name] = v; tryPlay(v);
  }
  function clearMedia() {
    stopAllSounds();
    try { speechSynthesis.cancel(); } catch (e) {}
    for (const k in G.videos) dropVideo(G.videos[k]); G.videos = {};
  }

  // ---------- escenas ----------
  function requestScene(name) { note('Cambio de escena -> "' + name + '"'); G.pending = name; for (const r of G.runs) r.dead = true; }
  function findScene(name) { return G.scenes.find(s => s.name === name) || G.scenes.find(s => s.name.trim() === String(name).trim()) || null; }
  // ---------- análisis de la escena: qué imágenes hacen falta primero y a qué escenas se puede ir ----------
  const BLOCKING = new Set(['WaitBrick', 'WaitUntilBrick', 'ForeverBrick', 'RepeatBrick', 'RepeatUntilBrick', 'BroadcastWaitBrick', 'SceneTransitionBrick', 'SceneStartBrick',
    'IfLogicBeginBrick', 'IfThenLogicBeginBrick', 'PlaySoundAndWaitBrick', 'SpeakAndWaitBrick', 'GlideToBrick']);
  function lookIdxOf(sp, b) {
    if (b.lookIdx != null && sp.looks[b.lookIdx] && (!b.lookFile || sp.looks[b.lookIdx].file === b.lookFile)) return b.lookIdx;
    return b.lookFile ? sp.looks.findIndex(l => l.file === b.lookFile) : -1;
  }
  function lookIndexFor(od, b) { // misma regla que setLook
    if (b.lookIdx != null && od.looks[b.lookIdx] && (!b.lookFile || od.looks[b.lookIdx].file === b.lookFile)) return b.lookIdx;
    return b.lookFile ? od.looks.findIndex(l => l.file === b.lookFile) : -1;
  }
  function firstLooks(sc) { // [objeto, apariencia]: la primera de cada objeto + las que sus primeros bloques activan
    const out = [];
    sc.objs.forEach((od, i) => {
      if (od.looks.length) out.push([i, 0]);
      for (const s of od.scripts) {
        if (s.type !== 'StartScript') continue;
        for (const b of s.bricks) {
          if (BLOCKING.has(b.type)) break;
          if (b.type === 'SetLookBrick') { const k = lookIndexFor(od, b); if (k >= 0) out.push([i, k]); }
          else if (b.type === 'SetBackgroundBrick' && sc.objs[0]) { const k = lookIndexFor(sc.objs[0], b); if (k >= 0) out.push([0, k]); }
          else if (b.type === 'SetLookByIndexBrick' && b.fl[0] && b.fl[0].type === 'NUMBER') { const k = Math.floor(num(b.fl[0].value)) - 1; if (k >= 0 && k < od.looks.length) out.push([i, k]); }
        }
      }
    });
    return out;
  }
  function nextScenes(sc) { // escenas a las que esta puede saltar (máx. 3)
    if (sc._next) return sc._next;
    const seen = new Set();
    const walk = l => { for (const b of l || []) { if ((b.type === 'SceneTransitionBrick' || b.type === 'SceneStartBrick') && b.scene) seen.add(b.scene); walk(b.loop); walk(b.ifB); walk(b.elseB); } };
    for (const od of sc.objs) for (const s of od.scripts) walk(s.bricks);
    seen.delete(sc.name); return (sc._next = Array.from(seen).slice(0, 3));
  }
  function lookPriority(sc) { // archivos que usan los bloques de "cambiar apariencia" y objetos con animación
    if (sc._pri) return sc._pri;
    const files = new Set(), anim = new Set();
    const walk = (od, l) => { for (const b of l || []) { if (b.lookFile) files.add(b.lookFile); if (b.type === 'NextLookBrick' || b.type === 'PreviousLookBrick' || b.type === 'SetLookByIndexBrick') anim.add(od.name); walk(od, b.loop); walk(od, b.ifB); walk(od, b.elseB); } };
    for (const od of sc.objs) for (const s of od.scripts) walk(od, s.bricks);
    return (sc._pri = { files, anim });
  }
  const idle = ms => new Promise(r => setTimeout(r, ms));

  // Trabajo en segundo plano (no estorba al juego): primero lo que mostrará la escena siguiente, luego el resto de esta
  async function idleWork(tok, sc) {
    await idle(200);
    for (const nm of nextScenes(sc)) {
      const ns = findScene(nm); if (!ns) continue;
      for (const [i, k] of firstLooks(ns)) {
        if (tok !== G.bgTok) return;
        if (G.memBudget && usedPx > G.memBudget * 0.6) break; // la precarga nunca se come toda la memoria
        const l = ns.objs[i].looks[k], p = l && findFile(l.file, ns.name); if (!p) continue;
        const e = entryFor(p); e.hold = true;
        if (e.state === 'none') { await loadEntry(e); await idle(20); }
      }
    }
    const pri = lookPriority(sc), rest = [];
    for (const sp of G.sprites) for (const l of sp.looks) if (l.path && !l.img) rest.push([pri.files.has(l.file) || pri.anim.has(sp.name) ? 0 : 1, l]);
    rest.sort((a, b) => a[0] - b[0]);
    for (const [, l] of rest) {
      if (tok !== G.bgTok) return;
      if (G.memBudget && usedPx >= G.memBudget * 0.85) break;
      const e = store.get(l.path); if (e && e.state === 'none') { await loadEntry(e); await idle(25); }
    }
  }

  // Durante la pantalla "Cargando…": deja lista la primera imagen de cada objeto de las escenas a las que se puede ir (máx. 2 escenas, máx. 3 s)
  async function preloadNext(sc) {
    const jobs = [];
    for (const nm of nextScenes(sc).slice(0, 2)) {
      const ns = findScene(nm); if (!ns) continue;
      for (const od of ns.objs) {
        const l = od.looks[0], p = l && findFile(l.file, ns.name); if (!p || usedPx > 100e6) continue;
        const e = entryFor(p); e.hold = true; if (e.state === 'none') jobs.push(loadEntry(e));
      }
    }
    if (jobs.length) await Promise.race([Promise.all(jobs), idle(3000)]);
  }
  // Libera la escena anterior: detiene todo lo que quedaba corriendo y suelta sus apariencias
  function freeScene() {
    for (const r of G.runs) r.dead = true;
    const ws = G.waiters; G.waiters = []; for (const w of ws) w.res(); // despierta scripts dormidos para que terminen
    for (const sp of G.sprites) {
      for (const l of sp.looks) { l.mask = undefined; const e = l.path && store.get(l.path); if (e) e.looks.delete(l); l.img = null; }
      for (const s of sp.scripts) s.cur = null;
    }
    G.sprites = []; G.background = null;
  }
  async function loadScene(name) {
    const sc = findScene(name);
    if (!sc) { warn('Escena inexistente: ' + name); return; }
    G.loading = true; const tok = ++G.bgTok;
    try {
      for (const r of G.runs) r.dead = true;
      const keep = new Set(); for (const od of sc.objs) for (const l of od.looks) { const p = findFile(l.file, sc.name); if (p) keep.add(p); }
      for (const e of store.values()) e.hold = false; // lo que se había precargado ya se usa (o se descarta ahora)
      freeScene();
      if (G.render.optimize) dropEntries(keep);
      G.runs.clear(); G.conds = []; G.texts = {}; if (penCx) penCx.clearRect(0, 0, G.W, G.H); penUsed = false; penBoxes.length = 0; tempo = 60; instrument = 'sine'; G.cam = { x: 0, y: 0, target: null, fh: 0, fv: 0 }; G.gravity = { x: 0, y: -10 }; clearMedia();
      G.sceneName = sc.name; G.sprites = sc.objs.map(makeSprite); G.background = G.sprites[0] || null;
      for (const sp of G.sprites) attachLooks(sp, sc.name);
      const must = G.lazy ? firstLooks(sc).map(([i, k]) => G.sprites[i].looks[k]) : [].concat(...G.sprites.map(sp => sp.looks));
      await Promise.all(must.map(l => { const e = l.path && store.get(l.path); return e ? loadEntry(e) : null; }));
      for (const sp of G.sprites) cur(sp);
      if (!G.lazy && G.render.preload !== false) await preloadNext(sc); // la escena siguiente se precarga ahora, durante "Cargando…" (no mientras se juega)
    } catch (e) { console.error(e); warn('Error al cargar la escena "' + name + '": ' + (e && e.message)); }
    { let ok = 0, tot = 0, bad = 0; for (const sp of G.sprites) for (const l of sp.looks) { tot++; if (l.img) ok++; else if (!l.path) bad++; }
      note('Escena "' + G.sceneName + '": ' + G.sprites.length + ' objetos, ' + ok + '/' + tot + ' apariencias listas al inicio (el resto carga en segundo plano)' + (bad ? ', ' + bad + ' SIN archivo' : '') + ', memoria de imágenes ~' + Math.round(usedPx / 1e6) + ' Mpx'); }
    G.fullNext = true; G.t0 = G.now; G.loading = false; // pase lo que pase, el juego sigue
    for (const sp of G.sprites) for (const s of sp.scripts) {
      if (s.def.type === 'StartScript') startScript(s);
      else if (s.def.type === 'WhenConditionScript' || s.def.type === 'CollisionScript') G.conds.push(s);
    }
    if (G.lazy && tok === G.bgTok) idleWork(tok, sc).catch(e => warn('Carga en segundo plano: ' + (e && e.message)));
  }

  // ---------- bucle principal ----------
  // Cada parte del fotograma va protegida: un error ya no detiene el juego (antes quedaba la pantalla en blanco para siempre)
  const guard = (name, f) => { try { f(); } catch (e) { warn('Error en ' + name + ': ' + (e && e.message) + ((e && e.stack) ? ' @' + String(e.stack).split('\n')[1] : '')); } };
  let stallN = 0, tickN = 0, loadingSince = 0;
  function sceneState() {
    let vis = 0, hid = 0, transp = 0, nolook = 0;
    for (const sp of G.sprites) { if (!sp.visible) hid++; else if (sp.trans >= 100) transp++; else if (!cur(sp)) nolook++; else vis++; }
    return G.sprites.length + ' objetos (' + vis + ' visibles, ' + hid + ' ocultos, ' + transp + ' transparentes, ' + nolook + ' sin imagen), ' + G.runs.size + ' scripts activos, ' + G.waiters.length + ' esperas';
  }
  function watchdog() { // si la escena queda vacía y sin actividad, lo deja escrito (para poder encontrar la causa)
    if (G.loading) { if (!loadingSince) loadingSince = G.now; else if (G.now - loadingSince > 25000) { warn('AVISO: "' + G.sceneName + '" lleva más de 25 s cargando'); } return; }
    loadingSince = 0;
    let drawn = 0; for (const sp of G.sprites) if (sp.pv) drawn++;
    if (!drawn && !G.runs.size && !G.waiters.length) { if (++stallN === 3) note('AVISO: la escena "' + G.sceneName + '" está vacía y sin actividad (pantalla en blanco): ' + sceneState()); } else stallN = 0;
  }
  function tick(ts) {
    if (G.stepMs) { // la pantalla puede ir a 90/120 Hz: la lógica sigue siendo de 60 pasos/s (antes iba a 45 en pantallas de 90 Hz)
      const d = G.lastTs ? ts - G.lastTs : G.stepMs; G.lastTs = ts;
      G.acc = Math.min(G.acc + d, G.stepMs * 2.5);
      if (G.acc < G.stepMs - 1.5) { requestAnimationFrame(tick); return; }
      G.acc -= G.stepMs;
    }
    G.lastTick = ts; if (++tickN % 90 === 0) guard('el vigilante', watchdog);
    const dt = Math.min(0.05, Math.max(0, (ts - (G.last || ts)) / 1000)); G.last = ts; G.now = ts;
    if (!G.loading && dt > 0) guard('la física', () => physicsStep(dt));
    guard('el movimiento', motionStep); guard('la cámara', camStep);
    guard('la pluma', penStep);
    guard('el dibujo', draw);
    guard('las escenas', () => {
      if (G.pending !== null && !G.loading) { const n = G.pending; G.pending = null; loadScene(n).catch(e => { G.loading = false; warn('Error al cambiar de escena: ' + (e && e.message)); }); }
      else if (!G.loading) {
        for (const s of G.conds) {
          let v = false;
          try { v = s.def.type === 'CollisionScript' ? physCollidesWithName(s.sprite, collTarget(s.def.msg)) : truthy(ev(s.def.cond, s.sprite)); } catch (e) { warn('Error en una condición: ' + (e && e.message)); }
          if (v && !s.prev) { if (s.def.type === 'CollisionScript') { if (!s.last || G.now - s.last > 120) { s.last = G.now; startScript(s); } } else startScript(s); } s.prev = v;
        }
      }
    });
    if (G.touch.upReq) { G.touch.down = false; G.touch.upReq = false; }
    guard('las esperas', () => { // esto SIEMPRE corre: si no, todos los "esperar" del juego se quedarían congelados
      const due = [], rest = [];
      for (const w of G.waiters) (w.t <= G.now ? due : rest).push(w);
      G.waiters = rest; for (const w of due) { try { w.res(); } catch (e) {} }
    });
    requestAnimationFrame(tick);
  }
  function fit() {
    const wrap = document.getElementById('wrap'), s = Math.min(innerWidth / G.W, innerHeight / G.H);
    wrap.style.transform = 'translate(' + (innerWidth - G.W * s) / 2 + 'px,' + (innerHeight - G.H * s) / 2 + 'px) scale(' + s + ')';
  }
  function bindInput() {
    const wrap = document.getElementById('wrap');
    const pos = e => { const r = wrap.getBoundingClientRect(); G.touch.x = (e.clientX - r.left) / r.width * G.W - G.W / 2 + G.cam.x; G.touch.y = G.H / 2 - (e.clientY - r.top) / r.height * G.H + G.cam.y; };
    // Controles asignados a teclado/mouse (se suman al toque; la pantalla táctil sigue igual)
    const binds = (G.game.inputs || []).filter(i => i.bind);
    const fire = (it, down, trig) => {
      if (G.loading) return;
      if (it.screen) { // "pantalla tocada" en cualquier parte
        if (down) { G.touch.down = true; for (const sp of G.sprites.slice()) for (const s of sp.scripts) if (s.def.type === 'WhenTouchDownScript') startScript(s); }
        else G.touch.upReq = true;
        return;
      }
      const sp = G.sprites.find(o => o.name === it.obj); if (!sp) return;
      if (down && !sp.visible) return; // objeto oculto: su tecla queda bloqueada hasta que se vuelva a mostrar (igual que el toque)
      if (it.hold) sp.keyHold = down;
      if (down && it.tap) { for (const s of sp.scripts) if (s.def.type === 'WhenScript') startScript(s); if (trig) trig.add(sp); }
    };
    addEventListener('keydown', e => { if (e.code === 'F9') toggleLog(); });
    let cornerTaps = [];
    const active = it => !it.scene || it.scene === G.sceneName;
    const heldKeys = new Set();
    addEventListener('keydown', e => {
      const m = binds.filter(i => i.bind.type === 'key' && i.bind.code === e.code); if (!m.length) return;
      e.preventDefault(); if (e.repeat || heldKeys.has(e.code)) return; heldKeys.add(e.code);
      for (const it of m) if (active(it)) fire(it, true);
    });
    addEventListener('keyup', e => {
      const m = binds.filter(i => i.bind.type === 'key' && i.bind.code === e.code); if (!m.length) return;
      heldKeys.delete(e.code); for (const it of m) fire(it, false);
    });
    addEventListener('blur', () => { heldKeys.clear(); for (const it of binds) fire(it, false); });
    if (binds.some(i => i.bind.type === 'mouse')) wrap.addEventListener('contextmenu', e => e.preventDefault());

    wrap.addEventListener('pointerdown', e => {
      pos(e); const trig = new Set();
      if (!G.fingers.has(e.pointerId) && G.fingerList.length < 10) { G.fingers.set(e.pointerId, sxy(e)); G.fingerList.push(e.pointerId); }
      if (G.touch.x - G.cam.x < -G.W / 2 + 220 && G.touch.y - G.cam.y > G.H / 2 - 220) { const t = Date.now(); cornerTaps = cornerTaps.filter(x => t - x < 2500); cornerTaps.push(t); if (cornerTaps.length >= 5) { cornerTaps = []; toggleLog(); } }
      if (e.pointerType === 'mouse') for (const it of binds) if (it.bind.type === 'mouse' && it.bind.button === e.button && active(it)) fire(it, true, trig);
      // el botón izquierdo del mouse y el toque siguen funcionando como siempre
      if (e.pointerType !== 'mouse' || e.button === 0) { G.touch.down = true; wrap.setPointerCapture(e.pointerId); if (!G.loading) tap(G.touch.x, G.touch.y, trig); }
    });
    const sxy = e => { const r = wrap.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * G.W - G.W / 2 + G.cam.x, y: G.H / 2 - (e.clientY - r.top) / r.height * G.H + G.cam.y }; };
    wrap.addEventListener('pointermove', e => { pos(e); if (G.fingers.has(e.pointerId)) G.fingers.set(e.pointerId, sxy(e)); });
    const up = e => {
      if (G.fingers.has(e.pointerId)) { G.fingers.delete(e.pointerId); G.fingerList = G.fingerList.filter(id => id !== e.pointerId); }
      if (e.pointerType === 'mouse') for (const it of binds) if (it.bind.type === 'mouse' && it.bind.button === e.button) fire(it, false);
      if (e.pointerType !== 'mouse' || e.button === 0) G.touch.upReq = true;
    };
    wrap.addEventListener('pointerup', up); wrap.addEventListener('pointercancel', up);
  }

  async function start(game, api) {
    G.api = api; G.game = game;
    G.W = game.meta.W || 2400; G.H = game.meta.H || 1080;
    G.scenes = game.scenes;
    if (!G.scenes.length) throw new Error('El juego no tiene escenas');
    const R = game.meta.render || {};
    G.render = { preload: R.preload !== false, dirty: R.dirty !== false, scale: Math.min(3, Math.max(0.25, R.scale || 1)), smooth: R.smooth || 'high', fps: R.fps === undefined ? 60 : R.fps, optimize: R.optimize !== false, maxImage: 0 }; // las imágenes se cargan siempre a su tamaño original
    G.stepMs = G.render.fps > 0 ? 1000 / G.render.fps : 0; // fps 0 = un paso por cada fotograma de la pantalla (como Pocket Code en el teléfono) G.acc = G.stepMs; G.lastTs = 0;
    // Tope de memoria para imágenes (en píxeles). Automático: según la memoria del dispositivo (celulares de gama baja = poco)
    G.lazy = G.render.optimize && typeof R.memMB === 'number' && R.memMB !== -1; // por defecto: modo normal (se cargan todas las imágenes de la escena al empezar)
    { const mb = R.memMB; let px;
      if (mb > 0) px = mb * 1e6; else if (mb === -1) px = 0;
      else { const dm = navigator.deviceMemory, android = /Android/i.test(navigator.userAgent || ''); px = android ? (dm ? (dm <= 2 ? 24e6 : dm <= 3 ? 36e6 : dm <= 4 ? 56e6 : 90e6) : 36e6) : 160e6; }
      G.memBudget = G.lazy ? px : 0; }
    window.__lowMem = () => { if (G.memBudget) { G.memBudget = Math.max(6e6, G.memBudget * 0.5); trimStore(); } }; // el sistema avisa que falta memoria
    G.vars = Object.assign({}, game.vars || {}); // valores iniciales de las variables (vida = 100, etc.)
    G.saved = (await api.loadVars()) || {};
    canvas = document.getElementById('c'); canvas.width = Math.round(G.W * G.render.scale); canvas.height = Math.round(G.H * G.render.scale);
    canvas.style.width = G.W + 'px'; canvas.style.height = G.H + 'px'; ctx = canvas.getContext('2d', { alpha: false });
    canvas.addEventListener('contextlost', e => { e.preventDefault(); warn('El dibujo se interrumpió (contexto perdido); se recupera solo'); });
    canvas.addEventListener('contextrestored', () => { ctx = canvas.getContext('2d', { alpha: false }); G.fullNext = true; warn('Dibujo recuperado'); });
    const wrap = document.getElementById('wrap'); wrap.style.width = G.W + 'px'; wrap.style.height = G.H + 'px';
    const vids = document.getElementById('videos'); vids.style.width = G.W + 'px'; vids.style.height = G.H + 'px';
    addEventListener('resize', fit); fit(); bindInput();
    requestAnimationFrame(tick);
    await loadScene(G.scenes[0].name);
  }

  window.CatroEngine = { _t: { reset: () => { for (const e of Array.from(store.values())) if (e.state === 'ready') evict(e); store.clear(); usedPx = 0; }, store, loadEntry, trimStore, nextScenes, firstLooks, cur, draw, usedPx: () => usedPx }, start, G, bindInput, ev, hit, collides, collidesWithName, tap, exec, startScript, broadcast, physicsStep, makeSprite };
})();
