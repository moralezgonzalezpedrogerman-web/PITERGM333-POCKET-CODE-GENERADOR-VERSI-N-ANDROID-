'use strict';
// Crea el "proyecto APK" de un juego: un .zip + un workflow de GitHub que lo compila a APK.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiterApk = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const enc = new TextEncoder();
  const appIdFor = id => 'com.piter.juego.g' + (String(id).split('-').pop().replace(/[^a-z0-9]/g, '') || 'x');

  function workflowYml(o) {
    return 'name: Compilar APK - ' + o.slug + '\n' +
      'on:\n  push:\n  workflow_dispatch:\n' +
      'jobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n' +
      '      - uses: actions/checkout@v4\n' +
      '      - uses: actions/setup-node@v4\n        with:\n          node-version: 20\n' +
      '      - uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: 17\n' +
      '      - name: Descomprimir\n        run: unzip -q "' + o.zipName + '" -d app\n' +
      '      - name: Compilar APK\n        working-directory: app\n        run: |\n' +
      '          npm install --no-audit --no-fund\n          npx cap add android\n          python3 patch_android.py\n          npx cap sync android\n' +
      '          cd android\n          chmod +x gradlew\n          if ! ./gradlew assembleDebug --no-daemon; then\n' +
      '            echo "Fallo con la actividad personalizada; compilando con la estandar"\n            cd ..\n            python3 patch_android.py --default-activity\n' +
      '            cd android && ./gradlew assembleDebug --no-daemon\n          fi\n' +
      '      - name: Nombrar el APK\n        run: cp app/android/app/build/outputs/apk/debug/app-debug.apk "' + o.apkName + '.apk"\n' +
      '      - uses: actions/upload-artifact@v4\n        with:\n          name: ' + o.slug + '-apk\n          path: ' + o.apkName + '.apk\n';
  }

  // o: Z, game, name, slug, version, orientation, fullscreen, icons{48..192:Uint8Array}, iconPng, files{...}, assetEntries[{rel,addTo(w,dest)}]
  async function build(o, progress) {
    const w = new o.Z.ZipWriter(), meta = o.game.meta, appId = appIdFor(meta.id);
    const j = x => enc.encode(JSON.stringify(x, null, 2));
    w.addBytes('package.json', j({ name: o.slug + '-apk', version: o.version || '1.0.0', private: true,
      dependencies: { '@capacitor/android': '^6.2.0', '@capacitor/app': '^6.0.0', '@capacitor/core': '^6.2.0' }, devDependencies: { '@capacitor/cli': '^6.2.0' } }));
    w.addBytes('capacitor.config.json', j({ appId, appName: String(o.name).replace(/[<>&"']/g, ''), webDir: 'www', server: { androidScheme: 'https' } }));
    w.addBytes('game-meta.json', j({ orientation: o.orientation || 'auto', fullscreen: o.fullscreen !== false }));
    for (const f of ['patch_android.py', 'MainActivity.java.tmpl']) w.addBytes(f, o.files[f]);
    for (const s in o.icons) w.addBytes('icons/' + s + '.png', o.icons[s]);
    for (const f of ['index.html', 'api.js', 'engine.js', 'app.js']) w.addBytes('www/' + f, o.files[f]);
    w.addBytes('www/game.json', enc.encode(JSON.stringify(o.game)));
    if (o.iconPng) w.addBytes('www/icon.png', o.iconPng);
    let i = 0;
    for (const e of o.assetEntries) {
      await e.addTo(w, 'www/assets/' + e.rel);
      if (progress && ++i % 50 === 0) progress('Copiando archivos del juego… ' + Math.round(i / o.assetEntries.length * 100) + '%');
    }
    return w.finish();
  }
  return { build, workflowYml, appIdFor };
});
