"""Se ejecuta en GitHub despues de 'npx cap add android': pone icono, orientacion y la actividad del juego."""
import json, os, shutil, sys

cfg = json.load(open('capacitor.config.json', encoding='utf-8'))
meta = json.load(open('game-meta.json', encoding='utf-8'))
app_id = cfg['appId']
pkg_dir = os.path.join('android', 'app', 'src', 'main', 'java', *app_id.split('.'))
act = os.path.join(pkg_dir, 'MainActivity.java')

def write_activity(custom):
    os.makedirs(pkg_dir, exist_ok=True)
    if custom:
        t = open('MainActivity.java.tmpl', encoding='utf-8').read()
        t = t.replace('__APPID__', app_id).replace('__FULLSCREEN__', 'fs()' if meta.get('runtime_fullscreen') else ('true' if meta.get('fullscreen', True) else 'false'))
    else:
        t = 'package %s;\nimport com.getcapacitor.BridgeActivity;\npublic class MainActivity extends BridgeActivity {}\n' % app_id
    open(act, 'w', encoding='utf-8').write(t)

if '--default-activity' in sys.argv:
    write_activity(False); sys.exit(0)

write_activity(True)

# icono del juego
res = os.path.join('android', 'app', 'src', 'main', 'res')
try:
    shutil.rmtree(os.path.join(res, 'mipmap-anydpi-v26'), ignore_errors=True)
    for dens, size in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
        d = os.path.join(res, 'mipmap-' + dens); os.makedirs(d, exist_ok=True)
        for n in ('ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png'):
            shutil.copy(os.path.join('icons', '%d.png' % size), os.path.join(d, n))
except Exception as e:
    print('Aviso: no se pudo poner el icono:', e)

# orientacion
try:
    m = os.path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml')
    s = open(m, encoding='utf-8').read()
    o = {'landscape': 'sensorLandscape', 'portrait': 'sensorPortrait'}.get(meta.get('orientation'))
    if o and 'screenOrientation' not in s:
        s = s.replace('<activity', '<activity android:screenOrientation="%s"' % o, 1)
        open(m, 'w', encoding='utf-8').write(s)
except Exception as e:
    print('Aviso: no se pudo fijar la orientacion:', e)
# nombre fijo de la plantilla (la app lo cambia por el nombre del juego al crear el APK)
try:
    if meta.get('label'):
        import re
        m = os.path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml')
        s = open(m, encoding='utf-8').read()
        s = re.sub(r'android:label="[^"]*"', 'android:label="%s"' % meta['label'], s)
        open(m, 'w', encoding='utf-8').write(s)
except Exception as e:
    print('Aviso: no se pudo poner el nombre:', e)
# que Android NO restaure datos viejos del juego al reinstalarlo (y que se borren al desinstalar)
try:
    m = os.path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml')
    s = open(m, encoding='utf-8').read()
    s = s.replace('android:allowBackup="true"', 'android:allowBackup="false"')
    open(m, 'w', encoding='utf-8').write(s)
except Exception as e:
    print('Aviso: no se pudo desactivar la copia de seguridad:', e)
print('Parche de Android aplicado')
