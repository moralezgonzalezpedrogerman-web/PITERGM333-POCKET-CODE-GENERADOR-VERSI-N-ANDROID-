// Puente para Android (WebView): hace lo que en Windows hacía preload.js
(function () {
  const P = () => (window.Capacitor && window.Capacitor.Plugins) || {};
  let gameP = null;
  const getGame = () => gameP || (gameP = fetch('game.json').then(r => r.json()));
  window.api = {
    getGame,
    loadVars: async () => {
      try { const j = JSON.parse(localStorage.getItem('DeviceVariables') || 'null'); if (j && typeof j === 'object') return j; } catch (e) {}
      const g = await getGame(); return (g.meta && g.meta.initialSaved && typeof g.meta.initialSaved === 'object') ? g.meta.initialSaved : {};
    },
    saveVars: async o => { try { localStorage.setItem('DeviceVariables', JSON.stringify(o)); return true; } catch (e) { return false; } },
    log: t => { try { console.log(t); } catch (e) {} },
    openUrl: u => { if (/^https?:\/\//i.test(u)) window.open(u, '_blank'); },
    quit: () => { const A = P().App; if (A && A.exitApp) A.exitApp(); },
    fileUrl: rel => rel.split('/').map(encodeURIComponent).join('/')
  };
})();
