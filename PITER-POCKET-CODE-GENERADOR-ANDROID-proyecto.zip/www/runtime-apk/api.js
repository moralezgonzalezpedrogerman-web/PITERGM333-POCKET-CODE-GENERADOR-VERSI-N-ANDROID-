// Puente para Android (WebView): hace lo que en Windows hacía preload.js
(function () {
  const P = () => (window.Capacitor && window.Capacitor.Plugins) || {};
  let gameP = null;
  // Carpeta de identificación del juego (Android/data/<paquete>/files/DatosDelJuego): no hace falta para jugar.
  // Solo se crea si no existe, así que quien tenga el juego puede editar lo que haya ahí sin que se pierda.
  async function dataFolder(g) {
    const Fs = P().Filesystem, m = g.meta || {}; if (!Fs) return;
    try { await Fs.stat({ path: 'DatosDelJuego/info.json', directory: 'EXTERNAL' }); return; } catch (e) {}
    const w = (path, data) => Fs.writeFile({ path, directory: 'EXTERNAL', data, encoding: 'utf8', recursive: true });
    try {
      await w('DatosDelJuego/info.json', JSON.stringify({ juego: m.name || '', id: m.appId || '', version: m.version || '', autor: m.company || '', creado: new Date().toISOString(), generado_con: m.generator || '' }, null, 2));
      await w('DatosDelJuego/LEEME.txt', 'Identificación del juego "' + (m.name || '') + '"\r\nId de la app: ' + (m.appId || '') + '\r\n\r\nEsta carpeta NO hace falta para jugar. Sirve para identificar el juego y para que quien lo tenga pueda ubicarlo y editarlo.\r\n');
    } catch (e) {}
  }
  let meta = {};
  const getGame = () => gameP || (gameP = fetch('game.json').then(r => r.json()).then(g => { meta = g.meta || {}; dataFolder(g); return g; }));
  window.api = {
    getGame,
    loadVars: async () => {
      await getGame(); if (meta.freshStart) { try { localStorage.removeItem('DeviceVariables'); } catch (e) {} return {}; } // "No recordar progreso"
      try { const j = JSON.parse(localStorage.getItem('DeviceVariables') || 'null'); if (j && typeof j === 'object') return j; } catch (e) {}
      const g = await getGame(); return (g.meta && g.meta.initialSaved && typeof g.meta.initialSaved === 'object') ? g.meta.initialSaved : {};
    },
    saveVars: async o => { if (meta.freshStart) return true; try { localStorage.setItem('DeviceVariables', JSON.stringify(o)); return true; } catch (e) { return false; } },
    log: t => { try { console.log(t); } catch (e) {} },
    openUrl: u => { if (/^https?:\/\//i.test(u)) window.open(u, '_blank'); },
    quit: () => { const A = P().App; if (A && A.exitApp) A.exitApp(); },
    fileUrl: rel => rel.split('/').map(encodeURIComponent).join('/')
  };
})();
