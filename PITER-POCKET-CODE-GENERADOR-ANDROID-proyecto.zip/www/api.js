'use strict';
// Capa que hace en el celular lo que en Windows hacía el proceso principal de Electron.
(function (root, factory) {
  const Z = (typeof module === 'object' && module.exports) ? require('./zip.js') : root.PiterZip;
  const api = factory(Z, root);
  if (typeof module === 'object' && module.exports) module.exports = api; else root.PiterApi = api;
})(typeof self !== 'undefined' ? self : this, function (Z, root) {
  const APP_FILES = ['main.js', 'preload.js', 'index.html', 'engine.js', 'app.js'];
  const cfg = {
    loadTemplate: async () => cfg._tpl || (cfg._tpl = (await fetch('runtime-template.zip')).blob()),
    loadRuntime: async f => new Uint8Array(await (await fetch('runtime/' + f)).arrayBuffer()),
    loadApkFile: async f => new Uint8Array(await (await fetch('runtime-apk/' + f)).arrayBuffer()),
    loadRunner: async () => { // plantilla de APK compilada junto con este generador (null si no está)
      try { const r = await fetch('runtime-apk/runner.apk'); if (!r.ok) return null; const b = await r.blob(); const h = new Uint8Array(await b.slice(0, 4).arrayBuffer()); return b.size > 10000 && h[0] === 0x50 && h[1] === 0x4B ? b : null; }
      catch (e) { return null; }
    }
  };
  let cur = null; // juego elegido: { blob, recs, prefix }

  const safeFileName = s => (String(s).replace(/[<>:"/\\|?*\x00-\x1f]/g, '').replace(/[. ]+$/g, '').trim().slice(0, 80)) || 'Juego';
  const slug = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 40) || 'juego';
  const hex = buf => Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  async function sha1(s) { return hex(await crypto.subtle.digest('SHA-1', new TextEncoder().encode(s))); }
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };

  // ---------- leer el juego (.catrobat / .zip) ----------
  async function prepare(file) {
    const recs = await Z.readCentral(file);
    const codes = recs.filter(r => /(^|\/)code\.xml$/i.test(r.name) && r.name.split('/').length <= 4).sort((a, b) => a.name.length - b.name.length);
    if (!codes.length) throw new Error('No encontré code.xml dentro del archivo. Elige un .catrobat o un .zip de un juego de Pocket Code.');
    const code = codes[0], prefix = code.name.slice(0, code.name.length - 'code.xml'.length);
    let xml = await Z.readText(file, code);
    if (xml.charCodeAt(0) === 0xFEFF) xml = xml.slice(1);
    const own = recs.filter(r => !r.name.endsWith('/') && r.name.startsWith(prefix) && !r.name.split('/').includes('..'));
    const rel = r => r.name.slice(prefix.length);
    const files = own.map(rel).filter(n => n !== 'code.xml' && n !== 'DeviceVariables.json' && n !== '.listo');
    let screenshot = null;
    for (const n of ['screenshot.png', 'manual_screenshot.png', 'automatic_screenshot.png']) {
      const r = own.find(x => rel(x) === n);
      if (r) { try { screenshot = 'data:image/png;base64,' + b64(await Z.readBytes(file, r)); } catch (e) {} break; }
    }
    let deviceVars = null;
    const dv = own.find(x => rel(x) === 'DeviceVariables.json');
    if (dv) {
      try {
        const j = JSON.parse(await Z.readText(file, dv));
        if (Array.isArray(j)) { deviceVars = {}; for (const e of j) if (e && e.name !== undefined) deviceVars[e.name] = e.value; }
        else if (j && typeof j === 'object') deviceVars = j;
      } catch (e) {}
    }
    cur = { blob: file, recs, prefix };
    return { xml, files, screenshot, deviceVars, sourceName: file.name };
  }

  // ---------- generar el paquete para Windows ----------
  const structureKey = g => { const p = [g.meta && g.meta.programName]; for (const sc of g.scenes || []) { p.push(sc.name); for (const ob of sc.objs || []) p.push(ob.name); } return p.join('|'); };
  const README = name => 'Cómo usar "' + name + '" en Windows\r\n\r\n1. Extrae TODO el contenido de este ZIP en una carpeta (clic derecho > Extraer todo).\r\n' +
    '2. Abre "' + name + '.exe". Si Windows muestra una pantalla azul de SmartScreen: "Más información" > "Ejecutar de todas formas".\r\n\r\n' +
    'El .exe ya lleva tu logotipo. Si creas un acceso directo y no lo muestra: clic derecho > Propiedades > Cambiar icono > elige "icono.ico".\r\n' +
    'No borres "motor.exe": es el motor del juego y el .exe lo abre.\r\n' +
    'El progreso del juego se guarda en %APPDATA%\\PiterPocketCode.\r\nGenerado con PITER POCKET CODE GENERADOR (Android).\r\n';

  const pkgOf = (n, custom) => { if (custom) return custom; const AB = (typeof module === 'object' && module.exports) ? require('./apkbuild.js') : root.PiterApkBuild; return AB ? AB.packageFor(n) : 'com.piter.juegos.juego'; };
  async function build(o, log) {
    if (!cur) throw new Error('Primero elige un juego.');
    const name = String(o.name || '').trim() || 'Juego', exeBase = safeFileName(name);
    log('1/3 Cargando el motor de Windows…');
    const templateBlob = await cfg.loadTemplate();
    const templateRecs = await Z.readCentral(templateBlob);
    if (!templateRecs.some(r => r.name === 'electron.exe')) throw new Error('El motor de Windows incluido en la app está incompleto.');
    const appFiles = {};
    for (const f of APP_FILES) appFiles[f] = await cfg.loadRuntime(f);
    const game = o.game;
    game.meta = Object.assign({}, game.meta, {
      id: slug(name) + '-' + (await sha1(structureKey(game))).slice(0, 8), name, version: o.version || '1.0.0', company: o.company || '',
      fullscreen: !!o.fullscreen, devtools: !!o.devtools, initialSaved: o.useSaved ? (o.deviceVars || null) : null, freshStart: !!o.freshStart, generator: 'PITER POCKET CODE GENERADOR (Android)'
    });
    // Lanzador con el logotipo del usuario (el .exe de Electron no se puede editar desde el celular: es de ~170 MB)
    let launcher = null;
    try {
      const PE = (typeof module === 'object' && module.exports) ? require('./peicon.js') : root.PiterPE;
      const raw = await cfg.loadRuntime('launcher.exe');
      if (PE && raw.length > 512 && raw[0] === 0x4D && raw[1] === 0x5A && o.iconFrames && o.iconFrames.length)
        launcher = PE.patchLauncher(raw, { frames: o.iconFrames, name, version: o.version || '1.0.0', company: o.company || '', exeName: exeBase + '.exe' });
    } catch (e) { log('Aviso: no se pudo poner el logotipo al .exe (' + e.message + '). Se usará el icono normal.'); }
    log('2/3 Armando el paquete (traducción + imágenes, sonidos y videos)…');
    const blob = await Z.buildPackage({
      templateBlob, templateRecs, srcBlob: cur.blob, srcRecs: cur.recs, srcPrefix: cur.prefix, appFiles, game, name, slug: slug(name),
      version: o.version || '1.0.0', prefix: exeBase + '/', exeName: exeBase + '.exe', launcher, info: JSON.stringify({ juego: name, id: pkgOf(name, o.pkg), version: o.version || '1.0.0', autor: o.company || '', creado: new Date().toISOString(), generado_con: 'PITER POCKET CODE GENERADOR (Android)' }, null, 2), iconPng: o.iconPng, iconIco: o.iconIco, readme: README(exeBase)
    }, log);
    log('Listo: ' + (blob.size / 1048576).toFixed(1) + ' MB');
    return { files: [{ blob, fileName: exeBase + '.zip', mime: 'application/zip' }], exeName: exeBase + '.exe', size: blob.size, kind: 'exe' };
  }

  // ---------- generar el APK directamente en el celular (sin GitHub) ----------
  async function buildApkDirect(o, log) {
    if (!cur) throw new Error('Primero elige un juego.');
    const AB = (typeof module === 'object' && module.exports) ? require('./apkbuild.js') : root.PiterApkBuild;
    const runner = AB && await cfg.loadRunner();
    if (!runner) return null; // sin plantilla: se usa el método de GitHub
    const name = String(o.name || '').trim() || 'Juego', sl = slug(name), game = o.game, pkg = (o.pkg && String(o.pkg).trim()) || AB.packageFor(name);
    { const bad = o.pkg ? AB.validPackage(pkg) : ''; if (bad) throw new Error('Identificación de la app no válida: ' + bad); }
    log('1/3 Preparando el APK de "' + name + '"…');
    game.meta = Object.assign({}, game.meta, {
      id: sl + '-' + (await sha1(structureKey(game))).slice(0, 8), name, version: o.version || '1.0.0', company: o.company || '', appId: pkg,
      dataFolder: 'Android/data/' + pkg + '/files/DatosDelJuego', fullscreen: o.fullscreen !== false, devtools: false, initialSaved: o.useSaved ? (o.deviceVars || null) : null, freshStart: !!o.freshStart,
      generator: 'PITER POCKET CODE GENERADOR (Android)'
    });
    const skip = new Set(['code.xml', 'DeviceVariables.json', '.listo']);
    const gameEntries = cur.recs.filter(r => !r.name.endsWith('/') && r.name.startsWith(cur.prefix) && !r.name.split('/').includes('..') && !skip.has(r.name.slice(cur.prefix.length)))
      .map(r => ({ rel: r.name.slice(cur.prefix.length), addTo: async (w, dest) => {
        if (r.method !== 0 && r.method !== 8) throw new Error('Compresión no soportada en ' + r.name);
        w.addRaw(dest, r.method, r.crc, r.comp, r.size, await Z.dataSlice(cur.blob, r));
      } }));
    log('2/3 Armando y firmando el APK (paquete ' + pkg + ')…');
    await Z.prefetch(cur.blob, cur.recs);
    const res = await AB.build({ Z, runner, pkg, label: name, orientation: o.orientation, iconsAndroid: o.iconsAndroid, game, gameEntries }, log);
    if (!res.icons) log('Aviso: no pude cambiar el icono de la app (se verá el icono normal).');
    const fileName = safeFileName(name) + '.apk';
    log('Listo: ' + (res.blob.size / 1048576).toFixed(1) + ' MB');
    return { files: [{ blob: res.blob, fileName, mime: 'application/vnd.android.package-archive' }], size: res.blob.size, kind: 'apkdone', pkg, fileName };
  }

  // ---------- generar el proyecto para compilar un APK del juego ----------
  async function buildApk(o, log) {
    if (!cur) throw new Error('Primero elige un juego.');
    const Apk = (typeof module === 'object' && module.exports) ? require('./apkproject.js') : root.PiterApk;
    const name = String(o.name || '').trim() || 'Juego', sl = slug(name), game = o.game;
    log('1/2 Preparando el proyecto de Android…');
    game.meta = Object.assign({}, game.meta, {
      id: sl + '-' + (await sha1(structureKey(game))).slice(0, 8), name, version: o.version || '1.0.0', company: o.company || '',
      fullscreen: o.fullscreen !== false, devtools: false, initialSaved: o.useSaved ? (o.deviceVars || null) : null, freshStart: !!o.freshStart, generator: 'PITER POCKET CODE GENERADOR (Android)'
    });
    if (o.pkg && String(o.pkg).trim()) { const AB = (typeof module === 'object' && module.exports) ? require('./apkbuild.js') : root.PiterApkBuild, bad = AB.validPackage(o.pkg); if (bad) throw new Error('Identificación de la app no válida: ' + bad); game.meta.appId = String(o.pkg).trim(); }
    const files = {};
    for (const f of ['index.html', 'api.js', 'patch_android.py', 'MainActivity.java.tmpl']) files[f] = await cfg.loadApkFile(f);
    for (const f of ['engine.js', 'app.js']) files[f] = await cfg.loadRuntime(f);
    const skip = new Set(['code.xml', 'DeviceVariables.json', '.listo']);
    const assetEntries = cur.recs.filter(r => !r.name.endsWith('/') && r.name.startsWith(cur.prefix) && !r.name.split('/').includes('..') && !skip.has(r.name.slice(cur.prefix.length)))
      .map(r => ({ rel: r.name.slice(cur.prefix.length), addTo: async (w, dest) => {
        if (r.method !== 0 && r.method !== 8) throw new Error('Compresión no soportada en ' + r.name);
        w.addRaw(dest, r.method, r.crc, r.comp, r.size, await Z.dataSlice(cur.blob, r));
      } }));
    await Z.prefetch(cur.blob, cur.recs);
    const zipName = sl + '-APK-proyecto.zip', ymlName = sl + '-compilar-apk.yml';
    const blob = await Apk.build({ Z, game, name, slug: sl, version: o.version, orientation: o.orientation, fullscreen: o.fullscreen !== false,
      icons: o.iconsAndroid, iconPng: o.iconPng, files, assetEntries }, log);
    const yml = new Blob([Apk.workflowYml({ slug: sl, zipName, apkName: sl })], { type: 'application/octet-stream' });
    log('2/2 Listo: ' + (blob.size / 1048576).toFixed(1) + ' MB');
    return { files: [{ blob, fileName: zipName, mime: 'application/zip' }, { blob: yml, fileName: ymlName, mime: 'application/octet-stream' }],
      size: blob.size, kind: 'apk', zipName, ymlName };
  }

  // ---------- carpeta de destino y guardado (Android) ----------
  const plugins = () => (globalThis.Capacitor && globalThis.Capacitor.Plugins) || {};
  const canPickFolder = () => !!plugins().FolderSaver;
  function prettyFolder(id) { // "primary:Download/Juegos" -> "Almacenamiento interno / Download/Juegos"
    const i = String(id).indexOf(':'), vol = i < 0 ? id : id.slice(0, i), rest = i < 0 ? '' : id.slice(i + 1);
    return (vol === 'primary' ? 'Almacenamiento interno' : vol === 'home' ? 'Documentos' : 'Tarjeta (' + vol + ')') + (rest ? ' / ' + rest : '');
  }
  async function pickFolder() {
    const r = await plugins().FolderSaver.pickFolder();
    return { uri: r.uri, name: prettyFolder(r.name) };
  }
  // Lee el archivo por bloques grandes (8 MB) y va preparando el siguiente mientras se escribe el anterior
  const CHUNK = 8 * 1024 * 1024;
  const readB64 = part => new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1] || ''); fr.onerror = () => rej(fr.error); fr.readAsDataURL(part); });
  async function pump(blob, write, progress) {
    let off = 0, next = readB64(blob.slice(0, CHUNK));
    for (;;) {
      const data = await next, first = off === 0, cur = off; off += CHUNK;
      next = off < blob.size ? readB64(blob.slice(off, off + CHUNK)) : null;   // se lee el siguiente mientras se escribe este
      await write(data, first);
      if (progress) progress(Math.min(100, Math.round(Math.min(blob.size, cur + CHUNK) / Math.max(1, blob.size) * 100)));
      if (!next) break;
    }
  }
  async function writeCache(Fs, blob, path, progress) {
    try { await Fs.deleteFile({ path, directory: 'CACHE' }); } catch (e) {}
    await pump(blob, (data, first) => first ? Fs.writeFile({ path, directory: 'CACHE', data }) : Fs.appendFile({ path, directory: 'CACHE', data }), progress);
    return (await Fs.getUri({ path, directory: 'CACHE' })).uri;
  }
  // Escribe directo en la carpeta elegida (sin copia intermedia): mucho más rápido en archivos grandes
  async function writeDirect(FS, treeUri, f, progress) {
    const { id } = await FS.beginWrite({ treeUri, fileName: f.fileName, mimeType: f.mime });
    try { await pump(f.blob, data => FS.writeChunk({ id, data }), progress); }
    finally { try { await FS.endWrite({ id }); } catch (e) {} }
  }
  // files: [{ blob, fileName, mime }]
  async function save(files, progress, treeUri) {
    const P = plugins(), Fs = P.Filesystem, Share = P.Share;
    if (!Fs || !Share) { // fuera de Android (prueba en navegador): descarga normal
      for (const f of files) { const a = document.createElement('a'); a.href = URL.createObjectURL(f.blob); a.download = f.fileName; document.body.appendChild(a); a.click(); a.remove(); }
      return { shared: false, folder: false };
    }
    const FS = P.FolderSaver;
    if (treeUri && FS && FS.beginWrite) { // camino rápido
      try { for (const f of files) await writeDirect(FS, treeUri, f, progress); return { shared: false, folder: true }; }
      catch (e) { /* si algo falla, se intenta el camino normal */ }
    }
    const uris = [];
    for (const f of files) uris.push(await writeCache(Fs, f.blob, 'piter-' + f.fileName.replace(/[^\w.\-]+/g, '_'), progress));
    const out = { shared: true, folder: false, uris, share: () => Share.share({ title: files[0].fileName, dialogTitle: 'Guardar o enviar', files: uris }) };
    if (treeUri && canPickFolder()) {
      try { for (let i = 0; i < files.length; i++) await FS.copyToFolder({ treeUri, sourceUri: uris[i], fileName: files[i].fileName, mimeType: files[i].mime }); out.folder = true; }
      catch (e) { out.folderError = e && e.message ? e.message : String(e); }
    }
    return out;
  }

  return { prepare, build, buildApk, buildApkDirect, save, pickFolder, canPickFolder, safeFileName, slug, _cfg: cfg };
});
