'use strict';
// Capa que hace en el celular lo que en Windows hacía el proceso principal de Electron.
(function (root, factory) {
  const Z = (typeof module === 'object' && module.exports) ? require('./zip.js') : root.PiterZip;
  const api = factory(Z, root);
  if (typeof module === 'object' && module.exports) module.exports = api; else root.PiterApi = api;
})(typeof self !== 'undefined' ? self : this, function (Z, root) {
  const APP_FILES = ['main.js', 'preload.js', 'index.html', 'engine.js', 'app.js'];
  const cfg = {
    loadTemplate: async () => (await fetch('runtime-template.zip')).blob(),
    loadRuntime: async f => new Uint8Array(await (await fetch('runtime/' + f)).arrayBuffer())
  };
  let cur = null; // juego elegido: { blob, recs, prefix }

  const safeFileName = s => (String(s).replace(/[<>:"/\\|?*\x00-\x1f]/g, '').replace(/[. ]+$/g, '').trim().slice(0, 80)) || 'Juego';
  const slug = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 40) || 'juego';
  const hex = buf => Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  async function sha1(s) { return hex(await crypto.subtle.digest('SHA-1', new TextEncoder().encode(s))); }
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };

  // ---------- leer el juego (.catrobat / .zip) ----------
  async function prepare(file) {
    const recs = await Z.readCentral(file);
    const codes = recs.filter(r => /(^|\/)code\.xml$/i.test(r.name) && r.name.split('/').length <= 4).sort((a, b) => a.name.length - b.name.length);
    if (!codes.length) throw new Error('No encontré code.xml dentro del archivo. Elige un .catrobat o un .zip de un juego de Pocket Code.');
    const code = codes[0], prefix = code.name.slice(0, code.name.length - 'code.xml'.length);
    let xml = await Z.readText(file, code);
    if (xml.charCodeAt(0) === 0xFEFF) xml = xml.slice(1);
    const own = recs.filter(r => !r.name.endsWith('/') && r.name.startsWith(prefix) && !r.name.split('/').includes('..'));
    const rel = r => r.name.slice(prefix.length);
    const files = own.map(rel).filter(n => n !== 'code.xml' && n !== 'DeviceVariables.json' && n !== '.listo');
    let screenshot = null;
    for (const n of ['screenshot.png', 'manual_screenshot.png', 'automatic_screenshot.png']) {
      const r = own.find(x => rel(x) === n);
      if (r) { try { screenshot = 'data:image/png;base64,' + b64(await Z.readBytes(file, r)); } catch (e) {} break; }
    }
    let deviceVars = null;
    const dv = own.find(x => rel(x) === 'DeviceVariables.json');
    if (dv) {
      try {
        const j = JSON.parse(await Z.readText(file, dv));
        if (Array.isArray(j)) { deviceVars = {}; for (const e of j) if (e && e.name !== undefined) deviceVars[e.name] = e.value; }
        else if (j && typeof j === 'object') deviceVars = j;
      } catch (e) {}
    }
    cur = { blob: file, recs, prefix };
    return { xml, files, screenshot, deviceVars, sourceName: file.name };
  }

  // ---------- generar el paquete para Windows ----------
  const structureKey = g => { const p = [g.meta && g.meta.programName]; for (const sc of g.scenes || []) { p.push(sc.name); for (const ob of sc.objs || []) p.push(ob.name); } return p.join('|'); };
  const README = name => 'Cómo usar "' + name + '" en Windows\r\n\r\n1. Extrae TODO el contenido de este ZIP en una carpeta (clic derecho > Extraer todo).\r\n' +
    '2. Abre "' + name + '.exe". Si Windows muestra una pantalla azul de SmartScreen: "Más información" > "Ejecutar de todas formas".\r\n\r\n' +
    'Para que el acceso directo tenga tu logotipo: clic derecho en el acceso directo > Propiedades > Cambiar icono > elige "icono.ico".\r\n' +
    'El progreso del juego se guarda en %APPDATA%\\PiterPocketCode.\r\nGenerado con PITER POCKET CODE GENERADOR (Android).\r\n';

  async function build(o, log) {
    if (!cur) throw new Error('Primero elige un juego.');
    const name = String(o.name || '').trim() || 'Juego', exeBase = safeFileName(name);
    log('1/3 Cargando el motor de Windows…');
    const templateBlob = await cfg.loadTemplate();
    const templateRecs = await Z.readCentral(templateBlob);
    if (!templateRecs.some(r => r.name === 'electron.exe')) throw new Error('El motor de Windows incluido en la app está incompleto.');
    const appFiles = {};
    for (const f of APP_FILES) appFiles[f] = await cfg.loadRuntime(f);
    const game = o.game;
    game.meta = Object.assign({}, game.meta, {
      id: slug(name) + '-' + (await sha1(structureKey(game))).slice(0, 8), name, version: o.version || '1.0.0', company: o.company || '',
      fullscreen: !!o.fullscreen, devtools: !!o.devtools, initialSaved: o.deviceVars || null, generator: 'PITER POCKET CODE GENERADOR (Android)'
    });
    log('2/3 Armando el paquete (traducción + imágenes, sonidos y videos)…');
    const blob = await Z.buildPackage({
      templateBlob, templateRecs, srcBlob: cur.blob, srcRecs: cur.recs, srcPrefix: cur.prefix, appFiles, game, name, slug: slug(name),
      version: o.version || '1.0.0', prefix: exeBase + '/', exeName: exeBase + '.exe', iconPng: o.iconPng, iconIco: o.iconIco, readme: README(exeBase)
    }, log);
    log('Listo: ' + (blob.size / 1048576).toFixed(1) + ' MB');
    return { blob, fileName: exeBase + '.zip', exeName: exeBase + '.exe', size: blob.size };
  }

  // ---------- guardar / compartir (Android) ----------
  async function save(blob, fileName, progress) {
    const P = root.Capacitor && root.Capacitor.Plugins, Fs = P && P.Filesystem, Share = P && P.Share;
    const safe = fileName.replace(/[^\w.\-]+/g, '_');
    if (!Fs || !Share) { // fuera de Android (prueba en navegador): descarga normal
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = fileName; document.body.appendChild(a); a.click(); a.remove();
      return { shared: false };
    }
    const path = 'piter-' + safe;
    try { await Fs.deleteFile({ path, directory: 'CACHE' }); } catch (e) {}
    const CH = 3 * 1024 * 1024;
    for (let off = 0, first = true; off < blob.size; off += CH, first = false) {
      const part = blob.slice(off, off + CH);
      const data = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1]); fr.onerror = () => rej(fr.error); fr.readAsDataURL(part); });
      if (first) await Fs.writeFile({ path, directory: 'CACHE', data }); else await Fs.appendFile({ path, directory: 'CACHE', data });
      if (progress) progress(Math.min(100, Math.round((off + CH) / blob.size * 100)));
    }
    const { uri } = await Fs.getUri({ path, directory: 'CACHE' });
    return { shared: true, uri, share: () => Share.share({ title: fileName, dialogTitle: 'Guardar o enviar ' + fileName, files: [uri] }) };
  }

  return { prepare, build, save, safeFileName, slug, _cfg: cfg };
});
