'use strict';
(function () {
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let src = null, compiled = null, customIcon = null, inputs = [], busy = false;
  let outTree = localStorage.getItem('outTree') || '', outName = localStorage.getItem('outName') || '';

  PiterOptions.init($('optBox'));
  const log = t => { const l = $('log'); l.textContent += t + '\n'; l.scrollTop = l.scrollHeight; };
  const bar = p => { $('bar').style.display = p == null ? 'none' : 'block'; $('pct').textContent = p == null ? '' : p + ' %'; if (p != null) $('bar').firstChild.style.width = p + '%'; };

  // ---------- 1. elegir juego ----------
  $('bFile').onclick = () => $('fileSrc').click();
  $('fileSrc').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (f) loadSource(f); };

  async function loadSource(file) {
    if (busy) return;
    busy = true; $('bGo').disabled = true; $('result').innerHTML = ''; $('report').style.display = 'none';
    $('status').textContent = 'Leyendo el juego…';
    try {
      const res = await PiterApi.prepare(file);
      $('status').textContent = 'Traduciendo los bloques…';
      await new Promise(r => setTimeout(r, 30));
      compiled = PiterCompiler.compile(res.xml, res.files);
      src = res;
      showReport(res, compiled.report);
      $('name').value = compiled.report.programName;
      if (!customIcon) $('icon').src = res.screenshot || 'default-icon.png';
      inputs = (compiled.game.inputs || []).map(i => Object.assign({}, i)); joy.on = ((compiled.report || {}).joystickPatterns || []).length > 0; joy.obj = ''; renderInputs(); // si se detectó un joystick, el teclado ya queda listo (WASD y flechas)
      PiterOptions.setGame(compiled.game); PiterOptions.setDeclared(compiled.report.declaredVars);
      $('useSavedBox').style.display = (src.deviceVars && Object.keys(src.deviceVars).length) ? '' : 'none'; $('useSaved').checked = false;
      for (const id of ['s2', 'sProg', 'sOpt', 'sMap', 's3']) { $(id).style.opacity = 1; $(id).style.pointerEvents = 'auto'; }
      $('bGo').disabled = false;
    } catch (e) {
      src = compiled = null; inputs = []; $('bGo').disabled = true;
      $('status').innerHTML = '<span class="bad">No se pudo leer el juego: ' + esc(e.message) + '</span>';
    }
    busy = false;
  }

  function list(o) { return Object.keys(o).sort().map(k => esc(k) + (o[k] > 1 ? ' ×' + o[k] : '')).join(', '); }
  function showReport(res, r) {
    $('status').innerHTML = '<b>' + esc(r.programName) + '</b> <span class="mut">(' + esc(res.sourceName) + ')</span>';
    let h = '<span class="pill">' + r.scenes + ' escena(s)</span><span class="pill">' + r.objects + ' objetos</span><span class="pill">' +
      r.scripts + ' scripts</span><span class="pill">' + r.bricks + ' bloques</span><span class="pill">' + res.files.length + ' archivos</span><ul>';
    if (r.ok) h += '<li class="ok">✔ Todos los bloques y fórmulas del juego están soportados.</li>';
    if (Object.keys(r.unsupportedBricks).length) h += '<li class="bad">✖ Bloques sin soporte (no harán nada): ' + list(r.unsupportedBricks) + '</li>';
    if (Object.keys(r.unsupportedScripts).length) h += '<li class="bad">✖ Scripts sin soporte: ' + list(r.unsupportedScripts) + '</li>';
    if (Object.keys(r.unsupportedFormulas).length) h += '<li class="bad">✖ Fórmulas sin soporte (valen 0): ' + list(r.unsupportedFormulas) + '</li>';
    if (r.missingAssets.length) h += '<li class="bad">✖ Faltan archivos del juego: ' + esc(r.missingAssets.slice(0, 12).join(', ')) + (r.missingAssets.length > 12 ? '…' : '') + '</li>';
    if (Object.keys(r.ignoredBricks).length) h += '<li class="warn">⚠ Bloques de celular/hardware que en PC no hacen nada: ' + list(r.ignoredBricks) + '</li>';
    if (Object.keys(r.mobileSensors).length) h += '<li class="warn">⚠ Sensores de celular (en PC valen 0): ' + list(r.mobileSensors) + '</li>';
    for (const j of (r.joystickPatterns || [])) h += '<li class="ok">🕹 Joystick detectado (' + ({ 1: 'patrón 1: variable de estado', 2: 'patrón 2: pantalla tocada', 3: 'patrón 3: mensajes', 4: 'patrón 4: por siempre, sin “cuando pulse”' }[j.pattern]) + '): perilla «' + esc(j.knob) + '», rastreador «' + esc(j.tracker) + '», personaje «' + esc(j.character) + '»' + (j.base ? ', base «' + esc(j.base) + '»' : '') + '. Se reconoce por su estructura, no por los nombres.' + (j.issues.length ? ' <span class="warn">🛠 Se repara solo: ' + esc(j.issues.join('; ')) + '.</span>' : '') + '</li>';
    if (!(r.joystickPatterns || []).length && (r.joysticks || []).length) h += '<li class="ok">🕹 Joystick virtual detectado en: ' + esc(r.joysticks.map(j => j.obj + (j.fingers === 'multi' ? ' (varios dedos)' : '')).join(', ')) + '. Se interpreta por la estructura de sus bloques, sin importar el nombre de los objetos.</li>';
    const phys = Object.keys(r.bricksUsed).filter(k => /^(SetPhysicsObjectType|SetVelocity|SetGravity|SetMass|SetBounce|SetFriction|TurnLeftSpeed|TurnRightSpeed)/.test(k));
    if (phys.length) h += '<li class="warn">⚠ Este juego usa física: se simula de forma aproximada, puede no ser idéntica a Pocket Code.</li>';
    h += '</ul><details><summary>Ver todos los bloques usados</summary><div class="mut" style="margin-top:6px">' + list(r.bricksUsed) + '</div></details>';
    h += '<button id="bCopyRep" class="sec" style="margin-top:12px;width:100%">📋 Copiar informe para soporte</button>';
    $('report').innerHTML = h; $('report').style.display = 'block';
    // informe con los bloques tal cual están en el juego: se pega en el chat para que se pueda analizar sin mandar el archivo
    $('bCopyRep').onclick = async () => {
      const b = $('bCopyRep'), t = PiterCompiler.describe(compiled.game, compiled.report, res.sourceName); let ok = false;
      try { await navigator.clipboard.writeText(t); ok = true; } catch (e) {
        try { const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); } catch (e2) { }
      }
      b.textContent = ok ? '✔ Informe copiado — pégalo en el chat' : '✖ No se pudo copiar'; setTimeout(() => { b.textContent = '📋 Copiar informe para soporte'; }, 3500);
    };
  }

  // ---------- 2. personalizar ----------
  $('bIcon').onclick = () => $('fileIcon').click();
  $('fileIcon').onchange = e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    const fr = new FileReader();
    fr.onload = () => { customIcon = fr.result; $('icon').src = customIcon; $('bIconDel').style.display = ''; $('iconNote').textContent = f.name; };
    fr.readAsDataURL(f);
  };
  $('bIconDel').onclick = () => {
    customIcon = null; $('bIconDel').style.display = 'none'; $('icon').src = (src && src.screenshot) || 'default-icon.png';
    $('iconNote').textContent = 'Si no eliges, se usa la captura del juego o un icono por defecto.';
  };
  const loadImage = url => new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('No pude leer la imagen del logotipo')); im.src = url; });
  async function makeIcon(url) { // .ico con varios tamaños (fotogramas PNG) + PNG de 256 px
    const img = await loadImage(url), sizes = [256, 128, 64, 48, 32, 16], pngs = [], frames = [];
    for (const s of sizes) {
      const c = document.createElement('canvas'); c.width = c.height = s;
      const x = c.getContext('2d'); x.imageSmoothingQuality = 'high';
      const k = Math.min(s / img.naturalWidth, s / img.naturalHeight), w = img.naturalWidth * k, h = img.naturalHeight * k;
      x.drawImage(img, (s - w) / 2, (s - h) / 2, w, h);
      const blob = await new Promise(r => c.toBlob(r, 'image/png'));
      pngs.push(new Uint8Array(await blob.arrayBuffer()));
      // fotograma para el .exe: PNG a 256 px y BMP (DIB) en los demás tamaños (lo que Windows espera)
      frames.push(s >= 256 ? { size: s, data: pngs[pngs.length - 1] } : { size: s, data: PiterPE.dibFromRgba(x.getImageData(0, 0, s, s).data, s) });
    }
    const n = sizes.length; let off = 6 + 16 * n;
    const buf = new ArrayBuffer(off + pngs.reduce((a, p) => a + p.length, 0)), dv = new DataView(buf), u8 = new Uint8Array(buf);
    dv.setUint16(0, 0, true); dv.setUint16(2, 1, true); dv.setUint16(4, n, true);
    sizes.forEach((s, i) => {
      const e = 6 + 16 * i;
      u8[e] = s >= 256 ? 0 : s; u8[e + 1] = s >= 256 ? 0 : s;
      dv.setUint16(e + 4, 1, true); dv.setUint16(e + 6, 32, true); dv.setUint32(e + 8, pngs[i].length, true); dv.setUint32(e + 12, off, true);
      u8.set(pngs[i], off); off += pngs[i].length;
    });
    const android = {};
    for (const sz of [48, 72, 96, 144, 192]) {
      const c = document.createElement('canvas'); c.width = c.height = sz;
      const x = c.getContext('2d'); x.imageSmoothingQuality = 'high';
      const k = Math.min(sz / img.naturalWidth, sz / img.naturalHeight), w = img.naturalWidth * k, h = img.naturalHeight * k;
      x.drawImage(img, (sz - w) / 2, (sz - h) / 2, w, h);
      android[sz] = new Uint8Array(await (await new Promise(r => c.toBlob(r, 'image/png'))).arrayBuffer());
    }
    return { ico: u8, png: pngs[0], android, frames };
  }

  // ---------- 3. mapear botones ----------
  const KEYS = [['Space', 'Espacio'], ['Enter', 'Enter'], ['ArrowLeft', '← Izquierda'], ['ArrowRight', '→ Derecha'], ['ArrowUp', '↑ Arriba'], ['ArrowDown', '↓ Abajo'],
    ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(c => ['Key' + c, c]), ...'0123456789'.split('').map(c => ['Digit' + c, c]),
    ['ShiftLeft', 'Shift izq.'], ['ControlLeft', 'Ctrl izq.'], ['AltLeft', 'Alt izq.'], ['Tab', 'Tab'],
    ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => ['F' + n, 'F' + n])];
  const MOUSE = [[0, 'Clic izquierdo'], [1, 'Clic central'], [2, 'Clic derecho']];
  const SUGGEST = ['Space', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'KeyZ', 'KeyX', 'KeyC', 'KeyA', 'KeyS', 'KeyD', 'KeyW', 'KeyE', 'KeyQ', 'KeyR', 'KeyF'];
  const labelOf = code => (KEYS.find(k => k[0] === code) || [0, code])[1];
  const bindVal = b => b ? (b.type === 'key' ? 'key:' + b.code : 'mouse:' + b.button) : '';
  const itemName = i => i.screen ? 'Pantalla tocada (en cualquier parte)' : i.obj + (i.scene && compiled.game.scenes.length > 1 ? '  (escena ' + i.scene + ')' : '');
  const itemKind = i => i.screen ? 'bloque "cuando se toca la pantalla" / "dedo tocando"' : [i.tap ? 'cuando se pulse' : '', i.hold ? 'mientras se toca' : ''].filter(Boolean).join(' + ');

  function renderInputs() {
    const box = $('mapList');
    if (!inputs.length) { box.innerHTML = '<div class="mut" style="margin-top:8px">Este juego no usa controles táctiles que se puedan asignar.</div>'; $('bSuggest').style.display = 'none'; renderJoy(); return; }
    $('bSuggest').style.display = '';
    renderJoy();
    const used = {}; for (const i of inputs) if (i.bind) (used[bindVal(i.bind)] = used[bindVal(i.bind)] || []).push(itemName(i));
    const opts = '<option value="">Sin asignar</option><optgroup label="Teclado">' + KEYS.map(k => '<option value="key:' + k[0] + '">' + esc(k[1]) + '</option>').join('') +
      '</optgroup><optgroup label="Mouse">' + MOUSE.map(m => '<option value="mouse:' + m[0] + '">' + m[1] + '</option>').join('') + '</optgroup>';
    box.innerHTML = '';
    inputs.forEach(it => {
      const v = bindVal(it.bind), dup = v && used[v].length > 1, row = document.createElement('div'); row.className = 'maprow';
      row.innerHTML = '<b>' + esc(itemName(it)) + '</b><small>' + esc(itemKind(it)) + '</small>' +
        (dup ? '<small class="warn">⚠ Esa misma tecla también activa: ' + esc(used[v].filter(x => x !== itemName(it)).join(', ')) + '</small>' : '') +
        (v === 'mouse:0' ? '<small class="warn">⚠ El clic izquierdo activará este control en cualquier parte de la pantalla.</small>' : '') +
        '<select>' + opts + '</select>';
      const sel = row.querySelector('select'); sel.value = v;
      sel.onchange = () => {
        const [t, x] = sel.value.split(':');
        if (!sel.value) delete it.bind;
        else if (t === 'key') it.bind = { type: 'key', code: x, label: labelOf(x) };
        else it.bind = { type: 'mouse', button: +x, label: MOUSE[+x][1] };
        renderInputs();
      };
      box.appendChild(row);
    });
  }
  // ---------- joystick con el teclado (solo .exe) ----------
  const joy = { on: false, obj: '', keys: { up: 'KeyW', down: 'KeyS', left: 'KeyA', right: 'KeyD' }, arrows: true, radius: 0 };
  function joyConfig() {
    if (!joy.on || !joy.obj || kind() !== 'exe') return undefined;
    const A = { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight' }, keys = {};
    for (const d of ['up', 'down', 'left', 'right']) keys[d] = [...new Set([joy.keys[d], ...(joy.arrows ? [A[d]] : [])])];
    return { obj: joy.obj, keys, radius: Math.max(0, +joy.radius || 0) };
  }
  function renderJoy() {
    const box = $('joyBox'); if (!compiled) { box.style.display = 'none'; return; }
    const rep = compiled.report || {}, det = [...(rep.joystickPatterns || []).map(j => j.knob), ...(rep.joysticks || []).map(j => j.obj)], fo = rep.fingerObjs || [];
    const names = [...new Set(compiled.game.scenes.flatMap(s => s.objs.map(o => o.name)))];
    if (!det.length && !fo.length && !(compiled.game.inputs || []).some(i => i.screen)) { box.style.display = 'none'; return; }
    box.style.display = '';
    if (!joy.obj || !names.includes(joy.obj)) joy.obj = det[0] || fo[0] || names.find(n => !/^(background|fondo)$/i.test(n)) || names[0] || '';
    const taken = new Set(inputs.filter(i => i.bind && i.bind.type === 'key').map(i => i.bind.code));
    const clash = ['up', 'down', 'left', 'right'].filter(d => taken.has(joy.keys[d]));
    const objOpts = names.map(n => '<option value="' + esc(n) + '"' + (n === joy.obj ? ' selected' : '') + '>' + esc(n) + (det.includes(n) ? ' (joystick detectado)' : fo.includes(n) ? ' (usa el dedo)' : '') + '</option>').join('');
    const keySel = (id, d) => '<label for="' + id + '">' + { up: '↑ Arriba', down: '↓ Abajo', left: '← Izquierda', right: '→ Derecha' }[d] + '</label><select id="' + id + '">' + KEYS.map(k => '<option value="' + k[0] + '"' + (k[0] === joy.keys[d] ? ' selected' : '') + '>' + esc(k[1]) + '</option>').join('') + '</select>';
    box.innerHTML = '<div class="joycard"><label class="check" style="margin-top:0"><input type="checkbox" id="joyOn"' + (joy.on ? ' checked' : '') + '><span><b>🕹 Usar el teclado como joystick</b><small>Para juegos con joystick virtual en pantalla: el juego recibe un dedo que se arrastra hacia donde marcan las teclas.</small></span></label>' +
      (joy.on ? '<label for="joyObj">Objeto del joystick (la palanca o su base)</label><select id="joyObj">' + objOpts + '</select>' +
        '<div class="joygrid"><div>' + keySel('joyUp', 'up') + '</div><div>' + keySel('joyDown', 'down') + '</div><div>' + keySel('joyLeft', 'left') + '</div><div>' + keySel('joyRight', 'right') + '</div></div>' +
        '<label class="check"><input type="checkbox" id="joyArrows"' + (joy.arrows ? ' checked' : '') + '><span>También con las flechas del teclado</span></label>' +
        '<label for="joyRadius">Distancia del dedo en píxeles <small class="mut">(0 = automática)</small></label><input type="text" id="joyRadius" inputmode="numeric" value="' + (joy.radius || 0) + '">' +
        (clash.length ? '<div class="warn joyexp">⚠ Una tecla del joystick también activa otro control de la lista de abajo.</div>' : '') +
        '<div class="mut joyexp">Si el personaje no llega a la velocidad máxima, sube la distancia; si se pasa, bájala.</div>' : '') + '</div>';
    $('joyOn').onchange = e => { joy.on = e.target.checked; renderJoy(); };
    if (joy.on) {
      $('joyObj').onchange = e => { joy.obj = e.target.value; };
      for (const [id, d] of [['joyUp', 'up'], ['joyDown', 'down'], ['joyLeft', 'left'], ['joyRight', 'right']]) $(id).onchange = e => { joy.keys[d] = e.target.value; renderJoy(); };
      $('joyArrows').onchange = e => { joy.arrows = e.target.checked; };
      $('joyRadius').onchange = e => { joy.radius = Math.max(0, parseFloat(e.target.value) || 0); };
    }
  }
  $('bSuggest').onclick = () => {
    const taken = new Set(inputs.filter(i => i.bind && i.bind.type === 'key').map(i => i.bind.code));
    const free = SUGGEST.filter(c => !taken.has(c));
    for (const it of inputs) if (!it.bind && free.length) { const c = free.shift(); it.bind = { type: 'key', code: c, label: labelOf(c) }; }
    renderInputs();
  };

  // ---------- 4. carpeta de destino y generar ----------
  const kind = () => document.querySelector('input[name=kind]:checked').value;
  function onKind() {
    const apk = kind() === 'apk';
    $('orientBox').style.display = apk ? '' : 'none'; $('bgBox').style.display = apk ? '' : 'none'; $('sMap').style.display = apk ? 'none' : '';
    $('devtools').closest('label').style.display = apk ? 'none' : '';
    $('bGo').textContent = apk ? 'GENERAR APK' : 'GENERAR .EXE';
    $('pkgBox').style.display = apk ? '' : 'none';
  }
  document.querySelectorAll('input[name=kind]').forEach(r => r.onchange = onKind); onKind();
  const showFolder = () => { $('folderName').textContent = outTree ? outName : 'Sin elegir'; };
  if (PiterApi.canPickFolder()) { $('folderBox').style.display = ''; showFolder(); }
  async function chooseFolder() {
    try { const r = await PiterApi.pickFolder(); outTree = r.uri; outName = r.name; localStorage.setItem('outTree', outTree); localStorage.setItem('outName', outName); showFolder(); return true; }
    catch (e) { return false; }
  }
  $('bFolder').onclick = chooseFolder;

  $('bGo').onclick = async () => {
    if (busy || !compiled) return;
    const name = $('name').value.trim();
    if (!name) { $('name').focus(); log('Escribe el nombre del programa.'); return; }
    if (PiterApi.canPickFolder() && !outTree && !(await chooseFolder())) { log('Elige la carpeta donde guardar el juego.'); return; }
    busy = true; $('bGo').disabled = true; $('log').textContent = ''; $('result').innerHTML = ''; bar(0); try { $('goBar').scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { }
    // Porcentaje total (0-100) de la generación: lo muestra la barra y la notificación
    const isApk = kind() === 'apk';
    const setP = (p, text) => { p = Math.max(0, Math.min(100, p)); bar(Math.round(p)); PiterNotify.update(p, text); };
    let lastAct = Date.now(), lastMsg = 'Preparando…';
    const wd = setInterval(() => { if (Date.now() - lastAct > 15000) { lastAct = Date.now(); log('Sigo trabajando… (' + lastMsg + '; los juegos grandes tardan más)'); } }, 5000);
    const glog = t => {
      lastAct = Date.now(); if (!/^Sigo/.test(t)) lastMsg = t.replace(/….*$/, '…'); log(t); let m;
      if ((m = /^(\d)\/(\d)/.exec(t))) { const i = +m[1], n = +m[2]; setP(n === 2 ? (i === 1 ? 5 : 80) : (i === 1 ? 5 : 10), i === 1 ? 'Preparando…' : 'Armando el paquete…'); }
      else if ((m = /Leyendo el juego… (\d+)%/.exec(t))) setP(isApk ? 10 + m[1] * 0.2 : 10 + m[1] * 0.15, 'Leyendo el juego…');
      else if ((m = /Copiando el motor… (\d+)%/.exec(t))) setP(25 + m[1] * 0.1, 'Copiando el motor…');
      else if ((m = /Copiando archivos del juego… (\d+)%/.exec(t))) setP(isApk ? 30 + m[1] * 0.3 : 35 + m[1] * 0.45, 'Copiando archivos del juego…');
      else if ((m = /Firmando el APK… (\d+)%/.exec(t))) setP(60 + m[1] * 0.2, 'Firmando el APK…');
      else if (/^Firmando el APK/.test(t)) setP(60, 'Firmando el APK…');
      else if (/^Listo:/.test(t)) setP(80, 'Guardando…');
    };
    PiterNotify.start(name);
    try {
      log('Preparando el icono…');
      const icon = await makeIcon(customIcon || src.screenshot || 'default-icon.png');
      compiled.game.inputs = inputs.map(i => Object.assign({}, i));
      { const jc = joyConfig(); if (jc) compiled.game.joystick = jc; else delete compiled.game.joystick; }
      { const op = PiterOptions.collect(); compiled.game.vars = op.vars; compiled.game.meta.render = op.render; }
      const apk = kind() === 'apk';
      const pkgVal = $('pkgId').value.trim();
      if (apk && pkgVal) { const bad = PiterApkBuild.validPackage(pkgVal); if (bad) { clearInterval(wd); PiterNotify.finish(false, 'Corrige la identificación de la app.'); $('pkgMsg').innerHTML = '<span class="bad">✖ ' + esc(bad) + '</span>'; $('pkgId').focus(); busy = false; $('bGo').disabled = false; bar(null); log('Corrige la identificación de la app.'); return; } }
      const common = { pkg: pkgVal, useSaved: $('useSaved').checked, freshStart: $('freshStart').checked, game: compiled.game, deviceVars: src.deviceVars, name, version: $('version').value.trim() || '1.0.0', company: $('company').value.trim(),
        fullscreen: apk ? true : $('fullscreen').checked, devtools: $('devtools').checked, iconIco: icon.ico, iconPng: icon.png, iconsAndroid: icon.android, iconFrames: icon.frames };
      common.background = $('bgPlay').checked;
      if (apk) { const o = $('orient').value, g = compiled.game.meta; common.orientation = o !== 'auto' ? o : (g.W >= g.H ? 'landscape' : 'portrait'); }
      let res = null;
      if (apk) { res = await PiterApi.buildApkDirect(common, glog); if (!res) { log('No encontré la plantilla de APK en esta versión de la app; se crea el paquete para compilar en GitHub.'); res = await PiterApi.buildApk(common, glog); } }
      else res = await PiterApi.build(common, glog);
      log('3/3 Guardando el archivo (puede tardar)…');
      const saved = await PiterApi.save(res.files, p => setP(80 + p * 0.2, 'Guardando el archivo…'), outTree);
      clearInterval(wd); bar(null); PiterNotify.finish(true, name + ' · ' + res.files.map(f => f.fileName).join(' + '));
      let h = '<div class="ok" style="font-weight:600">✔ ¡Listo! ' + res.files.map(f => esc(f.fileName)).join(' + ') + '</div>';
      if (saved.folder) h += '<div style="margin:6px 0">Guardado en: <b>' + esc(outName) + '</b></div>';
      if (saved.folderError) { h += '<div class="warn" style="margin:6px 0">⚠ No se pudo guardar en la carpeta (' + esc(saved.folderError) + '). Elige otra carpeta o usa "Guardar / Enviar".</div>'; outTree = ''; outName = ''; localStorage.removeItem('outTree'); showFolder(); }
      if (res.kind === 'apkdone') h += '<div class="mut" style="margin:6px 0">Abre el archivo <b>' + esc(res.fileName) + '</b> desde tu carpeta para instalarlo (permite "instalar apps de origen desconocido" si te lo pide).<br>Identificación del juego: <b>' + esc(res.pkg) + '</b><br>Su carpeta de datos (no hace falta para jugar): <b>Android/data/' + esc(res.pkg) + '/files/DatosDelJuego</b></div>';
      else if (res.kind === 'apk') h += '<div class="mut" style="margin:6px 0">Para obtener el APK: 1) crea un repositorio en GitHub y sube el <b>.zip</b> a la raíz; 2) sube el <b>.yml</b> dentro de <b>.github/workflows/</b>; 3) en Actions ejecuta el flujo y descarga el artefacto <b>' + esc(res.zipName.replace('-APK-proyecto.zip', '')) + '.apk</b>. Instálalo permitiendo orígenes desconocidos.</div>';
      else h += '<div class="mut" style="margin:6px 0">En la PC: extrae <b>todo</b> el zip en una carpeta y abre <b>' + esc(res.exeName) + '</b>.</div>';
      if (saved.shared) h += '<button id="bShare" class="big" style="background:var(--acc)">' + (saved.folder ? 'Enviar por otra app' : 'Guardar / Enviar') + '</button>';
      $('result').innerHTML = h;
      if (saved.shared) { $('bShare').onclick = () => saved.share().catch(e => log('Compartir: ' + e.message)); if (!saved.folder) saved.share().catch(() => {}); }
    } catch (e) {
      clearInterval(wd); bar(null); PiterNotify.finish(false, e.message); log('ERROR: ' + e.message);
      $('result').innerHTML = '<div class="bad">✖ No se pudo generar: ' + esc(e.message) + '</div>';
    }
    busy = false; $('bGo').disabled = false;
  };
})();
