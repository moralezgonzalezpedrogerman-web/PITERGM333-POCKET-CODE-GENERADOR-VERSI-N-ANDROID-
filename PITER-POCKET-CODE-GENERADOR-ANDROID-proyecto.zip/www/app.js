'use strict';
(function () {
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let src = null, compiled = null, customIcon = null, inputs = [], busy = false;
  let outTree = localStorage.getItem('outTree') || '', outName = localStorage.getItem('outName') || '';

  PiterOptions.init($('optBox'));
  const log = t => { const l = $('log'); l.textContent += t + '\n'; l.scrollTop = l.scrollHeight; };
  const bar = p => { $('bar').style.display = p == null ? 'none' : 'block'; if (p != null) $('bar').firstChild.style.width = p + '%'; };

  // ---------- 1. elegir juego ----------
  $('bFile').onclick = () => $('fileSrc').click();
  $('fileSrc').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (f) loadSource(f); };

  async function loadSource(file) {
    if (busy) return;
    busy = true; $('bGo').disabled = true; $('result').innerHTML = ''; $('report').style.display = 'none';
    $('status').textContent = 'Leyendo el juego…';
    try {
      const res = await PiterApi.prepare(file);
      $('status').textContent = 'Traduciendo los bloques…';
      await new Promise(r => setTimeout(r, 30));
      compiled = PiterCompiler.compile(res.xml, res.files);
      src = res;
      showReport(res, compiled.report);
      $('name').value = compiled.report.programName;
      if (!customIcon) $('icon').src = res.screenshot || 'default-icon.png';
      inputs = (compiled.game.inputs || []).map(i => Object.assign({}, i)); renderInputs();
      PiterOptions.setDeclared(compiled.report.declaredVars);
      for (const id of ['s2', 'sOpt', 'sMap', 's3']) { $(id).style.opacity = 1; $(id).style.pointerEvents = 'auto'; }
      $('bGo').disabled = false;
    } catch (e) {
      src = compiled = null; inputs = []; $('bGo').disabled = true;
      $('status').innerHTML = '<span class="bad">No se pudo leer el juego: ' + esc(e.message) + '</span>';
    }
    busy = false;
  }

  function list(o) { return Object.keys(o).sort().map(k => esc(k) + (o[k] > 1 ? ' ×' + o[k] : '')).join(', '); }
  function showReport(res, r) {
    $('status').innerHTML = '<b>' + esc(r.programName) + '</b> <span class="mut">(' + esc(res.sourceName) + ')</span>';
    let h = '<span class="pill">' + r.scenes + ' escena(s)</span><span class="pill">' + r.objects + ' objetos</span><span class="pill">' +
      r.scripts + ' scripts</span><span class="pill">' + r.bricks + ' bloques</span><span class="pill">' + res.files.length + ' archivos</span><ul>';
    if (r.ok) h += '<li class="ok">✔ Todos los bloques y fórmulas del juego están soportados.</li>';
    if (Object.keys(r.unsupportedBricks).length) h += '<li class="bad">✖ Bloques sin soporte (no harán nada): ' + list(r.unsupportedBricks) + '</li>';
    if (Object.keys(r.unsupportedScripts).length) h += '<li class="bad">✖ Scripts sin soporte: ' + list(r.unsupportedScripts) + '</li>';
    if (Object.keys(r.unsupportedFormulas).length) h += '<li class="bad">✖ Fórmulas sin soporte (valen 0): ' + list(r.unsupportedFormulas) + '</li>';
    if (r.missingAssets.length) h += '<li class="bad">✖ Faltan archivos del juego: ' + esc(r.missingAssets.slice(0, 12).join(', ')) + (r.missingAssets.length > 12 ? '…' : '') + '</li>';
    if (Object.keys(r.ignoredBricks).length) h += '<li class="warn">⚠ Bloques de celular/hardware que en PC no hacen nada: ' + list(r.ignoredBricks) + '</li>';
    if (Object.keys(r.mobileSensors).length) h += '<li class="warn">⚠ Sensores de celular (en PC valen 0): ' + list(r.mobileSensors) + '</li>';
    const phys = Object.keys(r.bricksUsed).filter(k => /^(SetPhysicsObjectType|SetVelocity|SetGravity|SetMass|SetBounce|SetFriction|TurnLeftSpeed|TurnRightSpeed)/.test(k));
    if (phys.length) h += '<li class="warn">⚠ Este juego usa física: se simula de forma aproximada, puede no ser idéntica a Pocket Code.</li>';
    h += '</ul><details><summary>Ver todos los bloques usados</summary><div class="mut" style="margin-top:6px">' + list(r.bricksUsed) + '</div></details>';
    $('report').innerHTML = h; $('report').style.display = 'block';
  }

  // ---------- 2. personalizar ----------
  $('bIcon').onclick = () => $('fileIcon').click();
  $('fileIcon').onchange = e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    const fr = new FileReader();
    fr.onload = () => { customIcon = fr.result; $('icon').src = customIcon; $('bIconDel').style.display = ''; $('iconNote').textContent = f.name; };
    fr.readAsDataURL(f);
  };
  $('bIconDel').onclick = () => {
    customIcon = null; $('bIconDel').style.display = 'none'; $('icon').src = (src && src.screenshot) || 'default-icon.png';
    $('iconNote').textContent = 'Si no eliges, se usa la captura del juego o un icono por defecto.';
  };
  const loadImage = url => new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('No pude leer la imagen del logotipo')); im.src = url; });
  async function makeIcon(url) { // .ico con varios tamaños (fotogramas PNG) + PNG de 256 px
    const img = await loadImage(url), sizes = [256, 128, 64, 48, 32, 16], pngs = [], frames = [];
    for (const s of sizes) {
      const c = document.createElement('canvas'); c.width = c.height = s;
      const x = c.getContext('2d'); x.imageSmoothingQuality = 'high';
      const k = Math.min(s / img.naturalWidth, s / img.naturalHeight), w = img.naturalWidth * k, h = img.naturalHeight * k;
      x.drawImage(img, (s - w) / 2, (s - h) / 2, w, h);
      const blob = await new Promise(r => c.toBlob(r, 'image/png'));
      pngs.push(new Uint8Array(await blob.arrayBuffer()));
      // fotograma para el .exe: PNG a 256 px y BMP (DIB) en los demás tamaños (lo que Windows espera)
      frames.push(s >= 256 ? { size: s, data: pngs[pngs.length - 1] } : { size: s, data: PiterPE.dibFromRgba(x.getImageData(0, 0, s, s).data, s) });
    }
    const n = sizes.length; let off = 6 + 16 * n;
    const buf = new ArrayBuffer(off + pngs.reduce((a, p) => a + p.length, 0)), dv = new DataView(buf), u8 = new Uint8Array(buf);
    dv.setUint16(0, 0, true); dv.setUint16(2, 1, true); dv.setUint16(4, n, true);
    sizes.forEach((s, i) => {
      const e = 6 + 16 * i;
      u8[e] = s >= 256 ? 0 : s; u8[e + 1] = s >= 256 ? 0 : s;
      dv.setUint16(e + 4, 1, true); dv.setUint16(e + 6, 32, true); dv.setUint32(e + 8, pngs[i].length, true); dv.setUint32(e + 12, off, true);
      u8.set(pngs[i], off); off += pngs[i].length;
    });
    const android = {};
    for (const sz of [48, 72, 96, 144, 192]) {
      const c = document.createElement('canvas'); c.width = c.height = sz;
      const x = c.getContext('2d'); x.imageSmoothingQuality = 'high';
      const k = Math.min(sz / img.naturalWidth, sz / img.naturalHeight), w = img.naturalWidth * k, h = img.naturalHeight * k;
      x.drawImage(img, (sz - w) / 2, (sz - h) / 2, w, h);
      android[sz] = new Uint8Array(await (await new Promise(r => c.toBlob(r, 'image/png'))).arrayBuffer());
    }
    return { ico: u8, png: pngs[0], android, frames };
  }

  // ---------- 3. mapear botones ----------
  const KEYS = [['Space', 'Espacio'], ['Enter', 'Enter'], ['ArrowLeft', '← Izquierda'], ['ArrowRight', '→ Derecha'], ['ArrowUp', '↑ Arriba'], ['ArrowDown', '↓ Abajo'],
    ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(c => ['Key' + c, c]), ...'0123456789'.split('').map(c => ['Digit' + c, c]),
    ['ShiftLeft', 'Shift izq.'], ['ControlLeft', 'Ctrl izq.'], ['AltLeft', 'Alt izq.'], ['Tab', 'Tab'],
    ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => ['F' + n, 'F' + n])];
  const MOUSE = [[0, 'Clic izquierdo'], [1, 'Clic central'], [2, 'Clic derecho']];
  const SUGGEST = ['Space', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'KeyZ', 'KeyX', 'KeyC', 'KeyA', 'KeyS', 'KeyD', 'KeyW', 'KeyE', 'KeyQ', 'KeyR', 'KeyF'];
  const labelOf = code => (KEYS.find(k => k[0] === code) || [0, code])[1];
  const bindVal = b => b ? (b.type === 'key' ? 'key:' + b.code : 'mouse:' + b.button) : '';
  const itemName = i => i.screen ? 'Pantalla tocada (en cualquier parte)' : i.obj + (i.scene && compiled.game.scenes.length > 1 ? '  (escena ' + i.scene + ')' : '');
  const itemKind = i => i.screen ? 'bloque "cuando se toca la pantalla" / "dedo tocando"' : [i.tap ? 'cuando se pulse' : '', i.hold ? 'mientras se toca' : ''].filter(Boolean).join(' + ');

  function renderInputs() {
    const box = $('mapList');
    if (!inputs.length) { box.innerHTML = '<div class="mut" style="margin-top:8px">Este juego no usa controles táctiles que se puedan asignar.</div>'; $('bSuggest').style.display = 'none'; return; }
    $('bSuggest').style.display = '';
    const used = {}; for (const i of inputs) if (i.bind) (used[bindVal(i.bind)] = used[bindVal(i.bind)] || []).push(itemName(i));
    const opts = '<option value="">Sin asignar</option><optgroup label="Teclado">' + KEYS.map(k => '<option value="key:' + k[0] + '">' + esc(k[1]) + '</option>').join('') +
      '</optgroup><optgroup label="Mouse">' + MOUSE.map(m => '<option value="mouse:' + m[0] + '">' + m[1] + '</option>').join('') + '</optgroup>';
    box.innerHTML = '';
    inputs.forEach(it => {
      const v = bindVal(it.bind), dup = v && used[v].length > 1, row = document.createElement('div'); row.className = 'maprow';
      row.innerHTML = '<b>' + esc(itemName(it)) + '</b><small>' + esc(itemKind(it)) + '</small>' +
        (dup ? '<small class="warn">⚠ Esa misma tecla también activa: ' + esc(used[v].filter(x => x !== itemName(it)).join(', ')) + '</small>' : '') +
        (v === 'mouse:0' ? '<small class="warn">⚠ El clic izquierdo activará este control en cualquier parte de la pantalla.</small>' : '') +
        '<select>' + opts + '</select>';
      const sel = row.querySelector('select'); sel.value = v;
      sel.onchange = () => {
        const [t, x] = sel.value.split(':');
        if (!sel.value) delete it.bind;
        else if (t === 'key') it.bind = { type: 'key', code: x, label: labelOf(x) };
        else it.bind = { type: 'mouse', button: +x, label: MOUSE[+x][1] };
        renderInputs();
      };
      box.appendChild(row);
    });
  }
  $('bSuggest').onclick = () => {
    const taken = new Set(inputs.filter(i => i.bind && i.bind.type === 'key').map(i => i.bind.code));
    const free = SUGGEST.filter(c => !taken.has(c));
    for (const it of inputs) if (!it.bind && free.length) { const c = free.shift(); it.bind = { type: 'key', code: c, label: labelOf(c) }; }
    renderInputs();
  };

  // ---------- 4. carpeta de destino y generar ----------
  const kind = () => document.querySelector('input[name=kind]:checked').value;
  function onKind() {
    const apk = kind() === 'apk';
    $('orientBox').style.display = apk ? '' : 'none'; $('sMap').style.display = apk ? 'none' : '';
    $('devtools').closest('label').style.display = apk ? 'none' : '';
    $('bGo').textContent = apk ? 'GENERAR PROYECTO APK' : 'GENERAR .EXE';
  }
  document.querySelectorAll('input[name=kind]').forEach(r => r.onchange = onKind); onKind();
  const showFolder = () => { $('folderName').textContent = outTree ? outName : 'Sin elegir'; };
  if (PiterApi.canPickFolder()) { $('folderBox').style.display = ''; showFolder(); }
  async function chooseFolder() {
    try { const r = await PiterApi.pickFolder(); outTree = r.uri; outName = r.name; localStorage.setItem('outTree', outTree); localStorage.setItem('outName', outName); showFolder(); return true; }
    catch (e) { return false; }
  }
  $('bFolder').onclick = chooseFolder;

  $('bGo').onclick = async () => {
    if (busy || !compiled) return;
    const name = $('name').value.trim();
    if (!name) { $('name').focus(); log('Escribe el nombre del programa.'); return; }
    if (PiterApi.canPickFolder() && !outTree && !(await chooseFolder())) { log('Elige la carpeta donde guardar el juego.'); return; }
    busy = true; $('bGo').disabled = true; $('log').textContent = ''; $('result').innerHTML = ''; bar(0);
    try {
      log('Preparando el icono…');
      const icon = await makeIcon(customIcon || src.screenshot || 'default-icon.png');
      compiled.game.inputs = inputs.map(i => Object.assign({}, i));
      { const op = PiterOptions.collect(); compiled.game.vars = op.vars; compiled.game.meta.render = op.render; }
      const apk = kind() === 'apk';
      const common = { game: compiled.game, deviceVars: src.deviceVars, name, version: $('version').value.trim() || '1.0.0', company: $('company').value.trim(),
        fullscreen: apk ? true : $('fullscreen').checked, devtools: $('devtools').checked, iconIco: icon.ico, iconPng: icon.png, iconsAndroid: icon.android, iconFrames: icon.frames };
      if (apk) { const o = $('orient').value, g = compiled.game.meta; common.orientation = o !== 'auto' ? o : (g.W >= g.H ? 'landscape' : 'portrait'); }
      const res = await (apk ? PiterApi.buildApk(common, log) : PiterApi.build(common, log));
      log('3/3 Guardando el archivo (puede tardar)…');
      const saved = await PiterApi.save(res.files, p => bar(p), outTree);
      bar(null);
      let h = '<div class="ok" style="font-weight:600">✔ ¡Listo! ' + res.files.map(f => esc(f.fileName)).join(' + ') + '</div>';
      if (saved.folder) h += '<div style="margin:6px 0">Guardado en: <b>' + esc(outName) + '</b></div>';
      if (saved.folderError) { h += '<div class="warn" style="margin:6px 0">⚠ No se pudo guardar en la carpeta (' + esc(saved.folderError) + '). Elige otra carpeta o usa "Guardar / Enviar".</div>'; outTree = ''; outName = ''; localStorage.removeItem('outTree'); showFolder(); }
      if (res.kind === 'apk') h += '<div class="mut" style="margin:6px 0">Para obtener el APK: 1) crea un repositorio en GitHub y sube el <b>.zip</b> a la raíz; 2) sube el <b>.yml</b> dentro de <b>.github/workflows/</b>; 3) en Actions ejecuta el flujo y descarga el artefacto <b>' + esc(res.zipName.replace('-APK-proyecto.zip', '')) + '.apk</b>. Instálalo permitiendo orígenes desconocidos.</div>';
      else h += '<div class="mut" style="margin:6px 0">En la PC: extrae <b>todo</b> el zip en una carpeta y abre <b>' + esc(res.exeName) + '</b>.</div>';
      if (saved.shared) h += '<button id="bShare" class="big" style="background:var(--acc)">' + (saved.folder ? 'Enviar por otra app' : 'Guardar / Enviar') + '</button>';
      $('result').innerHTML = h;
      if (saved.shared) { $('bShare').onclick = () => saved.share().catch(e => log('Compartir: ' + e.message)); if (!saved.folder) saved.share().catch(() => {}); }
    } catch (e) {
      bar(null); log('ERROR: ' + e.message);
      $('result').innerHTML = '<div class="bad">✖ No se pudo generar: ' + esc(e.message) + '</div>';
    }
    busy = false; $('bGo').disabled = false;
  };
})();
