'use strict';
// Panel "Rendimiento y variables" (lo usan el generador de PC y el de Android)
(function (root) {
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const SEL = 'width:100%;background:#12141a;border:1px solid #2d3240;color:#e9ebf1;border-radius:8px;padding:10px;font:inherit;min-height:42px';
  const INP = 'background:#12141a;border:1px solid #2d3240;color:#e9ebf1;border-radius:8px;padding:9px;font:inherit;min-height:42px;min-width:0';
  let box = null, vars = [];

  const select = (id, label, opts, def, hint) =>
    '<label>' + label + '</label><select id="' + id + '" style="' + SEL + '">' +
    opts.map(o => '<option value="' + o[0] + '"' + (String(o[0]) === String(def) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select>' +
    (hint ? '<div class="mut" style="font-size:12px;margin-top:3px">' + hint + '</div>' : '');
  const check = (id, label, hint, on) =>
    '<label class="check"><input type="checkbox" id="' + id + '"' + (on ? ' checked' : '') + '><span>' + label + '<small>' + hint + '</small></span></label>';

  function renderVars() {
    const list = box.querySelector('#o_vars');
    list.innerHTML = vars.length ? '' : '<div class="mut" style="font-size:12px">Este proyecto no trae variables con valor inicial. Puedes agregar las tuyas.</div>';
    vars.forEach((v, i) => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;gap:8px;margin:6px 0';
      row.innerHTML = '<input type="text" placeholder="nombre (ej. vida)" value="' + esc(v.name) + '" style="flex:2;' + INP + '">' +
        '<input type="text" placeholder="valor (ej. 100)" value="' + esc(v.value) + '" style="flex:1;' + INP + '">' +
        '<button class="sec" style="padding:8px 12px" title="Quitar">✕</button>';
      const [n, val, del] = row.querySelectorAll('input,button');
      n.oninput = () => { v.name = n.value; }; val.oninput = () => { v.value = val.value; };
      del.onclick = () => { vars.splice(i, 1); renderVars(); };
      list.appendChild(row);
    });
  }

  function init(el) {
    box = el;
    box.innerHTML =
      '<div style="font-weight:600;margin:2px 0 4px">Calidad de imagen</div>' +
      select('o_scale', 'Escala de resolución', [[0.5, '50 % (ahorra mucha memoria)'], [0.75, '75 %'], [1, '100 % (normal)'], [1.5, '150 % (más nítido)'], [2, '200 % (muy nítido)']], 1,
        'Más escala = imágenes más nítidas pero usa más memoria y batería. Menos escala = más ligero.') +
      select('o_smooth', 'Suavizado de las imágenes', [['high', 'Alto (más lento con imágenes grandes)'], ['low', 'Normal (recomendado, más rápido)'], ['off', 'Sin suavizar (píxeles nítidos)']], 'low', '"Sin suavizar" es mejor para juegos de píxeles.') +
      '<div style="font-weight:600;margin:16px 0 4px">Rendimiento y memoria</div>' +
      select('o_mem', 'Memoria para imágenes', [[0, 'Automática (recomendada: se adapta al dispositivo)'], [12, 'Muy baja (celulares de gama baja)'], [24, 'Baja'], [48, 'Media'], [96, 'Alta'], [-1, 'Sin límite (usa más memoria)']], 0,
        'Es solo un tope: las imágenes se ven igual. Si el juego necesita más, se cargan y se sueltan según se usan, y la escena siguiente se precarga.') +
      select('o_fps', 'Límite de fotogramas por segundo', [[60, '60 FPS (normal)'], [30, '30 FPS (ahorra batería y evita calentamiento)'], [0, 'Sin límite']], 60, '') +
      check('o_opt', 'Liberar memoria al cambiar de escena', 'Detiene scripts "por siempre", sonidos, videos y esperas de la escena anterior y suelta sus imágenes.', true) +
      check('o_shrink', 'Reducir imágenes enormes en memoria', 'Las imágenes de más de 2048 px se guardan reducidas (se siguen dibujando del mismo tamaño). Recomendado: carga más rápido y usa menos memoria.', true) +
      '<div style="font-weight:600;margin:16px 0 4px">Variables con valor inicial</div>' +
      '<div class="mut" style="font-size:12px;margin-bottom:6px">Estas variables arrancan con ese valor (vida = 100, etc.) en lugar de 0. Revísalas y corrígelas si hace falta.</div>' +
      '<div id="o_vars"></div><button id="o_add" class="sec" style="margin-top:6px">+ Agregar variable</button>';
    box.querySelector('#o_add').onclick = () => { vars.push({ name: '', value: '' }); renderVars(); };
    renderVars();
  }
  function setDeclared(list) { vars = (list || []).map(v => ({ name: v.name, value: String(v.value) })); if (box) renderVars(); }
  function collect() {
    const g = id => box.querySelector('#' + id), out = {};
    for (const v of vars) {
      const n = v.name.trim(); if (!n) continue;
      const t = String(v.value).trim();
      out[n] = /^-?\d+(\.\d+)?$/.test(t) ? Number(t) : (t === '' ? 0 : t);
    }
    return {
      vars: out,
      render: { scale: parseFloat(g('o_scale').value), smooth: g('o_smooth').value, fps: parseInt(g('o_fps').value, 10), optimize: g('o_opt').checked, maxImage: g('o_shrink').checked ? 2048 : 0, memMB: parseInt(g('o_mem').value, 10) }
    };
  }
  root.PiterOptions = { init, setDeclared, collect };
})(typeof self !== 'undefined' ? self : this);
