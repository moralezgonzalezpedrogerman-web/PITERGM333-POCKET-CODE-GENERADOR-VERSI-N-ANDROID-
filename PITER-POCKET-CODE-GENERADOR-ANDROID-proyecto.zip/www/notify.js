// Avisa del avance de la generación fuera de la app (notificación en Android; barra de la tarea y aviso en Windows).
(function () {
  const P = () => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.ProgressNotify) || null;
  let last = -1, active = false;
  const call = (m, o) => { try { const p = P(); if (p && p[m]) { const r = p[m](o); if (r && r.catch) r.catch(() => {}); } } catch (e) {} };
  window.PiterNotify = {
    start(title) { active = true; last = -1; call('start', { title: String(title || 'Juego'), text: 'Preparando…' }); },
    update(pct, text) {
      if (!active) return; pct = Math.max(0, Math.min(100, Math.round(pct)));
      if (pct === last) return; last = pct; call('update', { percent: pct, text: String(text || '') });
    },
    finish(ok, text) { if (!active) return; active = false; call('finish', { ok: !!ok, text: String(text || '') }); }
  };
})();
