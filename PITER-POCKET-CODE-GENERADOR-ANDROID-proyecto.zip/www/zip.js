'use strict';
// Lector/escritor de ZIP sin librerías. Copia las entradas ya comprimidas (sin descomprimir)
// y arma el resultado como un Blob (no carga todo en memoria).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiterZip = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const enc = new TextEncoder();
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u8) { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }

  async function readCentral(blob) {
    const tailLen = Math.min(blob.size, 65557);
    const tail = new DataView(await blob.slice(blob.size - tailLen).arrayBuffer());
    let p = -1;
    for (let i = tailLen - 22; i >= 0; i--) if (tail.getUint32(i, true) === 0x06054b50) { p = i; break; }
    if (p < 0) throw new Error('El archivo no es un ZIP / .catrobat válido');
    const count = tail.getUint16(p + 10, true), cdSize = tail.getUint32(p + 12, true), cdOff = tail.getUint32(p + 16, true);
    if (cdOff === 0xFFFFFFFF || count === 0xFFFF) throw new Error('El archivo es demasiado grande (ZIP64 no soportado)');
    const buf = await blob.slice(cdOff, cdOff + cdSize).arrayBuffer();
    const dv = new DataView(buf), u8 = new Uint8Array(buf), dec = new TextDecoder('utf-8');
    const recs = []; let o = 0;
    for (let i = 0; i < count; i++) {
      if (dv.getUint32(o, true) !== 0x02014b50) throw new Error('ZIP dañado (directorio central)');
      const nl = dv.getUint16(o + 28, true), el = dv.getUint16(o + 30, true), cl = dv.getUint16(o + 32, true);
      recs.push({ method: dv.getUint16(o + 10, true), crc: dv.getUint32(o + 16, true), comp: dv.getUint32(o + 20, true), size: dv.getUint32(o + 24, true),
        off: dv.getUint32(o + 42, true), name: dec.decode(u8.subarray(o + 46, o + 46 + nl)) });
      o += 46 + nl + el + cl;
    }
    return recs;
  }
  // Lee de golpe (en paralelo) las cabeceras locales de todas las entradas: evita miles de lecturas una por una
  // Calcula dónde empiezan los datos de cada archivo. Antes se hacía una lectura de 30 bytes por archivo (miles de lecturas
  // lentas en el celular); ahora se agrupan los archivos cercanos y se lee en bloques grandes de hasta 32 MB.
  async function prefetch(blob, recs, conc, onProgress) {
    const todo = recs.filter(r => r.ds === undefined && !r.name.endsWith('/')).sort((x, y) => x.off - y.off);
    if (!todo.length) return;
    const GAP = 4 << 20, MAXW = 32 << 20, groups = [];
    for (let i = 0; i < todo.length;) {
      let j = i; const start = todo[i].off; let end = start + 30;
      while (j + 1 < todo.length && todo[j + 1].off - end <= GAP && todo[j + 1].off + 30 - start <= MAXW) { j++; end = todo[j].off + 30; }
      groups.push({ i, j, start, end }); i = j + 1;
    }
    let done = 0, lastPct = -1; const CONC = Math.max(1, Math.min(conc || 3, 4));
    for (let g = 0; g < groups.length; g += CONC) {
      await Promise.all(groups.slice(g, g + CONC).map(async G => {
        const buf = await blob.slice(G.start, G.end).arrayBuffer();
        for (let k = G.i; k <= G.j; k++) {
          const r = todo[k], h = new DataView(buf, r.off - G.start, 30);
          if (h.getUint32(0, true) !== 0x04034b50) throw new Error('ZIP dañado (' + r.name + ')');
          r.ds = r.off + 30 + h.getUint16(26, true) + h.getUint16(28, true);
        }
        done += G.j - G.i + 1;
      }));
      if (onProgress) { const p = Math.round(done / todo.length * 100); if (p !== lastPct) { lastPct = p; onProgress(p); } }
    }
  }
  async function dataSlice(blob, rec) {
    let ds = rec.ds;
    if (ds === undefined) {
      const h = new DataView(await blob.slice(rec.off, rec.off + 30).arrayBuffer());
      if (h.getUint32(0, true) !== 0x04034b50) throw new Error('ZIP dañado (' + rec.name + ')');
      ds = rec.off + 30 + h.getUint16(26, true) + h.getUint16(28, true);
    }
    const sl = blob.slice(ds, ds + rec.comp);
    sl.__src = { blob, start: ds }; // de dónde sale: así el APK se puede leer del archivo original en bloques grandes (ver VBlob)
    return sl;
  }

  // ---------- lectura en bloques grandes ----------
  // Un APK armado con miles de trozos pequeños del archivo original es lentísimo de leer en el teléfono (cada trozo abre el archivo otra vez:
  // ~3 MB/s). VBlob conoce de dónde sale cada trozo y lo lee del original en ventanas de 16 MB seguidas, con la siguiente ya pedida de antemano.
  const SRC_WIN = 16 << 20, srcReaders = new WeakMap();
  class SrcReader {
    constructor(blob) { this.blob = blob; this.win = null; this.next = null; this.nextStart = -1; }
    async load(start) { const end = Math.min(this.blob.size, start + SRC_WIN); return { start, end, buf: new Uint8Array(await this.blob.slice(start, end).arrayBuffer()) }; }
    async copy(dest, destOff, s, n) {
      while (n > 0) {
        let w = this.win;
        if (!w || s < w.start || s >= w.end) {
          const start = Math.floor(s / SRC_WIN) * SRC_WIN;
          w = this.win = (this.next && this.nextStart === start) ? await this.next : await this.load(start);
          this.nextStart = w.end; this.next = w.end < this.blob.size ? this.load(w.end) : null; if (this.next) this.next.catch(() => {}); // pide ya la siguiente ventana
        }
        const m = Math.min(n, w.end - s);
        dest.set(w.buf.subarray(s - w.start, s - w.start + m), destOff);
        s += m; destOff += m; n -= m;
      }
    }
  }
  const readerOf = blob => { let r = srcReaders.get(blob); if (!r) srcReaders.set(blob, r = new SrcReader(blob)); return r; };
  class VBlob {
    constructor(parts) {
      this.segs = []; let pos = 0;
      for (const p of parts) {
        let seg;
        if (p instanceof VBlob) seg = { t: 'v', v: p, len: p.size };
        else if (p instanceof ArrayBuffer) seg = { t: 'm', b: new Uint8Array(p), len: p.byteLength };
        else if (ArrayBuffer.isView(p)) seg = { t: 'm', b: new Uint8Array(p.buffer, p.byteOffset, p.byteLength), len: p.byteLength };
        else if (p && p.__src) seg = { t: 's', r: readerOf(p.__src.blob), start: p.__src.start, len: p.size };
        else seg = { t: 'b', blob: p, len: p.size };
        if (!seg.len) continue; seg.pos = pos; pos += seg.len; this.segs.push(seg);
      }
      this.size = pos; this.type = 'application/vnd.android.package-archive';
    }
    // copia los bytes [a, b) a dest a partir de destOff
    async readInto(dest, destOff, a, b) {
      const S = this.segs; let lo = 0, hi = S.length - 1;
      while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (S[mid].pos <= a) lo = mid; else hi = mid - 1; }
      for (let i = lo; i < S.length && S[i].pos < b; i++) {
        const sg = S[i], x = Math.max(a, sg.pos), y = Math.min(b, sg.pos + sg.len), n = y - x, o = destOff + (x - a), at = x - sg.pos;
        if (sg.t === 'm') dest.set(sg.b.subarray(at, at + n), o);
        else if (sg.t === 's') await sg.r.copy(dest, o, sg.start + at, n);
        else if (sg.t === 'v') await sg.v.readInto(dest, o, at, at + n);
        else dest.set(new Uint8Array(await sg.blob.slice(at, at + n).arrayBuffer()), o);
      }
    }
    slice(a, b) { const self = this; a = Math.max(0, a); b = Math.min(this.size, b); return { size: b - a, async arrayBuffer() { const u = new Uint8Array(b - a); await self.readInto(u, 0, a, b); return u.buffer; } }; }
    // para fuera de Android (descarga en el navegador): un Blob normal
    async toBlob() { const out = []; for (let o = 0; o < this.size; o += 16 << 20) out.push(await this.slice(o, Math.min(this.size, o + (16 << 20))).arrayBuffer()); return new Blob(out, { type: this.type }); }
  }
  async function readBytes(blob, rec) {
    const sl = await dataSlice(blob, rec);
    if (rec.method === 0) return new Uint8Array(await sl.arrayBuffer());
    if (rec.method !== 8) throw new Error('Compresión no soportada en ' + rec.name);
    if (typeof DecompressionStream === 'undefined') throw new Error('Este Android/WebView es muy viejo (falta DecompressionStream). Actualiza "Android System WebView".');
    return new Uint8Array(await new Response(sl.stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
  }
  const readText = async (blob, rec) => new TextDecoder('utf-8').decode(await readBytes(blob, rec));

  class ZipWriter {
    constructor() {
      this.parts = []; this.cd = []; this.pos = 0;
      const d = new Date();
      this.time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
      this.date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    }
    // align: si es > 0, el inicio de los datos queda en una posición múltiplo de ese número (como zipalign; lo pide Android para resources.arsc)
    addRaw(name, method, crc, comp, size, data, align) {
      const nb = enc.encode(name), extra = align ? (align - (this.pos + 30 + nb.length) % align) % align : 0;
      const h = new ArrayBuffer(30 + nb.length + extra), dv = new DataView(h);
      dv.setUint32(0, 0x04034b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 0x0800, true); dv.setUint16(8, method, true);
      dv.setUint16(10, this.time, true); dv.setUint16(12, this.date, true); dv.setUint32(14, crc, true);
      dv.setUint32(18, comp, true); dv.setUint32(22, size, true); dv.setUint16(26, nb.length, true); dv.setUint16(28, extra, true);
      new Uint8Array(h).set(nb, 30);
      this.cd.push({ nb, method, crc, comp, size, off: this.pos });
      this.parts.push(h, data); this.pos += h.byteLength + comp;
      if (this.pos > 0xFFFFFF00 || this.cd.length >= 0xFFFF) throw new Error('El resultado es demasiado grande para un ZIP (4 GB / 65 535 archivos)');
    }
    addBytes(name, bytes, align) { this.addRaw(name, 0, crc32(bytes), bytes.length, bytes.length, bytes, align); }
    // Partes del ZIP por separado (hace falta para firmar el APK: la firma va entre los archivos y el directorio central)
    build() {
      const cdStart = this.pos; let cdSize = 0; const cdParts = [];
      for (const e of this.cd) {
        const b = new ArrayBuffer(46 + e.nb.length), dv = new DataView(b);
        dv.setUint32(0, 0x02014b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 20, true); dv.setUint16(8, 0x0800, true); dv.setUint16(10, e.method, true);
        dv.setUint16(12, this.time, true); dv.setUint16(14, this.date, true); dv.setUint32(16, e.crc, true); dv.setUint32(20, e.comp, true); dv.setUint32(24, e.size, true);
        dv.setUint16(28, e.nb.length, true); dv.setUint32(42, e.off, true); new Uint8Array(b).set(e.nb, 46);
        cdParts.push(b); cdSize += b.byteLength;
      }
      const count = this.cd.length;
      return { entries: new Blob(this.parts), entriesV: new VBlob(this.parts), entriesSize: cdStart, cd: new Blob(cdParts), cdSize,
        eocd: cdOffset => { const t = new ArrayBuffer(22), dv = new DataView(t);
          dv.setUint32(0, 0x06054b50, true); dv.setUint16(8, count, true); dv.setUint16(10, count, true);
          dv.setUint32(12, cdSize, true); dv.setUint32(16, cdOffset, true); return t; } };
    }
    finish() { const b = this.build(); return new Blob([b.entries, b.cd, b.eocd(b.entriesSize)], { type: 'application/zip' }); }
  }

  // Arma el ZIP final: motor de Electron (del molde) + juego traducido + archivos del juego
  async function buildPackage(o, progress) {
    const w = new ZipWriter(), P = o.prefix, skipSrc = new Set(['code.xml', 'DeviceVariables.json', '.listo']);
    const tpl = o.templateRecs.filter(r => !r.name.endsWith('/'));
    await prefetch(o.templateBlob, tpl); { let lp = -10; await prefetch(o.srcBlob, o.srcRecs, 3, p => { if (progress && (p - lp >= 5 || p === 100)) { lp = p; progress('Leyendo el juego… ' + p + '%'); } }); }
    let i = 0;
    for (const r of tpl) {
      const nm = r.name === 'electron.exe' ? (o.launcher ? 'motor.exe' : o.exeName) : r.name;
      w.addRaw(P + nm, r.method, r.crc, r.comp, r.size, await dataSlice(o.templateBlob, r));
      if (progress && ++i % 20 === 0) progress('Copiando el motor… ' + Math.round(i / tpl.length * 100) + '%');
    }
    if (o.launcher) w.addBytes(P + o.exeName, o.launcher);
    for (const f in o.appFiles) w.addBytes(P + 'resources/app/' + f, o.appFiles[f]);
    w.addBytes(P + 'resources/app/game.json', enc.encode(JSON.stringify(o.game)));
    w.addBytes(P + 'resources/app/package.json', enc.encode(JSON.stringify({ name: o.slug, productName: o.name, version: o.version, main: 'main.js' }, null, 2)));
    if (o.iconPng) w.addBytes(P + 'resources/app/icon.png', o.iconPng);
    if (o.iconIco) w.addBytes(P + 'icono.ico', o.iconIco);
    if (o.readme) w.addBytes(P + 'LEEME.txt', enc.encode(o.readme));
    if (o.info) w.addBytes(P + 'DatosDelJuego/info.json', enc.encode(o.info)); // identificación del juego (no hace falta para jugar)
    const ents = o.srcRecs.filter(r => !r.name.endsWith('/') && r.name.startsWith(o.srcPrefix) && !r.name.split('/').includes('..'));
    i = 0;
    for (const r of ents) {
      const rel = r.name.slice(o.srcPrefix.length);
      if (skipSrc.has(rel)) continue;
      if (r.method !== 0 && r.method !== 8) throw new Error('Compresión no soportada en el archivo del juego: ' + rel);
      w.addRaw(P + 'resources/app/assets/' + rel, r.method, r.crc, r.comp, r.size, await dataSlice(o.srcBlob, r));
      if (progress && ++i % 50 === 0) progress('Copiando archivos del juego… ' + Math.round(i / ents.length * 100) + '%');
    }
    return w.finish();
  }
  return { crc32, readCentral, readBytes, readText, dataSlice, prefetch, ZipWriter, VBlob, buildPackage };
});
