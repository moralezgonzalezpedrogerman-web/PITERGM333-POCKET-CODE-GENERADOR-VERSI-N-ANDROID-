'use strict';
// Lector/escritor de ZIP sin librerías. Copia las entradas ya comprimidas (sin descomprimir)
// y arma el resultado como un Blob (no carga todo en memoria).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiterZip = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const enc = new TextEncoder();
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u8) { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }

  async function readCentral(blob) {
    const tailLen = Math.min(blob.size, 65557);
    const tail = new DataView(await blob.slice(blob.size - tailLen).arrayBuffer());
    let p = -1;
    for (let i = tailLen - 22; i >= 0; i--) if (tail.getUint32(i, true) === 0x06054b50) { p = i; break; }
    if (p < 0) throw new Error('El archivo no es un ZIP / .catrobat válido');
    const count = tail.getUint16(p + 10, true), cdSize = tail.getUint32(p + 12, true), cdOff = tail.getUint32(p + 16, true);
    if (cdOff === 0xFFFFFFFF || count === 0xFFFF) throw new Error('El archivo es demasiado grande (ZIP64 no soportado)');
    const buf = await blob.slice(cdOff, cdOff + cdSize).arrayBuffer();
    const dv = new DataView(buf), u8 = new Uint8Array(buf), dec = new TextDecoder('utf-8');
    const recs = []; let o = 0;
    for (let i = 0; i < count; i++) {
      if (dv.getUint32(o, true) !== 0x02014b50) throw new Error('ZIP dañado (directorio central)');
      const nl = dv.getUint16(o + 28, true), el = dv.getUint16(o + 30, true), cl = dv.getUint16(o + 32, true);
      recs.push({ method: dv.getUint16(o + 10, true), crc: dv.getUint32(o + 16, true), comp: dv.getUint32(o + 20, true), size: dv.getUint32(o + 24, true),
        off: dv.getUint32(o + 42, true), name: dec.decode(u8.subarray(o + 46, o + 46 + nl)) });
      o += 46 + nl + el + cl;
    }
    return recs;
  }
  // Lee de golpe (en paralelo) las cabeceras locales de todas las entradas: evita miles de lecturas una por una
  async function prefetch(blob, recs, conc) {
    conc = conc || 64;
    const todo = recs.filter(r => r.ds === undefined && !r.name.endsWith('/'));
    for (let i = 0; i < todo.length; i += conc) {
      await Promise.all(todo.slice(i, i + conc).map(async r => {
        const h = new DataView(await blob.slice(r.off, r.off + 30).arrayBuffer());
        if (h.getUint32(0, true) !== 0x04034b50) throw new Error('ZIP dañado (' + r.name + ')');
        r.ds = r.off + 30 + h.getUint16(26, true) + h.getUint16(28, true);
      }));
    }
  }
  async function dataSlice(blob, rec) {
    if (rec.ds !== undefined) return blob.slice(rec.ds, rec.ds + rec.comp);
    const h = new DataView(await blob.slice(rec.off, rec.off + 30).arrayBuffer());
    if (h.getUint32(0, true) !== 0x04034b50) throw new Error('ZIP dañado (' + rec.name + ')');
    const ds = rec.off + 30 + h.getUint16(26, true) + h.getUint16(28, true);
    return blob.slice(ds, ds + rec.comp);
  }
  async function readBytes(blob, rec) {
    const sl = await dataSlice(blob, rec);
    if (rec.method === 0) return new Uint8Array(await sl.arrayBuffer());
    if (rec.method !== 8) throw new Error('Compresión no soportada en ' + rec.name);
    if (typeof DecompressionStream === 'undefined') throw new Error('Este Android/WebView es muy viejo (falta DecompressionStream). Actualiza "Android System WebView".');
    return new Uint8Array(await new Response(sl.stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
  }
  const readText = async (blob, rec) => new TextDecoder('utf-8').decode(await readBytes(blob, rec));

  class ZipWriter {
    constructor() {
      this.parts = []; this.cd = []; this.pos = 0;
      const d = new Date();
      this.time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
      this.date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    }
    // align: si es > 0, el inicio de los datos queda en una posición múltiplo de ese número (como zipalign; lo pide Android para resources.arsc)
    addRaw(name, method, crc, comp, size, data, align) {
      const nb = enc.encode(name), extra = align ? (align - (this.pos + 30 + nb.length) % align) % align : 0;
      const h = new ArrayBuffer(30 + nb.length + extra), dv = new DataView(h);
      dv.setUint32(0, 0x04034b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 0x0800, true); dv.setUint16(8, method, true);
      dv.setUint16(10, this.time, true); dv.setUint16(12, this.date, true); dv.setUint32(14, crc, true);
      dv.setUint32(18, comp, true); dv.setUint32(22, size, true); dv.setUint16(26, nb.length, true); dv.setUint16(28, extra, true);
      new Uint8Array(h).set(nb, 30);
      this.cd.push({ nb, method, crc, comp, size, off: this.pos });
      this.parts.push(h, data); this.pos += h.byteLength + comp;
      if (this.pos > 0xFFFFFF00 || this.cd.length >= 0xFFFF) throw new Error('El resultado es demasiado grande para un ZIP (4 GB / 65 535 archivos)');
    }
    addBytes(name, bytes, align) { this.addRaw(name, 0, crc32(bytes), bytes.length, bytes.length, bytes, align); }
    // Partes del ZIP por separado (hace falta para firmar el APK: la firma va entre los archivos y el directorio central)
    build() {
      const cdStart = this.pos; let cdSize = 0; const cdParts = [];
      for (const e of this.cd) {
        const b = new ArrayBuffer(46 + e.nb.length), dv = new DataView(b);
        dv.setUint32(0, 0x02014b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 20, true); dv.setUint16(8, 0x0800, true); dv.setUint16(10, e.method, true);
        dv.setUint16(12, this.time, true); dv.setUint16(14, this.date, true); dv.setUint32(16, e.crc, true); dv.setUint32(20, e.comp, true); dv.setUint32(24, e.size, true);
        dv.setUint16(28, e.nb.length, true); dv.setUint32(42, e.off, true); new Uint8Array(b).set(e.nb, 46);
        cdParts.push(b); cdSize += b.byteLength;
      }
      const count = this.cd.length;
      return { entries: new Blob(this.parts), entriesSize: cdStart, cd: new Blob(cdParts), cdSize,
        eocd: cdOffset => { const t = new ArrayBuffer(22), dv = new DataView(t);
          dv.setUint32(0, 0x06054b50, true); dv.setUint16(8, count, true); dv.setUint16(10, count, true);
          dv.setUint32(12, cdSize, true); dv.setUint32(16, cdOffset, true); return t; } };
    }
    finish() { const b = this.build(); return new Blob([b.entries, b.cd, b.eocd(b.entriesSize)], { type: 'application/zip' }); }
  }

  // Arma el ZIP final: motor de Electron (del molde) + juego traducido + archivos del juego
  async function buildPackage(o, progress) {
    const w = new ZipWriter(), P = o.prefix, skipSrc = new Set(['code.xml', 'DeviceVariables.json', '.listo']);
    const tpl = o.templateRecs.filter(r => !r.name.endsWith('/'));
    await prefetch(o.templateBlob, tpl); await prefetch(o.srcBlob, o.srcRecs);
    let i = 0;
    for (const r of tpl) {
      const nm = r.name === 'electron.exe' ? (o.launcher ? 'motor.exe' : o.exeName) : r.name;
      w.addRaw(P + nm, r.method, r.crc, r.comp, r.size, await dataSlice(o.templateBlob, r));
      if (progress && ++i % 20 === 0) progress('Copiando el motor… ' + Math.round(i / tpl.length * 100) + '%');
    }
    if (o.launcher) w.addBytes(P + o.exeName, o.launcher);
    for (const f in o.appFiles) w.addBytes(P + 'resources/app/' + f, o.appFiles[f]);
    w.addBytes(P + 'resources/app/game.json', enc.encode(JSON.stringify(o.game)));
    w.addBytes(P + 'resources/app/package.json', enc.encode(JSON.stringify({ name: o.slug, productName: o.name, version: o.version, main: 'main.js' }, null, 2)));
    if (o.iconPng) w.addBytes(P + 'resources/app/icon.png', o.iconPng);
    if (o.iconIco) w.addBytes(P + 'icono.ico', o.iconIco);
    if (o.readme) w.addBytes(P + 'LEEME.txt', enc.encode(o.readme));
    if (o.info) w.addBytes(P + 'DatosDelJuego/info.json', enc.encode(o.info)); // identificación del juego (no hace falta para jugar)
    const ents = o.srcRecs.filter(r => !r.name.endsWith('/') && r.name.startsWith(o.srcPrefix) && !r.name.split('/').includes('..'));
    i = 0;
    for (const r of ents) {
      const rel = r.name.slice(o.srcPrefix.length);
      if (skipSrc.has(rel)) continue;
      if (r.method !== 0 && r.method !== 8) throw new Error('Compresión no soportada en el archivo del juego: ' + rel);
      w.addRaw(P + 'resources/app/assets/' + rel, r.method, r.crc, r.comp, r.size, await dataSlice(o.srcBlob, r));
      if (progress && ++i % 50 === 0) progress('Copiando archivos del juego… ' + Math.round(i / ents.length * 100) + '%');
    }
    return w.finish();
  }
  return { crc32, readCentral, readBytes, readText, dataSlice, prefetch, ZipWriter, buildPackage };
});
