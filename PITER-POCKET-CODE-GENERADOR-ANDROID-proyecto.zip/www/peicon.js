'use strict';
// Pone logotipo, nombre y versión a un .exe pequeño (el "lanzador") reescribiendo su sección de recursos (.rsrc).
// Funciona en el celular: el lanzador pesa unos KB, así que se edita completo en memoria.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiterPE = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const alignUp = (n, a) => Math.ceil(n / a) * a;
  const u16 = n => [n & 255, (n >> 8) & 255];
  const u32 = n => [n & 255, (n >> 8) & 255, (n >> 16) & 255, (n >>> 24) & 255];
  function utf16(s, nul) { const o = []; for (let i = 0; i < s.length; i++) o.push(...u16(s.charCodeAt(i))); if (nul) o.push(0, 0); return o; }
  const pad4 = a => { while (a.length % 4) a.push(0); return a; };

  // ---- VS_VERSIONINFO (lo que Windows muestra en Propiedades > Detalles y en el Administrador de tareas) ----
  function vsNode(key, type, valueBytes, valueLen, children) {
    const a = [0, 0, ...u16(valueLen), ...u16(type), ...utf16(key, true)];
    pad4(a); a.push(...valueBytes); if (children && children.length) { pad4(a); for (const c of children) { a.push(...c); pad4(a); } }
    const len = a.length; a[0] = len & 255; a[1] = (len >> 8) & 255; return a;
  }
  function versionInfo(o) {
    const nums = String(o.version || '1.0.0').split('.').map(x => parseInt(x, 10) || 0).concat([0, 0, 0, 0]).slice(0, 4).map(x => Math.min(65535, x));
    const fixed = [...u32(0xFEEF04BD), ...u32(0x00010000), ...u32((nums[0] << 16) | nums[1]), ...u32((nums[2] << 16) | nums[3]),
      ...u32((nums[0] << 16) | nums[1]), ...u32((nums[2] << 16) | nums[3]), ...u32(0x3F), ...u32(0), ...u32(0x00040004), ...u32(1), ...u32(0), ...u32(0), ...u32(0)];
    const ver = String(o.version || '1.0.0'), name = String(o.name || 'Juego'), exe = String(o.exeName || name + '.exe');
    const strs = [['CompanyName', o.company || ''], ['FileDescription', name], ['FileVersion', ver], ['InternalName', name], ['OriginalFilename', exe],
      ['ProductName', name], ['ProductVersion', ver]];
    const sNodes = strs.map(([k, v]) => vsNode(k, 1, utf16(v, true), v.length + 1, null));
    const table = vsNode('040A04B0', 1, [], 0, sNodes); // español (alfabeto Unicode)
    const sfi = vsNode('StringFileInfo', 1, [], 0, [table]);
    const vfi = vsNode('VarFileInfo', 1, [], 0, [vsNode('Translation', 0, [...u16(0x040A), ...u16(0x04B0)], 4, null)]);
    return new Uint8Array(vsNode('VS_VERSION_INFO', 0, fixed, 52, [sfi, vfi]));
  }
  const MANIFEST = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">' +
    '<trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges><requestedExecutionLevel level="asInvoker" uiAccess="false"/></requestedPrivileges></security></trustInfo>' +
    '<compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1"><application><supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/></application></compatibility></assembly>';

  // ---- árbol de recursos: Tipo -> Id -> Idioma -> datos ----
  function buildResources(items, baseRva) { // items: [{type, id, lang, data:Uint8Array}]
    const types = [...new Set(items.map(i => i.type))].sort((a, b) => a - b);
    const byType = t => [...new Set(items.filter(i => i.type === t).map(i => i.id))].sort((a, b) => a - b);
    const dirSize = n => 16 + 8 * n;
    // posiciones
    let pos = dirSize(types.length); const l2 = {}, l3 = {};
    for (const t of types) { l2[t] = pos; pos += dirSize(byType(t).length); }
    for (const t of types) for (const id of byType(t)) { l3[t + ':' + id] = pos; pos += dirSize(items.filter(i => i.type === t && i.id === id).length); }
    const entryAt = {}; for (const it of items) { entryAt[it.type + ':' + it.id + ':' + it.lang] = pos; pos += 16; }
    let dataPos = alignUp(pos, 4); const dataAt = new Map();
    for (const it of items) { dataAt.set(it, dataPos); dataPos = alignUp(dataPos + it.data.length, 4); }
    const out = new Uint8Array(dataPos), dv = new DataView(out.buffer);
    const dir = (p, n) => { dv.setUint16(p + 12, 0, true); dv.setUint16(p + 14, n, true); };
    dir(0, types.length);
    types.forEach((t, i) => { dv.setUint32(16 + i * 8, t, true); dv.setUint32(20 + i * 8, 0x80000000 | l2[t], true); });
    for (const t of types) {
      const ids = byType(t); dir(l2[t], ids.length);
      ids.forEach((id, i) => { dv.setUint32(l2[t] + 16 + i * 8, id, true); dv.setUint32(l2[t] + 20 + i * 8, 0x80000000 | l3[t + ':' + id], true); });
      for (const id of ids) {
        const its = items.filter(i => i.type === t && i.id === id).sort((a, b) => a.lang - b.lang), p = l3[t + ':' + id]; dir(p, its.length);
        its.forEach((it, i) => { dv.setUint32(p + 16 + i * 8, it.lang, true); dv.setUint32(p + 20 + i * 8, entryAt[t + ':' + id + ':' + it.lang], true); });
      }
    }
    for (const it of items) {
      const e = entryAt[it.type + ':' + it.id + ':' + it.lang], d = dataAt.get(it);
      dv.setUint32(e, baseRva + d, true); dv.setUint32(e + 4, it.data.length, true); dv.setUint32(e + 8, 0, true); dv.setUint32(e + 12, 0, true);
      out.set(it.data, d);
    }
    return out;
  }

  // Convierte píxeles RGBA (de un canvas) a un fotograma de icono tipo BMP (DIB 32 bits con alfa)
  function dibFromRgba(rgba, s) {
    const mask = ((s + 31) >> 5) * 4, out = new Uint8Array(40 + s * s * 4 + mask * s), dv = new DataView(out.buffer);
    dv.setUint32(0, 40, true); dv.setInt32(4, s, true); dv.setInt32(8, s * 2, true); dv.setUint16(12, 1, true); dv.setUint16(14, 32, true);
    dv.setUint32(20, s * s * 4 + mask * s, true);
    let o = 40;
    for (let y = s - 1; y >= 0; y--) for (let x = 0; x < s; x++) { const i = (y * s + x) * 4; out[o++] = rgba[i + 2]; out[o++] = rgba[i + 1]; out[o++] = rgba[i]; out[o++] = rgba[i + 3]; }
    return out;
  }

  // exe: bytes del lanzador. o: { frames:[{size, png:bool, data}], name, version, company, exeName }
  function patchLauncher(exe, o) {
    const dv = new DataView(exe.buffer, exe.byteOffset, exe.byteLength);
    if (exe[0] !== 0x4D || exe[1] !== 0x5A) throw new Error('El lanzador no es un .exe válido');
    const pe = dv.getUint32(0x3C, true);
    if (dv.getUint32(pe, true) !== 0x00004550) throw new Error('El lanzador no tiene cabecera PE');
    const nsec = dv.getUint16(pe + 6, true), optSize = dv.getUint16(pe + 20, true), opt = pe + 24;
    if (dv.getUint16(opt, true) !== 0x20B) throw new Error('El lanzador no es de 64 bits');
    const secAlign = dv.getUint32(opt + 32, true), fileAlign = dv.getUint32(opt + 36, true), resDir = opt + 112 + 16;
    const resRva = dv.getUint32(resDir, true); if (!resRva) throw new Error('El lanzador no tiene sección de recursos');
    let sec = -1, lastEnd = 0;
    for (let i = 0; i < nsec; i++) {
      const s = opt + optSize + i * 40, va = dv.getUint32(s + 12, true), vs = dv.getUint32(s + 8, true), rp = dv.getUint32(s + 20, true), rs = dv.getUint32(s + 16, true);
      if (resRva >= va && resRva < va + Math.max(vs, 1)) sec = s;
      lastEnd = Math.max(lastEnd, rp + rs);
    }
    if (sec < 0) throw new Error('No encontré la sección de recursos del lanzador');
    const va = dv.getUint32(sec + 12, true), rawPtr = dv.getUint32(sec + 20, true), rawSize = dv.getUint32(sec + 16, true);
    if (rawPtr + rawSize < lastEnd) throw new Error('La sección de recursos del lanzador no es la última');

    const frames = (o.frames || []).slice().sort((a, b) => b.size - a.size), items = [];
    const grp = [0, 0, 1, 0, ...u16(frames.length)];
    frames.forEach((f, i) => {
      items.push({ type: 3, id: i + 1, lang: 0x0C0A, data: f.data });
      grp.push(f.size >= 256 ? 0 : f.size, f.size >= 256 ? 0 : f.size, 0, 0, ...u16(1), ...u16(32), ...u32(f.data.length), ...u16(i + 1));
    });
    if (frames.length) items.push({ type: 14, id: 1, lang: 0x0C0A, data: new Uint8Array(grp) });
    items.push({ type: 16, id: 1, lang: 0x0C0A, data: versionInfo(o) });
    items.push({ type: 24, id: 1, lang: 0x0C0A, data: new TextEncoder().encode(MANIFEST) });
    const rsrc = buildResources(items, va), newRaw = alignUp(rsrc.length, fileAlign);

    const out = new Uint8Array(rawPtr + newRaw); out.set(exe.subarray(0, rawPtr)); out.set(rsrc, rawPtr);
    const ov = new DataView(out.buffer);
    ov.setUint32(sec + 8, rsrc.length, true); ov.setUint32(sec + 16, newRaw, true);
    ov.setUint32(opt + 56, va + alignUp(rsrc.length, secAlign), true);        // SizeOfImage
    ov.setUint32(resDir, va, true); ov.setUint32(resDir + 4, rsrc.length, true);
    ov.setUint32(opt + 8, Math.max(0, ov.getUint32(opt + 8, true) - rawSize + newRaw), true); // SizeOfInitializedData
    ov.setUint32(opt + 64, 0, true);                                           // CheckSum
    return out;
  }
  return { patchLauncher, dibFromRgba, versionInfo, buildResources };
});
