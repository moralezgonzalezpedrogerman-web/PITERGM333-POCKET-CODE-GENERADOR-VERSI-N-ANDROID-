'use strict';
// Crea el APK del juego dentro del celular, sin GitHub: toma la "plantilla" (runner.apk, compilada junto con este generador),
// le cambia nombre, paquete, icono, orientación y archivos del juego, y la firma (esquema v2 de Android) con una llave propia.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiterApkBuild = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const enc = new TextEncoder(), dec = new TextDecoder('utf-8');
  const PKG_PLACEHOLDER = 'com.piter.juegos.plantilla', LABEL_PLACEHOLDER = 'PITER_NOMBRE_PLANTILLA';
  const subtle = () => (globalThis.crypto || root.crypto).subtle;

  // ---------- identificación del juego: com.piter.juegos.<nombre> ----------
  function packageFor(name) {
    let n = String(name).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 30);
    if (!n) n = 'juego';
    if (/^[0-9]/.test(n)) n = 'j' + n;
    return 'com.piter.juegos.' + n;
  }

  // ---------- AndroidManifest.xml binario (AXML) ----------
  function readPool(u8, off) {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    const size = dv.getUint32(off + 4, true), count = dv.getUint32(off + 8, true), styles = dv.getUint32(off + 12, true), flags = dv.getUint32(off + 16, true),
      start = dv.getUint32(off + 20, true), utf8 = !!(flags & 0x100);
    if (styles) throw new Error('El manifiesto de la plantilla tiene estilos (no soportado)');
    const strs = [];
    for (let i = 0; i < count; i++) {
      let p = off + start + dv.getUint32(off + 28 + i * 4, true);
      if (utf8) {
        let n = u8[p++]; if (n & 0x80) n = ((n & 0x7F) << 8) | u8[p++];
        let b = u8[p++]; if (b & 0x80) b = ((b & 0x7F) << 8) | u8[p++];
        strs.push(dec.decode(u8.subarray(p, p + b)));
      } else {
        let n = dv.getUint16(p, true); p += 2; if (n & 0x8000) { n = ((n & 0x7FFF) << 16) | dv.getUint16(p, true); p += 2; }
        let s = ''; for (let k = 0; k < n; k++) s += String.fromCharCode(dv.getUint16(p + k * 2, true)); strs.push(s);
      }
    }
    return { strs, utf8, size };
  }
  function writePool(strs, utf8) {
    const bodies = strs.map(s => {
      if (utf8) {
        const b = enc.encode(s), a = []; const l = x => x > 0x7F ? [(x >> 8) | 0x80, x & 255] : [x];
        a.push(...l(s.length), ...l(b.length)); const o = new Uint8Array(a.length + b.length + 1); o.set(a); o.set(b, a.length); return o;
      }
      const o = new Uint8Array(2 + s.length * 2 + 2), dv = new DataView(o.buffer); dv.setUint16(0, s.length, true);
      for (let k = 0; k < s.length; k++) dv.setUint16(2 + k * 2, s.charCodeAt(k), true); return o;
    });
    const total = bodies.reduce((a, b) => a + b.length, 0), head = 28 + 4 * strs.length, size = Math.ceil((head + total) / 4) * 4;
    const out = new Uint8Array(size), dv = new DataView(out.buffer);
    dv.setUint16(0, 1, true); dv.setUint16(2, 28, true); dv.setUint32(4, size, true); dv.setUint32(8, strs.length, true); dv.setUint32(12, 0, true);
    dv.setUint32(16, utf8 ? 0x100 : 0, true); dv.setUint32(20, head, true); dv.setUint32(24, 0, true);
    let p = head; bodies.forEach((b, i) => { dv.setUint32(28 + i * 4, p - head, true); out.set(b, p); p += b.length; });
    return out;
  }
  // o: { pkg, label, orientation: 'landscape' | 'portrait' | 'auto' }
  function patchManifest(src, o) {
    const dv = new DataView(src.buffer, src.byteOffset, src.byteLength);
    if (dv.getUint16(0, true) !== 3) throw new Error('AndroidManifest.xml de la plantilla no es válido');
    const poolOff = dv.getUint16(2, true);
    if (dv.getUint16(poolOff, true) !== 1) throw new Error('Manifiesto sin tabla de textos');
    const pool = readPool(src, poolOff);
    const clean = s => String(s).replace(/[\u0000-\u001f]/g, '');
    // Los nombres de CLASES (com.piter.juegos.plantilla.MainActivity) viven dentro del código compilado (classes.dex) y NO se pueden cambiar:
    // si se renombran, el APK se instala pero se cierra al abrir porque no encuentra la clase. Solo cambia el id de la app, permisos y autoridades.
    const isClass = s => s.indexOf(PKG_PLACEHOLDER + '.') === 0 && /^[A-Z][A-Za-z0-9]*[a-z][A-Za-z0-9]*$/.test(s.slice(PKG_PLACEHOLDER.length + 1));
    const strs = pool.strs.map(s => {
      if (s === '.MainActivity') return PKG_PLACEHOLDER + '.MainActivity';   // nombre relativo -> completo (el paquete de la app cambia, la clase no)
      return (isClass(s) ? s : s.split(PKG_PLACEHOLDER).join(o.pkg)).split(LABEL_PLACEHOLDER).join(clean(o.label));
    });
    if (!pool.strs.some(s => s.includes(PKG_PLACEHOLDER))) throw new Error('No encontré el paquete de la plantilla en el manifiesto');
    const newPool = writePool(strs, pool.utf8), rest = src.subarray(poolOff + pool.size);
    const out = new Uint8Array(poolOff + newPool.length + rest.length), ov = new DataView(out.buffer);
    out.set(src.subarray(0, poolOff)); out.set(newPool, poolOff); out.set(rest, poolOff + newPool.length); ov.setUint32(4, out.length, true);
    // orientación: se cambia el número del atributo android:screenOrientation (6 = horizontal, 7 = vertical, 10 = automática)
    const val = { landscape: 6, portrait: 7 }[o.orientation] || 10, idx = strs.indexOf('screenOrientation');
    if (idx >= 0) {
      let p = poolOff + newPool.length;
      while (p + 8 <= out.length) {
        const type = ov.getUint16(p, true), size = ov.getUint32(p + 4, true); if (size < 8) break;
        if (type === 0x0102) {
          const aStart = ov.getUint16(p + 24, true), aSize = ov.getUint16(p + 26, true), aCount = ov.getUint16(p + 28, true);
          for (let k = 0; k < aCount; k++) { const a = p + 16 + aStart + k * aSize; if (ov.getUint32(a + 4, true) === idx) { ov.setUint8(a + 15, 0x10); ov.setUint32(a + 16, val >>> 0, true); } }
        }
        p += size;
      }
    }
    const check = readPool(out, poolOff).strs;
    if (!check.includes(o.pkg)) throw new Error('El manifiesto no quedó con el paquete nuevo');
    if (pool.strs.some(x => x === PKG_PLACEHOLDER + '.MainActivity' || x === '.MainActivity') && !check.includes(PKG_PLACEHOLDER + '.MainActivity'))
      throw new Error('El manifiesto perdió la clase principal (el APK se cerraría al abrir)');
    return out;
  }
  // resources.arsc: el nombre del paquete es un campo fijo de 128 letras UTF-16 (se cambia en su lugar)
  function patchArsc(src, pkg) {
    const out = new Uint8Array(src), dv = new DataView(out.buffer);
    if (dv.getUint16(0, true) !== 2) throw new Error('resources.arsc de la plantilla no es válido');
    let p = dv.getUint16(2, true), done = 0;
    while (p + 8 <= out.length) {
      const type = dv.getUint16(p, true), size = dv.getUint32(p + 4, true); if (size < 8) break;
      if (type === 0x0200) {
        let cur = ''; for (let k = 0; k < 128; k++) { const c = dv.getUint16(p + 12 + k * 2, true); if (!c) break; cur += String.fromCharCode(c); }
        if (cur === PKG_PLACEHOLDER) { for (let k = 0; k < 128; k++) dv.setUint16(p + 12 + k * 2, k < pkg.length ? pkg.charCodeAt(k) : 0, true); done++; }
      }
      p += size;
    }
    if (!done) throw new Error('No encontré el paquete en resources.arsc');
    return out;
  }

  // ---------- firma (APK Signature Scheme v2) ----------
  const der = (tag, ...parts) => {
    const body = parts.reduce((a, p) => { const o = new Uint8Array(a.length + p.length); o.set(a); o.set(p, a.length); return o; }, new Uint8Array(0));
    const n = body.length, len = n < 128 ? [n] : n < 256 ? [0x81, n] : n < 65536 ? [0x82, n >> 8, n & 255] : [0x83, n >> 16, (n >> 8) & 255, n & 255];
    const out = new Uint8Array(1 + len.length + n); out[0] = tag; out.set(len, 1); out.set(body, 1 + len.length); return out;
  };
  const OID_SHA256_RSA = new Uint8Array([0x06, 9, 0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 1, 1, 0x0B]), NULL = new Uint8Array([5, 0]);
  const name = der(0x30, der(0x31, der(0x30, new Uint8Array([6, 3, 0x55, 4, 3]), der(0x0C, enc.encode('PITER POCKET CODE')))));
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));

  async function makeIdentity() {
    const kp = await subtle().generateKey({ name: 'RSASSA-PKCS1-v1_5', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' }, true, ['sign', 'verify']);
    const spki = new Uint8Array(await subtle().exportKey('spki', kp.publicKey)), serial = crypto.getRandomValues(new Uint8Array(8)); serial[0] = (serial[0] & 0x7F) || 1;
    const tbs = der(0x30, new Uint8Array([0xA0, 3, 2, 1, 2]), der(2, serial), der(0x30, OID_SHA256_RSA, NULL), name,
      der(0x30, der(0x17, enc.encode('200101000000Z')), der(0x18, enc.encode('20700101000000Z'))), name, spki);
    const sig = new Uint8Array(await subtle().sign('RSASSA-PKCS1-v1_5', kp.privateKey, tbs));
    const bits = new Uint8Array(sig.length + 1); bits.set(sig, 1);
    const cert = der(0x30, tbs, der(0x30, OID_SHA256_RSA, NULL), der(3, bits));
    return { jwk: await subtle().exportKey('jwk', kp.privateKey), spki, cert };
  }
  // La misma llave se reutiliza siempre (en el mismo celular): así un juego nuevo con el mismo nombre se instala como actualización.
  async function getIdentity() {
    try {
      const j = JSON.parse(localStorage.getItem('piterApkIdentity') || 'null');
      if (j && j.jwk && j.spki && j.cert) return { jwk: j.jwk, spki: unb64(j.spki), cert: unb64(j.cert) };
    } catch (e) {}
    const id = await makeIdentity();
    try { localStorage.setItem('piterApkIdentity', JSON.stringify({ jwk: id.jwk, spki: b64(id.spki), cert: b64(id.cert) })); } catch (e) {}
    return id;
  }
  const u32 = n => { const a = new Uint8Array(4); new DataView(a.buffer).setUint32(0, n, true); return a; };
  const cat = (...p) => { const n = p.reduce((a, x) => a + x.length, 0), o = new Uint8Array(n); let k = 0; for (const x of p) { o.set(x, k); k += x.length; } return o; };
  const lp = (...p) => { const b = cat(...p); return cat(u32(b.length), b); }; // con prefijo de longitud
  const sha256 = async u8 => new Uint8Array(await subtle().digest('SHA-256', u8));

  // zip: resultado de ZipWriter.build()
  async function signZip(zip, identity, progress) {
    const MB = 1 << 20, eocdPlain = new Uint8Array(zip.eocd(zip.entriesSize)), tasks = [];
    for (const sec of [zip.entries, zip.cd, new Blob([eocdPlain])]) for (let off = 0; off < sec.size; off += MB) tasks.push([sec, off]);
    const chunks = new Array(tasks.length), CONC = 8; // 8 bloques de 1 MB en paralelo
    for (let i = 0; i < tasks.length; i += CONC) {
      await Promise.all(tasks.slice(i, i + CONC).map(async ([sec, off], k) => {
        const ab = new Uint8Array(await sec.slice(off, Math.min(sec.size, off + MB)).arrayBuffer()), b = new Uint8Array(5 + ab.length);
        b[0] = 0xA5; new DataView(b.buffer).setUint32(1, ab.length, true); b.set(ab, 5); chunks[i + k] = await sha256(b);
      }));
      if (progress && i % 64 === 0) progress('Firmando el APK… ' + Math.round(i / tasks.length * 100) + '%');
    }
    const top = cat(new Uint8Array([0x5A]), u32(chunks.length), ...chunks), digest = await sha256(top), ALG = 0x0103;
    const signed = cat(lp(lp(u32(ALG), lp(digest))), lp(lp(identity.cert)), lp());
    const key = await subtle().importKey('jwk', identity.jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
    const sig = new Uint8Array(await subtle().sign('RSASSA-PKCS1-v1_5', key, signed));
    const signer = lp(lp(signed), lp(lp(u32(ALG), lp(sig))), lp(identity.spki));
    const v2 = lp(signer); // valor del bloque con id 0x7109871a
    const pairBuf = new Uint8Array(8 + 4 + v2.length); { const d = new DataView(pairBuf.buffer); d.setBigUint64(0, BigInt(4 + v2.length), true); d.setUint32(8, 0x7109871A, true); pairBuf.set(v2, 12); }
    const blockSize = pairBuf.length + 8 + 16, block = new Uint8Array(8 + blockSize), bd = new DataView(block.buffer);
    bd.setBigUint64(0, BigInt(blockSize), true); block.set(pairBuf, 8); bd.setBigUint64(8 + pairBuf.length, BigInt(blockSize), true); block.set(enc.encode('APK Sig Block 42'), 8 + pairBuf.length + 8);
    return new Blob([zip.entries, block, zip.cd, zip.eocd(zip.entriesSize + block.length)], { type: 'application/vnd.android.package-archive' });
  }

  // ---------- armado del APK ----------
  // o: { Z, runner:Blob, pkg, label, orientation, iconsAndroid:{48..192:Uint8Array}, game, gameEntries:[{rel, addTo(w, dest)}] }
  async function build(o, progress) {
    const Z = o.Z, recs = await Z.readCentral(o.runner), w = new Z.ZipWriter();
    if (Z.prefetch) await Z.prefetch(o.runner, recs);
    const text = bytes => dec.decode(bytes), pngWidth = b => new DataView(b.buffer, b.byteOffset, b.byteLength).getUint32(16, false);
    let manifest = false, arsc = false, icons = 0;
    for (const r of recs) {
      const n = r.name; if (n.endsWith('/')) continue;
      if (/^META-INF\/(MANIFEST\.MF|[^/]+\.(SF|RSA|DSA|EC))$/i.test(n)) continue;   // firma anterior de la plantilla
      if (n === 'assets/public/game.json') continue;
      if (n === 'AndroidManifest.xml') { w.addBytes(n, patchManifest(await Z.readBytes(o.runner, r), o), 4); manifest = true; continue; }
      if (n === 'resources.arsc') { w.addBytes(n, patchArsc(await Z.readBytes(o.runner, r), o.pkg), 4); arsc = true; continue; }
      if (n === 'assets/capacitor.config.json') {
        let c = {}; try { c = JSON.parse(text(await Z.readBytes(o.runner, r))); } catch (e) {}
        c.appId = o.pkg; c.appName = o.label; w.addBytes(n, enc.encode(JSON.stringify(c, null, 2)), 4); continue;
      }
      if (/^res\/mipmap[^/]*\/ic_launcher[^/]*\.png$/.test(n) && o.iconsAndroid) {
        const cur = await Z.readBytes(o.runner, r), wd = pngWidth(cur), best = Object.keys(o.iconsAndroid).map(Number).sort((a, b) => Math.abs(a - wd) - Math.abs(b - wd))[0];
        if (best) { w.addBytes(n, o.iconsAndroid[best], 4); icons++; continue; }
      }
      w.addRaw(n, r.method, r.crc, r.comp, r.size, await Z.dataSlice(o.runner, r), r.method === 0 ? 4 : 0);
    }
    if (!manifest || !arsc) throw new Error('La plantilla del APK está incompleta (falta el manifiesto o los recursos)');
    w.addBytes('assets/public/game.json', enc.encode(JSON.stringify(o.game)), 4);
    let i = 0;
    for (const e of o.gameEntries) {
      await e.addTo(w, 'assets/public/assets/' + e.rel);
      if (progress && ++i % 50 === 0) progress('Copiando archivos del juego… ' + Math.round(i / o.gameEntries.length * 100) + '%');
    }
    if (progress) progress('Firmando el APK…');
    return { blob: await signZip(w.build(), o.identity || await getIdentity(), progress), icons };
  }
  return { _writePool: writePool, build, packageFor, patchManifest, patchArsc, signZip, getIdentity, makeIdentity, PKG_PLACEHOLDER, LABEL_PLACEHOLDER };
});
