'use strict';
// Traductor: convierte el code.xml de Pocket Code / Catrobat en un JSON limpio (game.json)
// y genera un reporte de compatibilidad (qué bloques, fórmulas y archivos usa el juego).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiterCompiler = factory();
})(typeof self !== 'undefined' ? self : this, function () {

  // ---------- Lo que el motor (runtime/engine.js) sabe ejecutar ----------
  const SUPPORTED_BRICKS = new Set([
    // movimiento
    'PlaceAtBrick', 'SetXBrick', 'SetYBrick', 'ChangeXByNBrick', 'ChangeYByNBrick', 'MoveNStepsBrick',
    'TurnLeftBrick', 'TurnRightBrick', 'PointInDirectionBrick', 'PointToBrick', 'GlideToBrick',
    'IfOnEdgeBounceBrick', 'GoNStepsBackBrick', 'ComeToFrontBrick',
    // apariencia
    'SetSizeToBrick', 'ChangeSizeByNBrick', 'SetTransparencyBrick', 'ChangeTransparencyByNBrick',
    'SetBrightnessBrick', 'ChangeBrightnessByNBrick', 'SetColorBrick', 'ChangeColorByNBrick',
    'ClearGraphicEffectBrick', 'ShowBrick', 'HideBrick', 'NextLookBrick', 'PreviousLookBrick',
    'SetLookBrick', 'SetLookByIndexBrick', 'SetBackgroundBrick', 'SetBackgroundByIndexBrick',
    // control
    'WaitBrick', 'WaitUntilBrick', 'ForeverBrick', 'RepeatBrick', 'RepeatUntilBrick',
    'IfLogicBeginBrick', 'IfThenLogicBeginBrick', 'BroadcastBrick', 'BroadcastWaitBrick',
    'StopScriptBrick', 'SceneTransitionBrick', 'SceneStartBrick', 'ClearSceneBrick', 'ExitStageBrick', 'NoteBrick',
    // variables y listas
    'SetVariableBrick', 'ChangeVariableBrick', 'ShowTextBrick', 'HideTextBrick',
    'WriteVariableOnDeviceBrick', 'ReadVariableFromDeviceBrick',
    'AddItemToUserListBrick', 'DeleteItemOfUserListBrick', 'InsertItemIntoUserListBrick',
    'ReplaceItemInUserListBrick', 'ClearUserListBrick',
    // sonido
    'VibrationBrick', 'SetCameraFocusPointBrick', 'CloneBrick', 'DeleteThisCloneBrick', 'GoToBrick', 'SetRotationStyleBrick', 'ForVariableFromToBrick', 'ForItemInUserListBrick', 'TapAtBrick', 'FinishStageBrick',
    'UserDefinedBrick', 'ResetTimerBrick', 'StoreCSVIntoUserListBrick', 'IfLogicElseBrick', 'IfLogicEndBrick', 'IfThenLogicEndBrick', 'LoopEndlessBrick', 'LoopEndBrick',
    'PenDownBrick', 'PenUpBrick', 'SetPenSizeBrick', 'SetPenColorBrick', 'StampBrick', 'ClearBackgroundBrick',
    'SayBubbleBrick', 'SayForBubbleBrick', 'ThinkBubbleBrick', 'ThinkForBubbleBrick', 'ShowTextColorSizeAlignmentBrick', 'AskBrick', 'AskSpeechBrick', 'WebRequestBrick',
    'WriteListOnDeviceBrick', 'ReadListFromDeviceBrick', 'PlayNoteForBeatsBrick', 'PauseForBeatsBrick', 'SetTempoBrick', 'ChangeTempoByNBrick', 'SetInstrumentBrick', 'PlayDrumForBeatsBrick',
    'PlaySoundBrick', 'PlaySoundAtBrick', 'PlaySoundAndWaitBrick', 'StopSoundBrick', 'StopAllSoundsBrick',
    'SetVolumeToBrick', 'ChangeVolumeByNBrick', 'SpeakBrick', 'SpeakAndWaitBrick',
    // física
    'SetPhysicsObjectTypeBrick', 'SetVelocityBrick', 'TurnLeftSpeedBrick', 'TurnRightSpeedBrick',
    'SetGravityBrick', 'SetMassBrick', 'SetBounceBrick', 'SetFrictionBrick',
    // video / web
    'CreateVideoBrick', 'DeleteWebBrick', 'PlayVideoBrick', 'PauseVideoBrick', 'NativeViewConfigBrick', 'OpenUrlBrick'
  ]);
  // Bloques de celular/hardware: en PC no hacen nada (se ignoran sin error)
  const IGNORED_BRICKS = new Set(['FlashBrick', 'CameraBrick', 'ChooseCameraBrick', 'LedOnBrick', 'LedOffBrick']);
  const IGNORED_PATTERN = /^(Lego|Arduino|Phiro|Drone|Raspi|JumpingSumo|Nfc|Set(Nxt|Ev3))|(Stitch|Embroidery|SewUp|ThreadColor|Plot|Particle)/; // bordado, trazado y partículas: sin efecto en PC
  const SUPPORTED_SCRIPTS = new Set(['StartScript', 'WhenScript', 'WhenTouchDownScript', 'BroadcastScript', 'WhenConditionScript', 'CollisionScript', 'WhenClonedScript', 'WhenBackgroundChangesScript', 'WhenBounceOffScript', 'UserDefinedScript']);

  const SUPPORTED_FUNCTIONS = new Set(['TRUE', 'FALSE', 'RAND', 'ABS', 'ROUND', 'FLOOR', 'CEIL', 'SQRT', 'SIN', 'COS', 'TAN',
    'ARCSIN', 'ARCCOS', 'ARCTAN', 'ARCTAN2', 'LN', 'LOG', 'EXP', 'POWER', 'PI', 'MOD', 'MAX', 'MIN', 'JOIN', 'JOIN3', 'IF_THEN_ELSE', 'LENGTH', 'LETTER',
    'LIST_ITEM', 'NUMBER_OF_ITEMS', 'CONTAINS', 'INDEX_OF_ITEM', 'REGEX', 'FLATTEN', 'COLLIDES_WITH_EDGE', 'MULTI_FINGER_TOUCHED', 'MULTI_FINGER_X', 'MULTI_FINGER_Y']);
  const SUPPORTED_OPERATORS = new Set(['PLUS', 'MINUS', 'MULT', 'DIVIDE', 'MOD', 'POW', 'EQUAL', 'NOT_EQUAL', 'SMALLER_THAN',
    'SMALLER_OR_EQUAL', 'GREATER_THAN', 'GREATER_OR_EQUAL', 'LOGICAL_AND', 'LOGICAL_OR', 'LOGICAL_NOT']);
  const SUPPORTED_SENSORS = new Set(['FINGER_TOUCHED', 'FINGER_X', 'FINGER_Y', 'COLLIDES_WITH_FINGER', 'OBJECT_X', 'OBJECT_Y',
    'OBJECT_SIZE', 'OBJECT_TRANSPARENCY', 'OBJECT_BRIGHTNESS', 'OBJECT_ANGLE', 'OBJECT_DIRECTION', 'OBJECT_LOOK_NUMBER',
    'OBJECT_LAYER', 'OBJECT_COLOR', 'OBJECT_X_VELOCITY', 'OBJECT_Y_VELOCITY', 'OBJECT_ANGULAR_VELOCITY', 'MOTION_DIRECTION', 'OBJECT_LOOK_DIRECTION', 'OBJECT_MOTION_DIRECTION', 'OBJECT_ROTATION', 'LOOK_DIRECTION', 'LOUDNESS', 'OBJECT_WIDTH', 'OBJECT_HEIGHT', 'OBJECT_LOOK_NAME', 'OBJECT_NUMBER_OF_LOOKS', 'OBJECT_BACKGROUND_NUMBER', 'OBJECT_BACKGROUND_NAME', 'LAST_FINGER_INDEX', 'TIMER', 'DATE_YEAR', 'DATE_MONTH', 'DATE_DAY', 'DATE_WEEKDAY', 'TIME_HOUR', 'TIME_MINUTE', 'TIME_SECOND']);

  // ---------- utilidades XML ----------
  const kids = (el, tag) => el ? Array.from(el.children).filter(c => c.tagName === tag) : [];
  const kid = (el, tag) => el ? Array.from(el.children).find(c => c.tagName === tag) || null : null;
  const txt = (el, tag) => { const k = kid(el, tag); return k ? k.textContent : ''; };

  // Resuelve referencias relativas estilo XStream ("../../soundList/sound[2]")
  function resolveRef(el, ref) {
    let cur = el;
    for (const part of ref.split('/')) {
      if (part === '..') cur = cur.parentElement;
      else if (part === '.' || part === '') continue;
      else {
        const m = part.match(/^([^\[]+)(?:\[(\d+)\])?$/);
        const n = m[2] ? +m[2] : 1; let c = 0, found = null;
        for (const ch of cur.children) if (ch.tagName === m[1] && ++c === n) { found = ch; break; }
        cur = found;
      }
      if (!cur) return null;
    }
    return cur;
  }
  function deref(el) {
    let guard = 0;
    while (el && el.getAttribute('reference') && guard++ < 20) el = resolveRef(el, el.getAttribute('reference'));
    return el;
  }
  function refName(el) { // nombre de una variable o lista (inline o por referencia)
    const r = deref(el); if (!r) return null;
    const n = r.getElementsByTagName('name')[0] || r.getElementsByTagName('n')[0];
    return n ? n.textContent : null;
  }
  function refKey(el) {
    const r = deref(el); if (!r) return null;
    const k = r.getElementsByTagName('deviceValueKey')[0];
    return k ? k.textContent : null;
  }

  // ---------- traducción ----------
  function compF(el) {
    if (!el) return null;
    const o = { type: txt(el, 'type'), value: txt(el, 'value') };
    const l = compF(kid(el, 'leftChild')), r = compF(kid(el, 'rightChild'));
    if (l) o.l = l;
    if (r) o.r = r;
    const ac = kid(el, 'additionalChildren');
    if (ac && ac.children.length) o.a = Array.from(ac.children).map(compF).filter(Boolean);
    return o;
  }
  const FLAT_END = new Set(['IfLogicEndBrick', 'IfThenLogicEndBrick', 'LoopEndlessBrick', 'LoopEndBrick']);
  function nestFlat(list) {
    if (!list.some(b => FLAT_END.has(b.type) || b.type === 'IfLogicElseBrick')) return list;
    const root = [], stack = [{ arr: root }];
    for (const b of list) {
      const top = stack[stack.length - 1];
      const opensLoop = (b.type === 'ForeverBrick' || b.type === 'RepeatBrick' || b.type === 'RepeatUntilBrick') && b.loop === undefined;
      const opensIf = (b.type === 'IfLogicBeginBrick' || b.type === 'IfThenLogicBeginBrick') && b.ifB === undefined;
      if (opensLoop) { top.arr.push(b); b.loop = []; stack.push({ b, arr: b.loop, kind: 'loop' }); }
      else if (opensIf) { top.arr.push(b); b.ifB = []; if (b.type === 'IfLogicBeginBrick') b.elseB = []; stack.push({ b, arr: b.ifB, kind: 'if' }); }
      else if (b.type === 'IfLogicElseBrick') { if (top.kind === 'if' && top.b.elseB) top.arr = top.b.elseB; }
      else if (FLAT_END.has(b.type)) { if (stack.length > 1) stack.pop(); }
      else top.arr.push(b);
    }
    return root;
  }
  function compBricks(listEl) {
    const out = [];
    if (!listEl) return out;
    for (const b of listEl.children) {
      if (!b.getAttribute('type') || !(b.tagName === 'brick' || b.tagName.indexOf('.bricks.') >= 0)) continue;
      const c = compBrick(b); if (c) out.push(c);
    }
    return nestFlat(out);
  }
  function compBrick(b) {
    if (txt(b, 'commentedOut') === 'true') return null;
    const o = { type: b.getAttribute('type'), f: {}, fl: [] };
    const isUDB = o.type === 'UserDefinedBrick';
    if (isUDB) { // bloque propio: la cabecera de la definición no hace nada; la llamada lleva sus parámetros por nombre
      if (txt(b, 'isCallingBrick') !== 'true') return null;
      o.callId = txt(b, 'userDefinedBrickID'); o.args = {};
    }
    for (const f of kids(kid(b, 'formulaList') || kid(b, 'formulaMap'), 'formula')) {
      const c = compF(f); o.f[f.getAttribute('category')] = c; o.fl.push(c);
      if (isUDB && f.getAttribute('input') != null) o.args[f.getAttribute('input')] = c;
    }
    const lp = kid(b, 'loopBricks'); if (lp) o.loop = compBricks(lp);
    const ib = kid(b, 'ifBranchBricks'); if (ib) o.ifB = compBricks(ib);
    const eb = kid(b, 'elseBranchBricks'); if (eb) o.elseB = compBricks(eb);
    const msg = txt(b, 'broadcastMessage'); if (msg) o.msg = msg;
    const scene = txt(b, 'sceneForTransition') || txt(b, 'sceneToStart'); if (scene) o.scene = scene;
    const lk = kid(b, 'look');
    if (lk) {
      const r = deref(lk);
      if (r) {
        o.lookFile = r.getAttribute('fileName');
        const p = r.parentElement;
        if (p && p.tagName === 'lookList') o.lookIdx = Array.from(p.children).indexOf(r);
      }
    }
    const sd = kid(b, 'sound'); if (sd) { const s = deref(sd); if (s) o.sound = s.getAttribute('fileName'); }
    const uv = kid(b, 'userVariable'); if (uv) { o.varName = refName(uv); o.varKey = refKey(uv); }
    const ul = kid(b, 'userList'); if (ul) o.listName = refName(ul);
    const sp = kid(b, 'spinnerSelection') || kid(b, 'spinnerSelectionID') || kid(b, 'selection'); if (sp) o.spinner = parseInt(sp.textContent, 10);
    const ps = kid(b, 'propertySelection'); if (ps) o.prop = parseInt(ps.textContent, 10);
    const po = kid(b, 'pointedObject'); if (po) { const r = deref(po); if (r) o.pointed = r.getAttribute('name') || txt(r, 'name'); }
    if (o.type === 'SetPhysicsObjectTypeBrick') o.ptype = txt(b, 'type');
    // clones e "ir a": el objeto puede venir completo dentro del bloque o por referencia; solo hace falta su nombre
    const oc = kid(b, 'objectToClone'); if (oc) { const r = deref(oc); if (r) o.cloneOf = r.getAttribute('name') || txt(r, 'name'); }
    const ds = kid(b, 'destinationSprite'); if (ds) { const r = deref(ds); if (r) o.gotoName = r.getAttribute('name') || txt(r, 'name'); }
    if (o.listName != null) { const ul2 = kid(b, 'userList'); if (ul2) o.listKey = refKey(ul2); }
    return o;
  }
  function compScene(el, fallbackName) {
    const name = txt(el, 'name') || txt(el, 'n') || fallbackName || 'Escena';
    const objs = [];
    for (const oe0 of kids(kid(el, 'objectList'), 'object')) {
      const oe = deref(oe0) || oe0; // el objeto puede estar definido dentro de otro bloque (clonar, ir a…) y la lista solo lo referencia
      const od = { name: oe.getAttribute('name') || txt(oe, 'name') || '', looks: [], sounds: [], scripts: [], locals: [], localLists: [] };
      // variables y listas LOCALES del objeto (cada objeto, y cada clon, tiene su propia copia)
      for (const u of kids(kid(oe, 'userVariables'), 'userVariable')) { const n = refName(u); if (n != null) od.locals.push(n); }
      for (const u of kids(kid(oe, 'userLists'), 'userList')) { const n = refName(u); if (n != null) od.localLists.push(n); }
      for (const l of kids(kid(oe, 'lookList'), 'look')) od.looks.push({ file: l.getAttribute('fileName'), name: l.getAttribute('name') });
      for (const s of kids(kid(oe, 'soundList'), 'sound')) od.sounds.push({ file: s.getAttribute('fileName'), name: s.getAttribute('name') });
      for (const se of kids(kid(oe, 'scriptList'), 'script')) {
        if (txt(se, 'commentedOut') === 'true') continue;
        const sd = { type: se.getAttribute('type'), msg: txt(se, 'receivedMessage'), bricks: compBricks(kid(se, 'brickList')) };
        if (sd.type === 'UserDefinedScript') { sd.callId = txt(se, 'userDefinedBrickID'); sd.screenRefresh = txt(se, 'screenRefresh') !== 'false'; }
        if (sd.type === 'WhenConditionScript') sd.cond = compF(kid(kid(se, 'formulaMap'), 'formula'));
        if (sd.type === 'WhenBounceOffScript') sd.msg = txt(se, 'spriteToBounceOffName') || txt(se, 'receivedMessage');
        if (sd.type === 'WhenBackgroundChangesScript') { const lk = kid(se, 'look'); if (lk) { const r = deref(lk); if (r) { sd.lookFile = r.getAttribute('fileName'); const par = r.parentElement; if (par && par.tagName === 'lookList') sd.lookIdx = Array.from(par.children).indexOf(r); } } }
        od.scripts.push(sd);
      }
      objs.push(od);
    }
    return { name, objs };
  }

  // ---------- reporte de compatibilidad ----------
  const inc = (o, k) => { o[k] = (o[k] || 0) + 1; };
  function scanF(f, rep) {
    if (!f) return;
    if (f.type === 'FUNCTION' && !SUPPORTED_FUNCTIONS.has(f.value)) inc(rep.unsupportedFormulas, 'función ' + f.value);
    else if (f.type === 'OPERATOR' && !SUPPORTED_OPERATORS.has(f.value)) inc(rep.unsupportedFormulas, 'operador ' + f.value);
    else if (f.type === 'SENSOR' && !SUPPORTED_SENSORS.has(f.value)) inc(rep.mobileSensors, f.value);
    scanF(f.l, rep); scanF(f.r, rep); for (const x of f.a || []) scanF(x, rep);
  }
  function scanBricks(list, rep, files) {
    for (const b of list || []) {
      rep.bricks++; inc(rep.bricksUsed, b.type);
      if (!SUPPORTED_BRICKS.has(b.type)) {
        if (IGNORED_BRICKS.has(b.type) || IGNORED_PATTERN.test(b.type)) inc(rep.ignoredBricks, b.type);
        else inc(rep.unsupportedBricks, b.type);
      }
      for (const k in b.f) scanF(b.f[k], rep);
      for (const k in (b.args || {})) scanF(b.args[k], rep);
      if (b.type === 'CreateVideoBrick' && b.f.FILE && b.f.FILE.type === 'STRING' && b.f.FILE.value && !files[b.f.FILE.value.toLowerCase()])
        rep.missingAssets.push(b.f.FILE.value);
      scanBricks(b.loop, rep, files); scanBricks(b.ifB, rep, files); scanBricks(b.elseB, rep, files);
    }
  }

  // Variables declaradas en el proyecto (con su valor inicial, si lo trae)
  function declaredVars(doc) {
    const out = {};
    for (const tag of ['programVariableList', 'objectVariableList', 'userVariables']) {
      for (const lst of doc.getElementsByTagName(tag)) for (const uv of lst.getElementsByTagName('userVariable')) {
        if (uv.getAttribute('reference')) continue;
        const name = txt(uv, 'name') || txt(uv, 'n'); if (!name) continue;
        const raw = (txt(uv, 'value') || txt(uv, 'initialValue')).trim();
        if (raw === '') { if (!(name in out)) out[name] = 0; continue; }
        out[name] = /^-?\d+(\.\d+)?$/.test(raw) ? Number(raw) : raw;
      }
    }
    return out;
  }

  // ---------- detección de controles táctiles (para "mapear botones") ----------
  function fUses(f, names) { return !!f && ((f.type === 'SENSOR' && names.includes(f.value)) || fUses(f.l, names) || fUses(f.r, names)); }
  function bricksUse(list, names) {
    for (const b of list || []) {
      for (const k in b.f) if (fUses(b.f[k], names)) return true;
      if (bricksUse(b.loop, names) || bricksUse(b.ifB, names) || bricksUse(b.elseB, names)) return true;
    }
    return false;
  }
  const scriptUses = (s, names) => fUses(s.cond, names) || bricksUse(s.bricks, names);
  function detectInputs(scenes) {
    const inputs = []; let screen = false;
    for (const sc of scenes) for (const od of sc.objs) {
      const tap = od.scripts.some(s => s.type === 'WhenScript');
      const hold = od.scripts.some(s => scriptUses(s, ['COLLIDES_WITH_FINGER']));
      if (od.scripts.some(s => s.type === 'WhenTouchDownScript' || scriptUses(s, ['FINGER_TOUCHED', 'FINGER_X', 'FINGER_Y', 'MULTI_FINGER_TOUCHED', 'MULTI_FINGER_X', 'MULTI_FINGER_Y', 'LAST_FINGER_INDEX']))) screen = true;
      if (tap || hold) inputs.push({ id: 'obj:' + sc.name + '/' + od.name, scene: sc.name, obj: od.name, tap, hold });
    }
    if (screen) inputs.unshift({ id: 'screen', scene: null, obj: null, screen: true });
    return inputs;
  }
  // ---------- detección de joysticks virtuales (por la ESTRUCTURA de los bloques, no por el nombre del objeto) ----------
  // Un joystick es cualquier objeto cuyos bloques leen la posición de un dedo y la usan para mover algo
  // (poner X/Y, apuntar, mover pasos) o para escribir variables, aunque el creador le haya puesto cualquier nombre.
  const FINGER_SENSORS = ['FINGER_X', 'FINGER_Y', 'FINGER_TOUCHED', 'COLLIDES_WITH_FINGER', 'MULTI_FINGER_X', 'MULTI_FINGER_Y', 'MULTI_FINGER_TOUCHED', 'LAST_FINGER_INDEX'];
  const POS_WRITERS = new Set(['PlaceAtBrick', 'SetXBrick', 'SetYBrick', 'ChangeXByNBrick', 'ChangeYByNBrick', 'PointToBrick', 'PointInDirectionBrick', 'MoveNStepsBrick', 'GlideToBrick']);
  function bricksHave(list, pred) {
    for (const b of list || []) { if (pred(b) || bricksHave(b.loop, pred) || bricksHave(b.ifB, pred) || bricksHave(b.elseB, pred)) return true; }
    return false;
  }
  const MATH_FNS = ['SIN', 'COS', 'TAN', 'ARCTAN', 'ARCTAN2', 'SQRT', 'POWER'];
  const COND_BRICKS = new Set(['IfLogicBeginBrick', 'IfThenLogicBeginBrick', 'RepeatUntilBrick', 'WaitUntilBrick']);
  function fFn(f, names) { return !!f && ((f.type === 'FUNCTION' && names.includes(f.value)) || fFn(f.l, names) || fFn(f.r, names) || (f.a || []).some(x => fFn(x, names))); }
  // objetos que leen la posición de un dedo (candidatos para el joystick por teclado)
  function fingerObjects(scenes) {
    const out = [];
    for (const sc of scenes) for (const od of sc.objs) if (od.scripts.some(s => scriptUses(s, FINGER_SENSORS)) && !out.includes(od.name)) out.push(od.name);
    return out;
  }
  // ---------- joysticks hechos con bloques: los 3 patrones de la guía técnica ----------
  // Se reconocen por la ESTRUCTURA (qué hace cada bloque y a qué objeto/variable/mensaje apunta), nunca por los nombres:
  //  · rastreador: objeto con un "por siempre → ir a la posición del toque"
  //  · perilla: objeto con "cuando pulse" → "repetir hasta que no haya toque" → "apuntar hacia <rastreador>"
  //  · personaje: el que avanza con la variable de estado (patrones 1 y 2) o al recibir el mensaje (patrón 3)
  const DIR_SENSORS = ['OBJECT_DIRECTION', 'OBJECT_ANGLE', 'OBJECT_LOOK_DIRECTION', 'OBJECT_ROTATION', 'LOOK_DIRECTION', 'MOTION_DIRECTION', 'OBJECT_MOTION_DIRECTION'];
  function walkB(list, fn) { for (const b of list || []) { fn(b); walkB(b.loop, fn); walkB(b.ifB, fn); walkB(b.elseB, fn); } }
  function fVars(f, out) { out = out || new Set(); if (!f) return out; if (f.type === 'USER_VARIABLE') out.add(f.value); fVars(f.l, out); fVars(f.r, out); for (const x of f.a || []) fVars(x, out); return out; }
  function walkL(list, fn, inLoop) { for (const b of list || []) { fn(b, !!inLoop); const l = inLoop || b.type === 'ForeverBrick' || b.type === 'RepeatUntilBrick' || b.type === 'RepeatBrick'; walkL(b.loop, fn, l); walkL(b.ifB, fn, inLoop); walkL(b.elseB, fn, inLoop); } }
  // primer bucle (por siempre / repetir hasta que no haya toque) que contiene "apuntar hacia <objeto>"
  function findFingerLoop(list) {
    for (const b of list || []) {
      if ((b.type === 'RepeatUntilBrick' && fUses(b.f && b.f.REPEAT_UNTIL_CONDITION, FINGER_SENSORS)) || b.type === 'ForeverBrick') {
        let pt = null; walkB(b.loop, x => { if (!pt && x.type === 'PointToBrick' && x.pointed) pt = x; });
        if (pt) return { loop: b, parent: list, point: pt };
      }
      for (const sub of [b.loop, b.ifB, b.elseB]) { const r = findFingerLoop(sub); if (r) return r; }
    }
    return null;
  }
  const JOY_DEFECTS = {
    'dir-once': 'la dirección se leía una sola vez y quedaba congelada',
    'char-dir': 'el personaje no se orientaba según el joystick',
    'tracker': 'el rastreador no seguía al dedo',
    'state-reset': 'el personaje no se detenía al soltar'
  };
  // Se reconoce por la ESTRUCTURA (a qué objeto/variable/mensaje apunta cada bloque), nunca por los nombres. Además se detectan los
  // errores típicos de estos joysticks (los que hacen que en Pocket Code el personaje no siga a la palanca) para repararlos en el motor.
  function detectJoystickPatterns(scenes) {
    const res = [];
    for (const sc of scenes) {
      const names = new Set(sc.objs.map(o => o.name));
      for (const knob of sc.objs) for (const s of knob.scripts) {
        if (s.type !== 'WhenScript' && s.type !== 'WhenTouchDownScript') continue;
        const fl = findFingerLoop(s.bricks); if (!fl) continue;
        const trackerName = fl.point.pointed; if (!names.has(trackerName) || trackerName === knob.name) continue;
        const tracker = sc.objs.find(o => o.name === trackerName);
        let msg = null, stateVar = null;
        walkB(fl.loop.loop, x => {
          if (x.type === 'BroadcastBrick' || x.type === 'BroadcastWaitBrick') msg = x.msg;
          if (x.type === 'SetVariableBrick' && x.f && x.f.VARIABLE && x.f.VARIABLE.type === 'NUMBER' && +x.f.VARIABLE.value === 1) stateVar = x.varName;
        });
        let stateReset = !stateVar;
        if (stateVar) walkB(fl.parent.slice(fl.parent.indexOf(fl.loop) + 1), x => { if (x.type === 'SetVariableBrick' && x.varName === stateVar && x.f && x.f.VARIABLE && x.f.VARIABLE.type === 'NUMBER' && +x.f.VARIABLE.value === 0) stateReset = true; });
        // variable que guarda la dirección de la perilla
        let dirVar = null, dirInLoop = false;
        for (const k of knob.scripts) walkL(k.bricks, (x, il) => {
          if (x.type === 'SetVariableBrick' && x.f && x.f.VARIABLE && x.f.VARIABLE.type === 'SENSOR' && DIR_SENSORS.includes(x.f.VARIABLE.value)) { if (!dirVar) dirVar = x.varName; if (il) dirInLoop = true; }
        });
        // personaje: el que se mueve por la variable de estado / el mensaje / la variable de dirección
        let character = null, pattern = 0, charFinger = false;
        for (const o of sc.objs) {
          if (o === knob || o.name === trackerName || character) continue;
          for (const t of o.scripts) {
            if (msg && t.type === 'BroadcastScript' && t.msg === msg) { character = o; pattern = 3; }
            else if (stateVar && t.type === 'WhenConditionScript' && fVars(t.cond).has(stateVar)) {
              character = o; pattern = 1; walkB(t.bricks, x => { if (x.type === 'RepeatUntilBrick' && fUses(x.f && x.f.REPEAT_UNTIL_CONDITION, FINGER_SENSORS)) charFinger = true; });
              if (charFinger) pattern = 2;
            }
          }
        }
        if (!character) continue;
        // ¿el personaje se orienta con la variable de dirección y lo hace de forma continua / por evento?
        let oriented = false, orientVar = null;
        for (const t of character.scripts) walkL(t.bricks, (x, il) => {
          if (x.type === 'PointInDirectionBrick' && x.f && x.f.DEGREES) {
            const vs = fVars(x.f.DEGREES); if (vs.size && !orientVar) orientVar = [...vs][0];
            if (dirVar ? vs.has(dirVar) : vs.size) { if (il || t.type === 'BroadcastScript' || t.type === 'WhenConditionScript') oriented = true; }
          }
        });
        if (!dirVar && orientVar) dirVar = orientVar; // nadie la actualizaba bien: se toma la que usa el personaje
        const defects = [];
        if (dirVar && !dirInLoop && pattern !== 3) defects.push('dir-once');
        if (dirVar && !dirInLoop && pattern === 3) defects.push('dir-once');
        if (!oriented) defects.push('char-dir');
        let follows = false;
        for (const t of tracker.scripts) walkL(t.bricks, (x, il) => {
          if (il && ((x.type === 'GoToBrick' && x.spinner === 80) || ((x.type === 'PlaceAtBrick' || x.type === 'SetXBrick' || x.type === 'SetYBrick') && Object.keys(x.f || {}).some(k => fUses(x.f[k], FINGER_SENSORS))))) follows = true;
        });
        if (!follows) defects.push('tracker');
        if (stateVar && !stateReset) defects.push('state-reset');
        let base = null;
        for (const o of sc.objs) for (const t of o.scripts) walkB(t.bricks, x => {
          if (x.type === 'GoToBrick' && x.spinner === 82) { if (o === knob && x.gotoName && x.gotoName !== character.name) base = x.gotoName; else if (x.gotoName === knob.name && o.name !== trackerName && o !== character) base = o.name; }
        });
        res.push({ scene: sc.name, pattern, knob: knob.name, tracker: trackerName, character: character.name, base, stateVar, dirVar, message: msg, defects, issues: defects.map(d => JOY_DEFECTS[d]) });
      }
    }
    return res;
  }
  function detectJoysticks(scenes) {
    const out = [];
    for (const sc of scenes) for (const od of sc.objs) {
      let multi = false, single = false, moves = false, vars = false, area = false, math = false, cond = false;
      for (const s of od.scripts) {
        if (scriptUses(s, ['MULTI_FINGER_X', 'MULTI_FINGER_Y', 'MULTI_FINGER_TOUCHED', 'LAST_FINGER_INDEX'])) multi = true;
        if (scriptUses(s, ['FINGER_X', 'FINGER_Y', 'FINGER_TOUCHED'])) single = true;
        if (scriptUses(s, ['COLLIDES_WITH_FINGER'])) area = true;
        // solo cuenta si el bloque que mueve/guarda USA un sensor de dedo en su fórmula (o está dentro de un si-toca-con-dedo)
        const usesF = b => Object.keys(b.f || {}).some(k => fUses(b.f[k], FINGER_SENSORS));
        if (bricksHave(s.bricks, b => POS_WRITERS.has(b.type) && (usesF(b) || scriptUses({ bricks: [b], type: '' }, FINGER_SENSORS)))) moves = true;
        if (bricksHave(s.bricks, b => (b.type === 'SetVariableBrick' || b.type === 'ChangeVariableBrick') && usesF(b))) vars = true;
        if (bricksHave(s.bricks, b => Object.keys(b.f || {}).some(k => fFn(b.f[k], MATH_FNS)))) math = true; // trigonometría / raíz: típico de un joystick
        if ((s.cond && fUses(s.cond, FINGER_SENSORS)) || bricksHave(s.bricks, b => COND_BRICKS.has(b.type) && usesF(b))) cond = true; // "si el dedo toca…"

        if (bricksHave(s.bricks, b => (b.type === 'IfLogicBeginBrick' || b.type === 'IfThenLogicBeginBrick') && usesF(b) && (bricksHave(b.ifB, x => POS_WRITERS.has(x.type)) || bricksHave(b.ifB, x => x.type === 'SetVariableBrick')))) area = area || true;
      }
      if ((multi || single) && ((moves && (math || cond)) || (multi && vars))) out.push({ scene: sc.name, obj: od.name, fingers: multi ? 'multi' : 'single', mueve: moves, variables: vars, trig: math, condicion: cond });
    }
    return out;
  }

  // ¿Cuántos FPS necesita este juego? Si tiene movimiento/animación dentro de bucles, física o deslizamientos, 60; si es casi todo menús y escenas fijas, 30 alcanza.
  const MOVERS = new Set(['MoveNStepsBrick', 'TurnLeftBrick', 'TurnRightBrick', 'ChangeXByNBrick', 'ChangeYByNBrick', 'SetXBrick', 'SetYBrick', 'PlaceAtBrick', 'ChangeSizeByNBrick', 'SetSizeToBrick',
    'ChangeTransparencyByNBrick', 'SetTransparencyBrick', 'ChangeBrightnessByNBrick', 'NextLookBrick', 'PreviousLookBrick', 'SetLookBrick', 'SetLookByIndexBrick', 'IfOnEdgeBounceBrick', 'PointToBrick', 'PointInDirectionBrick']);
  const PHYS = /^(SetPhysicsObjectType|SetVelocity|SetGravity|SetMass|SetBounce|SetFriction|TurnLeftSpeed|TurnRightSpeed|GlideTo)/;
  function analyzeFps(game) {
    let why = '';
    const inLoop = (list, loop) => {
      for (const b of list || []) {
        if (PHYS.test(b.type)) { why = why || 'usa física o deslizamientos'; return true; }
        if (loop && MOVERS.has(b.type)) { why = why || 'tiene movimiento o animación dentro de bucles'; return true; }
        const isLoop = b.type === 'ForeverBrick' || b.type === 'RepeatBrick' || b.type === 'RepeatUntilBrick';
        if (inLoop(b.loop, loop || isLoop) || inLoop(b.ifB, loop) || inLoop(b.elseB, loop)) return true;
      }
      return false;
    };
    for (const sc of game.scenes) for (const od of sc.objs) for (const s of od.scripts) {
      if (s.type === 'CollisionScript') { why = 'usa colisiones'; return { fps: 60, why }; }
      if (inLoop(s.bricks, false)) return { fps: 60, why };
    }
    return { fps: 30, why: 'es casi todo menús y escenas fijas' };
  }

  function compile(xml, fileList, opts) {
    const Parser = (opts && opts.DOMParser) || DOMParser;
    const doc = new Parser().parseFromString(xml, 'text/xml');
    if (doc.getElementsByTagName('parsererror').length) throw new Error('code.xml no es un XML válido');
    const header = doc.getElementsByTagName('header')[0];
    const programName = txt(header, 'programName') || 'Juego';
    const W = parseInt(txt(header, 'virtualScreenWidth') || txt(header, 'screenWidth'), 10) || 2400;
    const H = parseInt(txt(header, 'virtualScreenHeight') || txt(header, 'screenHeight'), 10) || 1080;

    const sceneEls = kids(kid(doc.documentElement, 'scenes'), 'scene');
    let scenes;
    if (sceneEls.length) scenes = sceneEls.map(el => compScene(el));
    else if (kid(doc.documentElement, 'objectList')) scenes = [compScene(doc.documentElement, 'Escena')]; // formato antiguo sin escenas
    else throw new Error('El proyecto no tiene escenas ni objetos');

    // índice de archivos: nombre en minúsculas -> rutas dentro de "assets/"
    const files = {};
    for (const rel of fileList || []) {
      const base = rel.split('/').pop().toLowerCase();
      (files[base] || (files[base] = [])).push('assets/' + rel);
    }

    const rep = { programName, scenes: scenes.length, objects: 0, scripts: 0, bricks: 0, bricksUsed: {}, unsupportedBricks: {},
      ignoredBricks: {}, unsupportedScripts: {}, unsupportedFormulas: {}, mobileSensors: {}, missingAssets: [] };
    for (const sc of scenes) for (const od of sc.objs) {
      rep.objects++;
      for (const l of od.looks) if (l.file && !files[l.file.toLowerCase()]) rep.missingAssets.push(l.file);
      for (const s of od.sounds) if (s.file && !files[s.file.toLowerCase()]) rep.missingAssets.push(s.file);
      for (const s of od.scripts) {
        rep.scripts++;
        if (!SUPPORTED_SCRIPTS.has(s.type)) inc(rep.unsupportedScripts, s.type);
        scanF(s.cond, rep); scanBricks(s.bricks, rep, files);
      }
    }
    rep.missingAssets = Array.from(new Set(rep.missingAssets));
    rep.ok = !Object.keys(rep.unsupportedBricks).length && !Object.keys(rep.unsupportedScripts).length &&
      !Object.keys(rep.unsupportedFormulas).length && !rep.missingAssets.length;

    rep.inputs = detectInputs(scenes).length; rep.joysticks = detectJoysticks(scenes); rep.fingerObjs = fingerObjects(scenes); rep.joystickPatterns = detectJoystickPatterns(scenes);
    const vars = declaredVars(doc); rep.declaredVars = Object.keys(vars).map(k => ({ name: k, value: vars[k] }));
    return { game: { format: 1, meta: { programName, W, H }, scenes, files, inputs: detectInputs(scenes), joysticks: rep.joysticks, joyPatterns: rep.joystickPatterns, vars }, report: rep };
  }

  return { compile, compScene, analyzeFps, SUPPORTED_BRICKS, IGNORED_BRICKS, SUPPORTED_SCRIPTS, detectJoystickPatterns };
});
